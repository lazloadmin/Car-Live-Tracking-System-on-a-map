<?php

class Home_m extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        //$this->load->library('BRIFBusiness');
    }

    public function login($userName = '', $password = '') {
    
        $query = $this->db->get_where('users', array('username' => $userName, 'password' => $password, 'status' => 'Active'));
        if ($query->num_rows() > '0') {
            $result = $query->row_array();
           return $result;
        } else {
            return false;
        }
    }

}

?>