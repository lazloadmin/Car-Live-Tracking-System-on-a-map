<?php

class Admin_model extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        $this->load->library('BRIFBusiness');
    }

    // for lolgin  
    public function get_login($request = '') {
//        include APPPATH . 'third_party/Database.php';
//        include APPPATH . 'third_party/MetaData.php';
//        include APPPATH . 'third_party/Tools.php';
//        include APPPATH . 'third_party/User.php';
//        include APPPATH . 'third_party/People.php';
//        include APPPATH . 'third_party/Peoplebusiness.php';
//        include APPPATH . 'third_party/Userpermissiongroup.php';
        $userLogIn = new UserLogIn();
        $userLogIn->JSONDecode($request); //Perse the JSON request
        $result = $userLogIn->LogIn();
        return $userLogIn->JSONEncode();
    }

    public function get_loginXX($email = '', $password = '') {
//        include APPPATH . 'third_party/Database.php';
//        include APPPATH . 'third_party/MetaData.php';
//        include APPPATH . 'third_party/Tools.php';
//        include APPPATH . 'third_party/User.php';
//        include APPPATH . 'third_party/People.php';
//        include APPPATH . 'third_party/Peoplebusiness.php';
//        include APPPATH . 'third_party/Userpermissiongroup.php';
        $user = new User();
        $user = $user->Login($email, $password);
        return $user;
    }

    public function getClientlist() {
        $this->db->order_by("ID_pepl", "desc");
        $this->db->where('Email_pepl!=', 'admin@gmail.com');
        $result = $this->db->get('tblpeople')->result_array();
        return $result;
    }

//............................. Business List  ...................///////////
    public function getbusinesslist() {
//        include APPPATH . 'third_party/Database.php';
//        include APPPATH . 'third_party/MetaData.php';
//        include APPPATH . 'third_party/Tools.php';
//        include APPPATH . 'third_party/User.php';
//        include APPPATH . 'third_party/People.php';
//        include APPPATH . 'third_party/Peoplebusiness.php';
//        include APPPATH . 'third_party/Userpermissiongroup.php';
        $result = User::isUserAllowed();
        if ($result == true) {
            $this->db->order_by("ID_busi", "desc");
            //$this->db->where('Email_pepl!=','admin@gmail.com');
            $result = $this->db->get('tblbusiness')->result_array();
            return $result;
        }
    }

    public function checkActive($param1 = '') {
        $type = $this->db->get_where('tbluser', array('ID_user' => $param1));
        if ($type->num_rows() > 0) {
            $type1 = $type->row_array();
            $Status_user = $type1['Status_user'];
            return $Status_user;
        } else {
            return false;
        }
    }
    
    public function searchPeoples($request)
    {
        //return $request;
        $result =  BusinessRegisterView::searchPeoples($request);
        return $result;
    }
    
    /// Business List New Functions
    
    //getting business list
    
    public function getBusiList()
    {
        $res=Business::getBusiList();
    }
    
    //getting business details
    
    public function getBusiDetail($request)
    {
        $res=Business::getBusiDetail($request);
    }
    
    //updating business list
    
    public function updateBusiList($request)
    {
        $res=Business::updateBusiList($request);
    }
    
    
    /*
     * Group Permission List
     * 
     * Function used to set permission based on
     * group name
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function groupPermissionList($argData = '')
    {
        $results = Permissiongroup::groupPermissionList($argData);
        return $results;
    }
    
    
    /*
     * Group Permission Update
     * 
     * Function used to update group permission based on
     * group name
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function groupPermissionUpdate($groupName = '',$systemFunction = '',$status = false)
    {
        $date = date('Y-m-d H:i:s.');
        $id = User::getSessionUserDefaultBusinessID();
        $currentUserID =User::GetSessionUser()->ID_pepl_user_n_sqt;
        
        $permissiongroupfunction = new Permissiongroupfunction();
        $permissiongroupfunction->GroupName_pgrp_pgrf_s_sqt = $groupName;
        $permissiongroupfunction->Method_sysf_pgrf_s_sqt = $systemFunction;
        
        $results = $permissiongroupfunction->LoadDataArrayJSON('');
        
        
        $permissiongroupfunction->Status_pgrf_s_sqt = ($status == true)?'Active':'Deactivated';
        
        // Update data when exist in records
        if($results != '[]')
        {
            $permissiongroupfunction->DateUpdated_pgrf_d_sqt =  $date;
            $permissiongroupfunction->UpdatedBy_pgrf_n_sqt = $currentUserID; 
            $resultStatus = $permissiongroupfunction->UpdateDB();
            return $resultStatus;
            
        }
        // Insert data when not exist in our records
        else
        {
            $permissiongroupfunction->DateAdded_pgrf_d_sqt =  $date;
            $permissiongroupfunction->AddedBy_pgrf_n_sqt = $currentUserID; 
            $resultStatus =  $permissiongroupfunction->InsertIntoDB();
            return $resultStatus;
        }
    }
    
    /*
     * System Function List
     * 
     * Function list all the function that are
     * being used
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function systemFunctionList($argData = '1=1')
    {
        $systemFunction  = new SystemFunction();
        $results = $systemFunction->LoadDataArrayJSON($argData);
        return $results;
    }
    
    /*
     * Permission Group Function
     * 
     * Function list all the function that are
     * being used
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function permissionGroupFunction($groupName)
    {
        $permissionGroupFunction  = new Permissiongroupfunction();
        
        $results = $permissionGroupFunction->LoadDataArrayJSON('Status_pgrf = "Active" AND GroupName_pgrp_pgrf = "'.$groupName.'"');
        return $results;
    }
    
    /*
     * Sales Report Group By
     * 
     * Function list all the recrod 
     * based on business id
     * 
     * @param mixed depend on what array contain
     * @retrun json contain all the records
     */
    public function salesReportGroupBy($groupBy,$day1,$day2)
    {
        $saleOrder  = new get_saleorder();
        
        $results = $saleOrder->salesReportGroupBy($groupBy,$day1,$day2);
        return $results;
    }
    
    
    /*
     * User Permission List
     * 
     * Function used to list permission based on
     * group name
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function userPermissionList($groupName)
    {
        $permissionGroupFunction  = new Permissiongroupfunction();
        
        $results = $permissionGroupFunction->LoadDataArrayJSON('GroupName_pgrp_pgrf = "'.$groupName.'"');
        return $results;
    }
    
    /*
     * User Permission Update
     * 
     * Function used to update user permission based on
     * people id and business id and function name
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function userPermissionUpdate($groupName = '',$systemFunction = '',$status = false,$peplid,$busiid)
    {
        $date = date('Y-m-d H:i:s.');
        $id = User::getSessionUserDefaultBusinessID();
        $currentUserID =User::GetSessionUser()->ID_pepl_user_n_sqt;
        
        $userpermission = new Userpermission();
        $userpermission->ID_pepl_usrp_n_sqt = $peplid;
        $userpermission->ID_busi_usrp_n_sqt = $busiid;
        $userpermission->Method_sysf_usrp_s_sqt = $systemFunction;
        
        $list = $userpermission->Load();
        
        if($list[0]->ID_usrp_n_sqta)
        {
             $list[0]->Status_usrp_s_sqt = ($status == true)?'Active':'Deactivated';
             $result = $list[0]->UpdateDB();
        }
       
        return $result;
    }
    
    /*
     * User Person List
     * 
     * Function used to list user persons
     * based on people id, bussiness id
     * 
     * @param mixed depend on what array contain
     * @retrun void
     */
    public function userPersonList($peopleId,$businessId)
    {
        $userPermission  = new Userpermission();
        $userPermission->ID_pepl_usrp_n_sqt = $peopleId;
        $userPermission->ID_busi_usrp_n_sqt = $businessId;
        $userPermission->Status_usrp_s_sqt = 'Active';
        $results = $userPermission->LoadDataArrayJSON('');
        return $results;
    }
    
    /*
     * User Sales Report Group By
     * 
     * Function list all the recrod 
     * based on business id
     * 
     * @param mixed depend on what array contain
     * @retrun json contain all the records
     */
     public function userSalesReportGroupBy($groupBy,$businessId,$day)
    {
        $saleOrder  = new get_saleorder();
        
        $results = $saleOrder->userSalesReportGroupBy($groupBy,$businessId,$day);
        return $results;
    }
    
    public function datewiseuserSalesReport($groupBy,$businessId,$day,$sdate)
    {
        $saleOrder  = new get_saleorder();
        
        $results = $saleOrder->datewiseuserSalesReport($groupBy,$businessId,$day,$sdate);
        return $results;
    }
    
    public function weekwiseuserSalesReport($groupBy,$businessId,$day,$sdate)
    {
        $saleOrder  = new get_saleorder();
        
        $results = $saleOrder->weekwiseuserSalesReport($groupBy,$businessId,$day,$sdate);
        return $results;
    }
}

?>