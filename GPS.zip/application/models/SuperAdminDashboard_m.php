<?php

class SuperAdminDashboard_m extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        //$this->load->library('BRIFBusiness');
    }

    /*
     * for getiing permission list
     */
    public function getPermissionList($par1 = '', $par2 = '') {
        $this->db->select('*');
        $this->db->from('permission_name');
        $this->db->join('permission', 'permission.permission_id = permission_name.id');
        $query = $this->db->get()->result_array();
        return $query; 
    }
    /*
     * for checking permission list 
     * if user is exist then show user data 
     * if not esist then notshow the user data 
     */
    public function checkPermissionList ($par1='',$par2=''){
      $result = $this->db->get_where('permission', array('permission_id'=>$par1))->result_array();
     if(count($result)>0){
        return true;
      }else{
          return false;
      }
    }
    

}

?>