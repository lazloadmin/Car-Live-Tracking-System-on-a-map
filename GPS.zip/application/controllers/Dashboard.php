<?php

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->model('Dashboard_m');
        if (!$this->session->userdata['admin'] && !$this->session->userdata['superadmin']) {
            $this->session->set_flashdata('permission_message', 'log_again');
            redirect('index.php/Home/admin', 'refresh');
        }
    }

    /*
     * for view login page 
     */

    public function index() {
        //$this->load->view('login');
         
         $this->load->view('admin/header');
         $this->load->view('admin/dashboard');
         $this->load->view('admin/footer');
    }

    /*
     * for user login
     * check if user exist then show user login 
     */

    public function admin() {

        $this->load->view('admin/header');
        $this->load->view('admin/dashboard');
        $this->load->view('admin/footer');
    }

    /*
     * for add user
     */

    public function addUser($param1 = '') {
        $pageData['par1'] = $param1;
        $a_id = $this->session->userdata['admin']['id'];
        $pageData['a_id'] = $a_id;
        $pageData['portal_user'] = $this->db->get_where('porat_user', array('a_id' => $a_id))->result_array();
        // echo $this->input->post('type');
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Add Edit User';
        $this->load->view('admin/header');
        
        $this->load->view('admin/addUser', $pageData);
        $this->load->view('admin/footer');
        $this->load->view('model');
    }

    /*
     * for searching table 
     */

    public function addUser1() {

        $pageData['portal_user'] = $this->db->get_where('porat_user', array('usertype' => 'sub'))->result_array();
        // echo $this->input->post('type');
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Add Edit User';
        $this->load->view('admin/header');
        $this->load->view('admin/addUser', $pageData);
        $this->load->view('admin/footer');
    }

    /*
     * for save user data
     */

    public function saveUser($param1 = '', $param2 = '', $param3 = '') {
        //echo '<pre>';  print_r($_POST);
       // die;
      
        
        $data['user_id'] = $this->input->post('userId');
        $data['username'] = $this->input->post('userName');
        if ($this->input->post('password')) {
            $data['password'] = $this->input->post('password');
        }
        $data['usertype'] = $this->input->post('usertype');
        $data['phone'] = $this->input->post('phoneNumber');
        $data['dob'] = $this->input->post('dob');
        $data['email'] = $this->input->post('emailId');
        $data['mobile_app'] = $this->input->post('onoffswitch2');
        $data['portal_login'] = $this->input->post('onoffswitch1');
        //$data[''] = $this->input->post('upload'); // for image
        $data['gender'] = $this->input->post('gender');
        $data['address'] = $this->input->post('address');
        $data['fleet_size'] = $this->input->post('fleetSize');
        $data['must_set_password'] = $this->input->post('mustSetPassword');
        $data['timezone'] = $this->input->post('timeZone');
        $data['date'] = date('Y-m-d H:i:s');
        
        $data['date_formate']= $this->input->post('dateFormate');
        $data['portalexpirydate'] =  $this->input->post('portalexpiryDta');
        //$a_id =  $this->session->userdata['login']['admin']['id'];
        $data['a_id'] = $this->session->userdata['admin']['id'];
        
       // echo '<pre>'; print_r($data); die;
        

        if ($param1 == 'create') {
            
          $result = $this->db->insert('porat_user', $data); 
       
          //  echo $this->db->last_query();
       //die;
            $this->session->set_flashdata('flash_message', 'Save sucessfully');
            redirect('index.php/Dashboard/addUser', 'refresh');
        } else if ($param1 == 'edit') {
            $id = $this->input->post('hid');
            $this->db->where('id', $id);
            $this->db->update('porat_user', $data);
            $this->session->set_flashdata('flash_message', 'Update  sucessfully');
            redirect('index.php/Dashboard/addUser', 'refresh');
        } else if ($param1 == 'delete') {
            $id = $this->input->post('id');
            $this->db->where('id', $id);
            $this->db->delete('porat_user');
            $this->session->set_flashdata('flash_message', 'Delete  sucessfully');
            redirect('index.php/Dashboard/addUser', 'refresh');
        }
    }
    
    /*
     * function for check user exist or not exist
     */
    public function checkUserId(){
        $userId = $this->input->post('userId'); 
        $result = $this->db->get_where('porat_user',array('user_id'=>$userId))->result_array();
       // print_r($result);
        $data = '';
        if(count($result)>0){
            $data = '1';
        }
        print_r($data);
    }

    /*
     * for showing mobile app user
     */

    public function MobileAppUser() {
        $a_id = $this->session->userdata['admin']['id'];
        $pageData['a_id'] = $a_id;

        $pageData['portal_user'] = $this->db->get_where('porat_user', array('mobile_app' => '1', 'a_id' => $a_id))->result_array();
        // echo $this->input->post('type');
        // echo '<pre>';  print_r( $pageData['portal_user']); die;
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Mobile App User';
        $this->load->view('admin/header');
        $this->load->view('admin/mobileAppUser', $pageData);
        $this->load->view('admin/footer');
    }

    /*     * ****** Device management meenu Start Here ******************** */


    /*
     * for add vehicle 
     * @par1 create then add
     * @par1 edit then edit 
     */

    public function addEditDevice($par1 = '', $par2 = '') {

        $a_id = $this->session->userdata['admin']['id'];
        $pageData['a_id'] = $a_id;
        $pageData['par1'] = $par1;
        $pageData['devicedetails'] = $this->db->get_where('devicedetails', array('a_id' => $a_id))->result_array();
        $pageData['vehicaltype'] = $this->db->get_where('vehicaltype', array('status' => 'Active'))->result_array();
        $pageData['simoperator'] = $this->db->get_where('simoperator', array('status' => 'Active'))->result_array();
        $pageData['devicetype'] = $this->db->get_where('devicetype', array('status' => 'Active'))->result_array();
        $pageData['Installer'] = $this->db->get_where('employee', array('desigination' => 'Installer', 'a_id' => $a_id))->result_array();
        $pageData['Sales'] = $this->db->get_where('employee', array('desigination' => 'Sales', 'a_id' => $a_id))->result_array();
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Add/Edit Device';
        $this->load->view('admin/header');
        $this->load->view('admin/addEditDevice', $pageData);
        $this->load->view('admin/footer');
        $this->load->view('model');
    }

    /*
     * for add  Device  final 
     * $par1 can perform all operation
     */

    public function addEditDeviceFinal($par1 = '', $par2 = '') {

        $data['instalationdate'] = $this->input->post('instalationdate');
        $data['deviceid'] = $this->input->post('deviceid');
        $data['devicetype'] = $this->input->post('devicetype');
        $data['deviceimi'] = $this->input->post('deviceimi');
        $phoneNumber = $this->input->post('simphoneno');// re changing the sim imi to 
        $data['simphoneno'] = $this->input->post('simphoneno');
        $data['simimi'] = preg_replace('/\s+/', '', '00000'.$phoneNumber);
        $data['simselection'] = $this->input->post('simselection');
        $data['simoperator'] = $this->input->post('simoperator');
        $data['vehicalnumber'] = $this->input->post('vehicalnumber');
        $data['vehicaldetails'] = $this->input->post('vehicaldetails');
        $data['devicesoldby'] = $this->input->post('devicesoldby');
        $data['deviceinstalledby'] = $this->input->post('deviceinstalledby');
        $data['vehicaltype'] = $this->input->post('vehicaltype');
        $data['date'] = date('Y-m-d H:i:s');
        $data['a_id'] = $this->session->userdata['admin']['id'];
        
              // echo  $data = substr($data['simimi'],7); die;
        

        if ($par1 == 'create') {
            $result = $this->db->insert('devicedetails', $data);
            $lastId = $this->db->insert_id(); 
            // for getting vehical imi 
            $vehicaltype = $this->db->get_where('vehicaltype',array('id'=>$data['vehicaltype']))->row_array();
            
            // for add vehical assign
           //$data = substr($data['simimi'],7); die;
            
            $assignvehical['a_id']= $this->session->userdata['admin']['id'];
            $assignvehical['user_id']= ''; 
            $assignvehical['device_id']=  $lastId;
            $assignvehical['vehical_imi']= substr($data['simimi'],5);
            $assignvehical['vehical_name']= $vehicaltype['vehicalname'];
            
            $assignvehical['date']= $data['date'];
            $result = $this->db->insert('assignvehical', $assignvehical);
            $this->session->set_flashdata('flash_message', 'Save sucessfully');
            redirect('index.php/Dashboard/addEditDevice', 'refresh');
            
            
            
        } else if ($par1 == 'edit') {
            $id = $this->input->post('hid');
            $this->db->where('id', $id);
            $this->db->update('devicedetails', $data);
            $this->session->set_flashdata('flash_message', 'Update  sucessfully');
            redirect('index.php/Dashboard/addEditDevice', 'refresh');
        } else if ($par1 == 'delete') {
            $id = $this->input->post('id');
            $this->db->where('id', $id);
            $this->db->delete('devicedetails');
            $this->session->set_flashdata('flash_message', 'Delete  sucessfully');
            redirect('index.php/Dashboard/addEditDevice', 'refresh');
        }
    }

    /*
     * function for vehichal allocation
     */

    public function vehicalAllocation($par1 = '', $par2 = '') {


        $this->db->select('*');
        $this->db->from('vehicaltype');
        $this->db->join('devicedetails', 'vehicaltype.id = devicedetails.vehicaltype');
        $query = $this->db->get()->result_array();
        $pageData['devicedetails'] = $query;
        // echo '<pre>'; print_r($pageData['devicedetails']); die; 
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Vehicle Allocation';
        $this->load->view('admin/header');
        $this->load->view('admin/vehicalAllocation', $pageData);
        $this->load->view('admin/footer');
    }

    /*
     * for vehical allocation search
     * search by usera name 
     * with like operator
     */

    public function searchUser() {
        $searctext = $this->input->post('searchtext');
        $this->db->select('*');
        $this->db->from('porat_user');
        $this->db->like('user_id', $searctext);
        //$this->db->where('usertype','Main');
        $query = $this->db->get()->result_array();
        ?>
        <?php foreach ($query as $key => $value) { ?>
            <span  class="reslt" id="<?php echo $value['user_id'] ?>" > <?php echo $value['user_id'] ?></span>
            <?php
        }
    }

    /*
     * for add and delete vehical assign
     * when action == add then insert recod to assign vehivcal
     * when action == remove then delete particular record 
     */

    public function addDeleteVehicalAssign($par1 = '', $par2 = '') {
        $action = $this->input->post('action');
        // for get device details
        $devceid = $this->input->post('id');
        $userId = $this->input->post('userId');
        if ($action == 'add') {
           $result =  $this->db->get_where('assignvehical',array('device_id'=> $devceid ))->row_array();
          // print_r($result['user_id']); die;
           $userIdDetails = $result['user_id'];
           $userIdDetails1  =  explode(',',$userIdDetails);
          // print_r($userIdDetails1); die;
           $checkValue = '';
           foreach($userIdDetails1 as $key=>$value){
               if($value == $userId ){
                    $checkValue = 1;
               }
           }
           
          if($result['user_id']){
              $result['user_id'] = $result['user_id'].','.$userId ; 
          }else{
               $result['user_id'] = $userId;
          }
            if($checkValue==''){
            $this->db->where('device_id',$devceid);
            $this->db->update('assignvehical', $result);
            }
            //echo $this->db->last_query(); die;
            
        } else if ($action == 'remove') {
          $result =  $this->db->get_where('assignvehical',array('device_id'=> $devceid ))->row_array();
         // print_r($result); die;
          
          
          if($result['user_id']){
              $removeUserId = explode(',',$result['user_id']);
              // print_r($removeUserId); 
              $newdata = '';
                $asd =  count($removeUserId);  
              if( $asd  > 1){
               // echo $devceid.'/';  
                  foreach($removeUserId as $key=>$value){
                      if($value==$userId){
                          
                      }else{
                         $newdata .= $value.','; 
                      }
                  }
                
                  $newdata = substr($newdata, 0, -1); 
                  $result['user_id'] = $newdata; 
                  $this->db->where('device_id',$devceid);
                  $this->db->update('assignvehical', $result);
                  //echo $this->db->last_query(); die;
             }
             else{
                
                  $result['user_id'] = ''; 
                  $this->db->where('device_id',$devceid);
                  $this->db->update('assignvehical', $result);
                  //echo $this->db->last_query(); die;
              }
              
          }
            
            
 
        }
    }

    /*     * **** Admin Menu Start Here ************ */


    /*
     * for employee management 
     */

    public function employeeManagement($par1 = '', $par2 = '') {
        $pageData['par1'] = $par1;
        $a_id = $this->session->userdata['admin']['id'];
        $pageData['employee'] = $this->db->get_where('employee', array('a_id' => $a_id))->result_array();
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Employee Management';
        $this->load->view('admin/header');
        $this->load->view('admin/employeeManagement', $pageData);
        $this->load->view('admin/footer');
        $this->load->view('model');
    }

    /*
     * for save EmployeeManagement
     */

    public function saveEmployeeManagement($par1 = '', $par2 = '') {
        $a_id = $this->session->userdata['admin']['id'];
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['address'] = $this->input->post('address');
        $data['phone'] = $this->input->post('phone');
        $data['dob'] = $this->input->post('dob');
        $data['desigination'] = $this->input->post('desigination');
        $data['date'] = date('Y-m-d H:i:s');
        $data['a_id'] = $a_id;
        if ($par1 == 'create') {
            $result = $this->db->insert('employee', $data);
            $this->session->set_flashdata('flash_message', 'Save sucessfully');
            redirect('index.php/Dashboard/employeeManagement', 'refresh');
        } else if ($par1 == 'edit') {
            $id = $this->input->post('hid');
            $this->db->where('id', $id);
            $this->db->update('employee', $data);
            $this->session->set_flashdata('flash_message', 'Update  Sucessfully');
            redirect('index.php/Dashboard/employeeManagement', 'refresh');
        } else if ($par1 == 'delete') {
            $id = $this->input->post('id');
            $this->db->where('id', $id);
            $this->db->delete('employee');
            $this->session->set_flashdata('flash_message', 'Delete Sucessfully');
            redirect('index.php/Dashboard/employeeManagement', 'refresh');
        }
    }

    /*
     * for mobile portal feature
     */

    public function mobilePortalFeature($par1 = '', $par2 = '') {
        $pageData['par1'] = $par1;
        $pageData['employee'] = $this->db->get('employee')->result_array();
        $pageData['pageName'] = 'Admin';
        $pageData['Title'] = 'Mobile Portal Feature';
        $this->load->view('admin/header');
        $this->load->view('admin/mobilePortalFeature', $pageData);
        $this->load->view('admin/footer');
        $this->load->view('model');
    }

    /*
     * for Save mobile portal feature
     */

    public function saveMobilePortalFeature($par1 = '', $par2 = '') {
        
    }

    /*
      for get getgpsdata function particular business id
     */

    public function getgpsdata1() {
        
   
        $a_id = $this->session->userdata['admin']['id'];

//        $this->db->select("*");
//        $this->db->from("assignvehical");
//        $this->db->order_by("id", "desc");
//        $this->db->where('a_id', $a_id);
//        $query = $this->db->get();
//        $assignvehical = $query->result_array();
//
//        //$query = $this->db->order_by('birth_date', 'ASC')->get_where($this->tbl_name, $where);
//        //echo '<pre>';  print_r($assignvehical); die;
//
//        $deviceId = $assignvehical[0]['device_id'];
//        $deviceId1 = array();
//        $assignvehical1 = array();
//        $imiNumber = array();
//        foreach($assignvehical as $key=>$value){
//        $deviceId1[] = $value['device_id']; 
//           
//        $ndI = $value['device_id'];
//        $this->db->select("*");
//        $this->db->from("devicedetails");
//        $this->db->order_by("id", "desc");
//        $this->db->where('id', $ndI);
//        $query1 = $this->db->get();
//        $assignvehical1[] = $query1->result_array();
//         //$imiNumber[] =  
//        }
            //echo '<pre>'; print_r($assignvehical1); die; 
            
            
            
        
        
        
        
        // for getting device details vehical 
        $this->db->select("*");
        $this->db->from("devicedetails");
        $this->db->order_by("id", "desc");
        $this->db->where('id', $deviceId);
        $query1 = $this->db->get();
        $assignvehical1 = $query1->result_array();
        // print_r(json_encode($assignvehical)); die;
      // echo '<pre>'; print_r($assignvehical1); die; 
        $simimi1 = '(' . $assignvehical1[0]['simimi'];
        //$ab = '(000008604040635';

        $simimi = ltrim($simimi1, '( 00000');
        //$simimi1 =  substr($simimi, 1); 

        $this->db->select("*");
        $this->db->from("record");
        $this->db->order_by("id", "desc");
        $this->db->where('imino', $simimi);
        $query2 = $this->db->get();
        $result = $query2->result_array();

        // $this->db->order_by("id","desc");
        // $result = $this->db->get_where('record')->result_array();
        print_r(json_encode($result));
    }
    
   /*
    * function for get vehical user data
    * for particular user assign
    */
    public function getAssignVehicalDataPartularUser(){
        $userId = $this->input->post('userId');
        $SQL = "SELECT * FROM `assignvehical` WHERE `FIND_IN_SET`('$userId',`user_id`);";
        $query = $this->db->query($SQL);
        $result = $query->result_array(); ?> 
         <select name="assignvehical[]" id="select-to" multiple size="10"  class="form-control1">
        <?php 
        foreach($result as $key=>$value){
            ?>
             <option value="<?php echo $value['device_id']; ?>"> <?php echo $value['vehical_name']; ?></option>                                  
            <?php
        }
        ?>
       </select>
             <?php
        //echo json_encode($result);
    }
    
    /*
     * function for get user list 
     * which is assign by the user
     * 
     */
    public function getuserList(){
        $a_id = $this->session->userdata['admin']['id'];
        $result = $this->db->get_where('porat_user',array('a_id'=>$a_id,'status'=>'Active'))->result_array();
        print_r(json_encode($result));
        }
        
        
    /*
     * for getting gps data
     * for particular user id
     */
        public function getGpsData(){
           $userId = file_get_contents('php://input');
           $SQL = "SELECT * FROM `assignvehical` WHERE `FIND_IN_SET`('$userId',`user_id`);";
           $query = $this->db->query($SQL);
           $result = $query->result_array();
           $data = array(); // for getting data 
           foreach($result as $key=>$value){
               $deviceId = $value['device_id'];
             
              $newData =  $this->db->get_where('record',array('device_id'=>$deviceId))->row_array();
               if($newData ){
               $data[] =  $newData ;
               }
           }
           
           print_r(json_encode($data));
           
           
        }
    
    
        
        /*
         * get gps data final
         * for all user 
         */
        public function getFinalGpasData(){
            $a_id = $this->session->userdata['admin']['id'];
            $assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id))->result_array();
            $newData = array();
            if($assignVehical){
            $vehicalNumber = file_get_contents('php://input');
           //print_r($vehicalNumber); die;
            if($vehicalNumber){
                $deviceDetails = $this->db->get_where('devicedetails',array('a_id'=>$a_id,'vehicalnumber'=>$vehicalNumber))->row_array();
              
                //print_r($deviceDetails);  die;
                if($deviceDetails){
                    $deviceId1 = $deviceDetails['id'];
                    $assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id,'device_id'=>$deviceId1))->row_array();
                    //print_r($assignVehical); die;
                    if($assignVehical){
                         $deviceId2 = $assignVehical['device_id'];
                         //$recordForVehicalNo = $this->db->get_where('record',array('device_id'=>$deviceId2))->result_array();
                         $SQL = "select * from record where device_id = '$deviceId2' order by id desc limit 1";
                         $query = $this->db->query($SQL);
                         $result = $query->result_array();
                         print_r(json_encode($result)); 
                    }
                    
                }
            }else{
           
            //$assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id))->result_array();
            $newData = array();
            foreach($assignVehical as $key=>$value){
                $deviceId = $value['device_id'];
               // $result = $this->db->get_where('record',array('device_id'=>$deviceId))->result_array();
                $SQL = "select * from record where device_id = '$deviceId' order by id desc limit 1";
                $query = $this->db->query($SQL);
                $result = $query->result_array();
                 if(count($result)>0){
                     foreach($result as $key=>$value3){
                         $newData[] = $value3;
                     }
                 }
//                 if(count($result)=='1'){
//                     $newData[] = $result[0]; 
//                 }
            }
             print_r(json_encode($newData)); 
         }
    }
    
 }
        
          public function getFinalGpasData11111111(){
            $userId = file_get_contents('php://input');
            
            $a_id = $this->session->userdata['admin']['id'];
            $assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id))->result_array();
            $newData = array();
            foreach($assignVehical as $key=>$value){
                $deviceId = $value['device_id'];
                $result = $this->db->get_where('record',array('device_id'=>$deviceId))->row_array();
                 if($result){
                $newData[] = $result;
                 }
            }
            print_r(json_encode($newData)); 
        }
        
        
          /*
         * get gps data final
         * for all user 
         */
        public function getFinalGpasData111FFFf(){
            $a_id = $this->session->userdata['admin']['id'];
            $assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id))->result_array();
            $newData = array();
            if($assignVehical){
            $vehicalNumber = file_get_contents('php://input');
            if($vehicalNumber){
                $deviceDetails = $this->db->get_where('devicedetails',array('a_id'=>$a_id,'vehicalnumber'=>$vehicalNumber))->row_array();
              
                //print_r($deviceDetails);  die;
                if($deviceDetails){
                    $deviceId1 = $deviceDetails['id'];
                    $assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id,'device_id'=>$deviceId1))->row_array();
                    //print_r($assignVehical); die;
                    if($assignVehical){
                         $deviceId2 = $assignVehical['device_id'];
                         $recordForVehicalNo = $this->db->get_where('record',array('device_id'=>$deviceId2))->result_array();
                         print_r(json_encode($recordForVehicalNo)); 
                    }
                    
                }
            }else{
           
            //$assignVehical = $this->db->get_where('assignvehical',array('a_id'=>$a_id))->result_array();
            $newData = array();
            foreach($assignVehical as $key=>$value){
                $deviceId = $value['device_id'];
               $result = $this->db->get_where('record',array('device_id'=>$deviceId))->result_array();
                
                
                
                 if(count($result)>1){
                     foreach($result as $key=>$value3){
                         $newData[] = $value3;
                     }
                 }
                 if(count($result)=='1'){
                     $newData[] = $result[0]; 
                 }
            }
             print_r(json_encode($newData)); 
         }
    }
    
 }
 
 /*
  * function for get 
  * user wise working vehical and not working
  * vehical 
  */
 public function getUserWiseWokingVehical($par1='',$par2=''){
    
    // $selectedTime = "9:15:45";
     //$endTime = strtotime("-1 minutes", strtotime($selectedTime));
     //echo date('h:i:s', $endTime); die;
     
    // echo TIME('2009-05-18 15:45:57.005678'); 
    //print_r(  explode(' ','2017-01-17 09:04:01')); die;
     //TIME("2009-05-18 15:45:57.005678")
     
     // echo '<pre>';
     $a_id = $this->session->userdata['admin']['id'];
     $porat_user = $this->db->get_where('porat_user',array('a_id'=>$a_id,'status'=>'Active'))->result_array();
     // print_r(json_encode($porat_user));
     $workingDeviceData = array();
     $notworkingDeviceData = array();
     $userId = '';
     $deviceId = '';
     foreach($porat_user as $key=>$value){
           $userId = $value['user_id'];
           $SQL = "SELECT * FROM `assignvehical` WHERE `FIND_IN_SET`('$userId',`user_id`);";
           $query = $this->db->query($SQL);
           $result = $query->result_array();
           $i = '1';
           if($result){
               //echo '<pre>';  print_r($result); die;
               //$deviceId = $result['device_id']; 
              $workingDeviceData[$userId]['total'] = count($result);
              foreach($result as $key1=>$value1){
                 // echo $i;
                  $deviceId = $value1['device_id'];
                  //$notworkingDeviceData[$userId]['notworking'] = '';
                   $date = date('H:i:s');
                   $endTime = strtotime("-50 minutes", strtotime($date)); 
                   $checkDate = date('h:i:s', $endTime); 
                   $date1 = date("Y-m-d");
                   
                   $SQL = "SELECT * FROM record WHERE   time = '$date1' AND time1 BETWEEN NOW() - INTERVAL 15 MINUTE AND NOW() - INTERVAL 1 MINUTE order by id desc limit 1";
                   //$SQL = "select * from record where device_id = '$deviceId' AND UTC(time) = '2017-01-17'  AND  time1 BETWEEN  '$checkDate' AND '$date'  order by id desc";
                  // $SQL = "select * from record where device_id = '$deviceId' AND time1  NOT IN ($checkDate,$date); order by id desc limit 1";
                    //echo $SQL ; die;
                   $query = $this->db->query($SQL);
                   $result2 = $query->result_array();
                   if(count($result2)>0){
                       $workingDeviceData[$userId]['working'] =   $workingDeviceData[$userId]['working'] + count($result2);
                   }
                  // print_r($result2); die;
                   
                  
             $i++; }
           }
           
          // $SQL = "SELECT * FROM `record` WHERE `FIND_IN_SET`('$userId',`user_id`);";
           //$query = $this->db->query($SQL);
           
     }
     
    // print_r($workingDeviceData); die;
     print_r(json_encode($workingDeviceData));
     
 }
 
 
 /*function for get user wise vehical details
  * when click particular user and get user id 
  */ 
 public function getVehicaldDetailsUserWise(){
     $userId = file_get_contents('php://input');
     $SQL = "SELECT * FROM `assignvehical` WHERE `FIND_IN_SET`('$userId',`user_id`);";
     $query = $this->db->query($SQL);
     $result = $query->result_array();
     $deviceData = array();
     foreach($result as $key=>$value){
          $deviceId = $value['device_id']; 
          $deviceDetails = $this->db->get_where('devicedetails',array('id'=>$deviceId))->row_array(); 
          if($deviceDetails){
            $deviceData[] = $deviceDetails;  
          }
     }
     //die;
     print_r(json_encode($deviceData));
 }
 
 /*
  * for getall vehical
  * working or not working both showing here
  */
 public function getAllVehical(){
     $sql = "SELECT EmployeeName, PositionName, GroupName FROM Employees E";
 }
        
        
        

}
?>