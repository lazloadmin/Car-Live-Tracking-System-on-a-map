<?php

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->library('email');
        // $this->load->database();
        $this->load->model('Home_m');
    }

    /*
     * for view login page 
     */

    public function index() {
       $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
		//$result  =  $this->db->get_where('sitesetting', array('status'=>'Active'));
		//print_r($result); die;
		
        //$res1 =  $this->db->get_where('banner', array('status'=>'Active'))->result_array();
        $pageData['sitesetting'] =  $res[0];
        $pageData['banner'] =  $this->db->get_where('banner', array('status'=>'Active'))->result_array();
         //print_r($pageData); die;
        
        $this->load->view('frontdashboard/header');
        $this->load->view('frontdashboard/dashboard',$pageData);
        $this->load->view('frontdashboard/footer');
    }
    
    /*
     * for about us page 
     */
    
    public function about(){
        $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
        //$res1 =  $this->db->get_where('banner', array('status'=>'Active'))->result_array();
        $pageData['sitesetting'] =  $res[0];
         $this->load->view('frontdashboard/header');
         $this->load->view('frontdashboard/about',$pageData);
         $this->load->view('frontdashboard/footer');
    }
    
    /*
     * for gps system page 
     */
    public function gpsSystem(){
         $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
         $pageData['sitesetting'] =  $res[0];
         $this->load->view('frontdashboard/header');
         $this->load->view('frontdashboard/gpsSystem',$pageData);
         $this->load->view('frontdashboard/footer');
    }
    
    /*
     * for Faq page
     */
    
    public function Faq(){
         $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
         $pageData['sitesetting'] =  $res[0];
         $this->load->view('frontdashboard/header');
         $this->load->view('frontdashboard/Faq',$pageData);
         $this->load->view('frontdashboard/footer');
    }
    /*
     * for contact page 
     */
    public function Contact(){
         $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
         $pageData['sitesetting'] =  $res[0];
         $this->load->view('frontdashboard/header');
         $this->load->view('frontdashboard/Contact',$pageData);
         $this->load->view('frontdashboard/footer');
    }
    /*
     * for support page
     */
    public function Support(){
         $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
         $pageData['sitesetting'] =  $res[0];
         $this->load->view('frontdashboard/header');
         $this->load->view('frontdashboard/Support',$pageData);
         $this->load->view('frontdashboard/footer');
    }
    
    
    /*
     * for admin login
     */
     public function admin() {
        $this->load->view('login');
    }

    /*
     * for user login
     * check if user exist then show user login 
     */

    public function userLogin() {
        $username = $this->input->post('userId');
        $password = md5($this->input->post('password'));
        $result = $this->Home_m->login($username, $password);
        $type = $result['type'];
        if ($result) {
            $userSessiondata = array($type => array('username' => $result['username'],
                    'status' => $result['status'],
                    'id' => $result['id'],
                    'login' => TRUE
                )
            );
        }
        //$this->session->set_userdata('login', $userSessiondata);
         $this->session->set_userdata($userSessiondata);
       //echo '<pre>';  print_r($this->session->userdata['login']['admin']['username']); die;
        if ($type == 'admin') {
            $this->session->set_flashdata('flash_message', 'login Sucessfull');
            redirect('index.php/Dashboard/admin', 'refresh');
        }else if($type == 'superadmin'){
             $this->session->set_flashdata('flash_message', 'login Sucessfull');
             redirect('index.php/SuperAdminDashboard/SuperAdmin', 'refresh');
        }
        else {
            $this->session->set_flashdata('permission_message', 'username and Password is invalid');
            redirect('index.php/Home/admin', 'refresh');
        }
    }

    /*
     * this is function logout for admin
     * if super admin login then redirect to superadmin dashboard
     * if admin logout then redirect to home admin dashboard
     */
    public function logout() {
        //  echo '<pre>'; print_r($_SESSION['admin']);  
        //  echo '<pre>'; print_r($_SESSION['superadmin']);
        //print_r($_SESSION['superadmin']); die;
        //$this->session->unset_userdata($sessiondata);
        $this->session->unset_userdata('admin'); 
       // $this->session->unset_userdata();
       if($_SESSION['superadmin']){
           //$this->session->set_flashdata('flash_message', 'Logout sucessfull.');
           redirect('index.php/SuperAdminDashboard/SuperAdmin', 'refresh');
       }else{
           $this->session->set_flashdata('flash_message', 'Logout sucessfull.');
           redirect('index.php/Home/admin', 'refresh');
       }
    }
    
     public function superadminlogout() {
       //echo '<pre>'; print_r($_SESSION['admin']);  
       //print_r($_SESSION['superadmin']); die;
       //$this->session->unset_userdata($sessiondata);
        $this->session->unset_userdata('superadmin'); 
       // $this->session->unset_userdata();
        $this->session->set_flashdata('flash_message', 'Logout sucessfull.');
        redirect('index.php/Home/admin', 'refresh');
    }
    
    /*
     * for payment page
     */
    public function payment($par1=''){
        if($par1=='fail'){
           //echo "your teansaction is  failed"; 
           $pageData['fail'] = "your teansaction is  failed";
        }
        
        $res =  $this->db->get_where('sitesetting', array('status'=>'Active'))->result_array();
        //$res1 =  $this->db->get_where('banner', array('status'=>'Active'))->result_array();
        $pageData['sitesetting'] =  $res[0];
        $pageData['banner'] =  $this->db->get_where('banner', array('status'=>'Active'))->result_array();
        $this->load->view('frontdashboard/header');
        $this->load->view('frontdashboard/payment',$pageData);
        $this->load->view('frontdashboard/footer');
    }
    
    
    
    
    public function payNow($par1=''){
        if($par1=='create'){
            $data['user_name'] = $this->input->post('name');
            $data['email'] = $this->input->post('email');
            $data['phone'] = $this->input->post('phone');
            $data['product_info'] = $this->input->post('productinfo');
            $data['amount'] = $this->input->post('amount');
            $data['pay_date'] = date('Y-m-d H:i:s');
            $data['date'] = date('Y-m-d H:i:s');
            $data['status'] = 'pending';
            $data['order_id'] = $this->input->post('txnid');
            $res =  $this->db->insert('payment',$data);
          // echo $this->db->last_query();
            
        }
        
        if($par1=='fail'){
            //echo "yor transaction ahs be canceled";
           $txnid=$_POST["txnid"];
           $data['status'] = 'failed';
           $this->db->where('order_id',$txnid);
           $this->db->update('payment',$data);
           
           $this->session->set_flashdata('permission_message', 'yor transaction has been canceled');
           redirect('index.php/Home/payment', 'refresh');
        }
        if($par1=='sucess'){
             $txnid=$_POST["txnid"];
             $data['status'] = 'sucess';
             $this->db->where('order_id',$txnid);
             $this->db->update('payment',$data);
             $this->session->set_flashdata('flash_message', 'Your Payment transaction Is Sucess');
             redirect('index.php/Home/payment', 'refresh'); 
        }
         
    }
    
    /*
     * for sending email
     */
    public function sendEmail(){
       $name = $this->input->post('name');
       $email = $this->input->post('email');
       $phone = $this->input->post('phone');
       $message = $this->input->post('message');
       $emailtemplate .=  'Name : '.$name;
       $emailtemplate .=  'Email : '.$email;
       $emailtemplate .=  'Phone : '.$phone;
       $emailtemplate .=  'Message : '.$message;
       
       $emailfrom = 'vts24@vts24.in' ;
            //$url = base_url() . "Home/verify_user/vrf_mail/" . $vcode;
       $this->email->from($emailfrom, 'Worldtrack');
       $this->email->to('gps.worldtrack@gmail.com');
       $this->email->subject('Contact Us');
       $this->email->message($emailtemplate);
       $res = $this->email->send();
       if($res){
       $this->session->set_flashdata('flash_message', 'Send mail sucessfully');
       redirect('index.php/Home/Contact', 'refresh');
       }else{
           $this->session->set_flashdata('permission_message', 'Email not send. some error');
           redirect('index.php/Home/Contact', 'refresh');
       }
       
    }
    

}

?>