<?php

class SuperAdminDashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->helper('html');
        $this->load->model('SuperAdminDashboard_m');
         if (!$this->session->userdata['superadmin']) {
            $this->session->set_flashdata('permission_message', 'log_again');
            redirect('index.php/Home/admin', 'refresh');
        }

    }

    /*
     * for view login page 
     */

    public function index() {
        //$this->load->view('login');
         $this->load->view('superadmin/header');
        $this->load->view('superadmin/dashboard');
        $this->load->view('superadmin/footer');
    }
    
    

    /*
     * for user login
     * check if user exist then show user login 
     */

    public function SuperAdmin() {
        
        //$this->load->view('login');
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/dashboard');
        $this->load->view('superadmin/footer');
    }
    /*
     * for add user
     */
  public function adduser($par1 ='' , $par2 =''){
      $s_id =  $this->session->userdata['superadmin']['id']; 
      $pageData['par1'] = $par1;
      $pageData['portal_user'] = $this->db->get_where('users',array('type'=>'admin'))->result_array();
      $pageData['permission_name'] = $this->db->get_where('permission_name',array('status'=>'Active'))->result_array();
      // echo $this->input->post('type');
      $pageData['pageName'] = 'Super Admin';
      $pageData['Title'] = 'Add Edit User'; 
      $this->load->view('superadmin/header');
      $this->load->view('superadmin/addUser',$pageData);
      $this->load->view('superadmin/footer');
      $this->load->view('model');
  }
  /*
   * for save   user data 
   */
   public function saveUser ($par1='',$par2=''){
       $s_id =  $this->session->userdata['superadmin']['id']; 
       $data['username'] = $this->input->post('username');
       if($this->input->post('password')){
       $data['password'] = md5($this->input->post('password'));
       }
       $data['permission'] = $this->input->post('permission_id');  
       $data['email'] = $this->input->post('email');
       $data['phone'] = $this->input->post('phone');
       $data['address'] = $this->input->post('address');
       $data['gender'] = $this->input->post('gender');
       $data['s_id'] =   $s_id;
       $data['status'] = $this->input->post('status');
       $data['added_date'] = date('Y-m-d H:i:s');
       $data['type'] = 'admin';
       
       if($par1=='create'){
           //print_r($data);
           $this->db->insert('users',$data);
           $this->session->set_flashdata('flash_message', 'Insert  sucessfully');
          redirect('index.php/SuperAdminDashboard/addUser', 'refresh');
       }else if($par1=='edit'){
             $id = $this->input->post('hid');
             $this->db->where('id', $id);
             $this->db->update('users',$data);
             $this->session->set_flashdata('flash_message', 'Update  sucessfully');
            redirect('index.php/SuperAdminDashboard/addUser', 'refresh');
        } else if($par1 == 'delete'){
             $id = $this->input->post('id');
             $this->db->where('id', $id);
             $this->db->delete('users');
             $this->session->set_flashdata('flash_message', 'Delete  sucessfully');
            redirect('index.php/SuperAdminDashboard/addUser', 'refresh');
        }
       
   }
 
   
   /***********Site Setting menu start here**********************/
   
    /*
     * for add banner manage by admin only show page 
     */
    public function addBanner($par1=''){
        $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] =  $par1;
        $pageData['banner'] = $this->db->get('banner')->result_array();
        $pageData['pageName'] = 'Admin'; 
        $pageData['Title'] = 'Manage Banner'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/manageBanner' , $pageData);
        $this->load->view('superadmin/footer');
    }
    
    /*
     * add banner from data base
     * if param1 = create then save the data base 
     * if param1  edit then update the database
     */
    public function addBannerFinal($param1='', $param2=''){
          $s_id =  $this->session->userdata['superadmin']['id']; 
        
          
           if($param1 == 'edit' ||  $param1 == 'create'){
            $data['name'] = $this->input->post('name');
            $data['title'] = $this->input->post('title');
            $data['status'] = $this->input->post('status');
            $data['heading1'] = $this->input->post('heading1');
            $data['heading2'] = $this->input->post('heading2');
            $data['heading3'] = $this->input->post('heading3');
            $data['description'] = $this->input->post('description');
            
            
            $data['s_id'] =   $s_id;
            // for image upload 
            if($_FILES['image']['name']){
            $errors= array();
            $random = substr(number_format(time() * rand(),0,'',''),0,5);
            $file_name = $random.$_FILES['image']['name']; 
            $file_size =$_FILES['image']['size'];
            $file_tmp =$_FILES['image']['tmp_name'];
            $file_type=$_FILES['image']['type'];
           
            $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
            $expensions= array("jpeg","jpg","png"); 
            if(in_array($file_ext,$expensions)=== false){
             //$errors[]="extension not allowed, please choose a JPEG or PNG file.";
            $this->session->set_flashdata('permission_message', 'extension not allowed, please choose a JPEG or PNG file.');
            redirect('index.php/SuperAdminDashboard/addBanner', 'refresh');
            }
           
            move_uploaded_file($file_tmp,"uploads/".$file_name);
            $data['image'] =  $file_name;
             }
           }
   
            
            
        if($param1 == 'create'){
           
            $this->db->insert('banner',$data);
            $this->session->set_flashdata('flash_message', 'Insert  Sucessfully');
            redirect('index.php/SuperAdminDashboard/addBanner', 'refresh');
//          $this->session->set_flashdata('permission_message', 'username and Password is invalid');
//          redirect('Home/index', 'refresh');
        }
       if($param1 == 'edit'){
             $id = $this->input->post('hid');
             $this->db->where('id', $id);
             $this->db->update('banner',$data);
             $this->session->set_flashdata('flash_message', 'Update  Sucessfully');
             redirect('index.php/SuperAdminDashboard/addBanner', 'refresh');
        }
        if($param1=='delete'){
            //$id = $param2;
            $id = $this->input->post('id');
            
            $this->db->where('id', $id);
            $this->db->delete('banner');
            $this->session->set_flashdata('flash_message', 'Delete  Sucessfully');
            redirect('index.php/SuperAdminDashboard/addBanner', 'refresh');
            
        }
    }

    /*
     *  live chat page and live chat show list
     */
    public function addLiveChat($param1=''){
         $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] = $param1; 
        $pageData['sitesetting'] = $this->db->get('sitesetting')->result_array();
        $pageData['pageName'] = 'Admin'; 
        $pageData['Title'] = 'Add/Edit Live Chat'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/addLiveChat' , $pageData);
        $this->load->view('superadmin/footer');
    }
    /*
     * add edit live chat
     */
   public function addEditLiveChatFinal($param1='', $param2=''){
        $s_id =  $this->session->userdata['superadmin']['id']; 
       $data['livechat'] = $this->input->post('liveChat');
       $data['status'] = $this->input->post('status'); 
       $data['title'] = $this->input->post('title'); 
       $data['s_id'] =   $s_id;
       
       if($param1=='create'){
           $this->db->insert('sitesetting',$data);
           $this->session->set_flashdata('flash_message', 'Insert  Sucessfully');
           redirect('index.php/SuperAdminDashboard/addLiveChat', 'refresh');
       }
       if($param1=='edit'){
           $id = $this->input->post('hid');
           $this->db->where('id',$id);
           $this->db->update('sitesetting',$data);
           $this->session->set_flashdata('flash_message', 'Update Sucessfully');
           redirect('index.php/SuperAdminDashboard/addLiveChat', 'refresh');
       }
       if($param1=='delete'){
           $id = $this->input->post('id');
           $this->db->where('id',$id);
           $this->db->delete('sitesetting');
           $this->session->set_flashdata('flash_message', 'Delete Sucessfully');
           redirect('index.php/SuperAdminDashboard/addLiveChat', 'refresh');
       }
       
       
   }
   
   
   /*
    * for show payment Transaction
    */
   public function paymentTransaction(){
       
        $where = '(status="failed" or status = "sucess")';
        $this->db->where($where);
        $pageData['payment'] = $this->db->get('payment')->result_array();
        $pageData['pageName'] = 'Super Admin'; 
        $pageData['Title'] = 'Payment Transaction'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/paymentTransaction' , $pageData);
        $this->load->view('superadmin/footer');
   }
   
   /*
    * add device type
    */
   public function addDeviceType($par1='',$par2=''){
        $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] =  $par1;
        $pageData['devicetype'] = $this->db->get('devicetype')->result_array();
        $pageData['pageName'] = 'Super Admin'; 
        $pageData['Title'] = 'Add Device Type'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/deviceType' , $pageData);
        $this->load->view('superadmin/footer');
        $this->load->view('model');
   }
   
  
   
   
   
   /*
    * for add and edit device type 
    * and delete device type 
    */
    public function addDeviceTypeFinal($par1='',$par2=''){
        
        $s_id =  $this->session->userdata['superadmin']['id']; 
        if($par1=='create' || $par1=='edit'){
        $data['displayname'] = $this->input->post('displayname'); 
        $data['ip'] = $this->input->post('ipaddress'); 
        $data['port'] = $this->input->post('port'); 
        $data['description'] = $this->input->post('description'); 
        $data['status'] = $this->input->post('status');
        if($data['status']==''){
             $data['status'] = 'Deactivated';
        }
        $data['date'] =  date('Y-m-d H:i:s');
        $data['s_id'] = $s_id;
        
        
        if($_FILES['image']['name']){
            $errors= array();
            $random = substr(number_format(time() * rand(),0,'',''),0,5);
            $file_name = $random.$_FILES['image']['name']; 
            $file_size =$_FILES['image']['size'];
            $file_tmp =$_FILES['image']['tmp_name'];
            $file_type=$_FILES['image']['type'];
           
            $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
            $expensions= array("jpeg","jpg","png"); 
            if(in_array($file_ext,$expensions)=== false){
             //$errors[]="extension not allowed, please choose a JPEG or PNG file.";
            $this->session->set_flashdata('permission_message', 'extension not allowed, please choose a JPEG or PNG file.');
            redirect('index.php/SuperAdminDashboard/addBanner', 'refresh');
            }
           
            move_uploaded_file($file_tmp,"uploads/device/".$file_name);
            $data['image'] =  $file_name;
             }
             
            if($par1=='create'){
            $this->db->insert('devicetype',$data);
            $this->session->set_flashdata('flash_message', 'Insert Sucessfully');
            redirect('index.php/SuperAdminDashboard/addDeviceType', 'refresh');
            }
            
            if($par1 == 'edit'){
             $id = $this->input->post('hid');
             $this->db->where('id', $id);
             $this->db->update('devicetype',$data);
             $this->session->set_flashdata('flash_message', 'Update Sucessfully');
             redirect('index.php/SuperAdminDashboard/addDeviceType', 'refresh');
            }
        }
         if($par1=='delete'){
            //$id = $param2;
            $id = $this->input->post('id');
            
            $this->db->where('id', $id);
            $this->db->delete('devicetype');
            $this->session->set_flashdata('flash_message', 'Delete  Sucessfully');
            redirect('index.php/SuperAdminDashboard/addDeviceType', 'refresh');
            
        }
        
        
    }
    
     /*
    * for add simOperator
    */
   public function simOperator($par1='',$par2=''){
        $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] =  $par1;
        $pageData['simoperator'] = $this->db->get('simoperator')->result_array();
        $pageData['pageName'] = 'Super Admin'; 
        $pageData['Title'] = 'Add Sim Operator'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/simOperator' , $pageData);
        $this->load->view('superadmin/footer');
        $this->load->view('model');
   }
   
    
    /*
    * sim operator add final 
    */
   public function simOperatorFinal($par1='', $par2=''){
       $s_id =  $this->session->userdata['superadmin']['id']; 
       $data['name'] = $this->input->post('name');
       $data['status'] = $this->input->post('status');
       if( $data['status']==''){
           $data['status'] = 'Deactivated'; 
       }
       $data['apn'] = $this->input->post('apn');
       $data['date'] = date('Y-m-d H:i:s');
       $data['s_id'] = $s_id;
       
           if($par1=='create'){
            $this->db->insert('simoperator',$data);
            //echo $this->db->last_query(); die;
            $this->session->set_flashdata('flash_message', 'Insert Sucessfully');
            redirect('index.php/SuperAdminDashboard/simOperator', 'refresh');
            }
            
            if($par1 == 'edit'){
             $id = $this->input->post('hid');
             $this->db->where('id', $id);
             $this->db->update('simoperator',$data);
             $this->session->set_flashdata('flash_message', 'Update Sucessfully');
             redirect('index.php/SuperAdminDashboard/simOperator', 'refresh');
            }
            
            if($par1=='delete'){
            //$id = $param2;
            $id = $this->input->post('id');
            
            $this->db->where('id', $id);
            $this->db->delete('simoperator');
            $this->session->set_flashdata('flash_message', 'Delete  Sucessfully');
            redirect('index.php/SuperAdminDashboard/simOperator', 'refresh');
          }
       
       
   }
   
    /*
    * for add Vehical Type vehicaltype
    */
   public function addVehicalType($par1='',$par2=''){
        $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] =  $par1;
        $pageData['vehicaltype'] = $this->db->get('vehicaltype')->result_array();
        $pageData['pageName'] = 'Super Admin'; 
        $pageData['Title'] = 'Add Vehical Type'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/vehicalType' , $pageData);
        $this->load->view('superadmin/footer');
        $this->load->view('model');
   }
   
    /*
    * sim operator add Vehical Final
    */
   public function addVehicalTypeFinal($par1='', $par2=''){
       $s_id =  $this->session->userdata['superadmin']['id']; 
       $data['vehicalname'] = $this->input->post('vehicalname');
       $data['status'] = $this->input->post('status');
       if( $data['status']==''){
           $data['status'] = 'Deactivated'; 
       }
       $data['date'] = date('Y-m-d H:i:s');
       $data['s_id'] = $s_id;
       
           if($par1=='create'){
            $this->db->insert('vehicaltype',$data);
            //echo $this->db->last_query(); die;
            $this->session->set_flashdata('flash_message', 'Insert Sucessfully');
            redirect('index.php/SuperAdminDashboard/addVehicalType', 'refresh');
            }
            
            if($par1 == 'edit'){
             $id = $this->input->post('hid');
             $this->db->where('id', $id);
             $this->db->update('vehicaltype',$data);
             $this->session->set_flashdata('flash_message', 'Update Sucessfully');
             redirect('index.php/SuperAdminDashboard/addVehicalType', 'refresh');
            }
            
            if($par1=='delete'){
            //$id = $param2;
            $id = $this->input->post('id');
            
            $this->db->where('id', $id);
            $this->db->delete('vehicaltype');
            $this->session->set_flashdata('flash_message', 'Delete  Sucessfully');
            redirect('index.php/SuperAdminDashboard/addVehicalType', 'refresh');
          }
       
       
   }
   
   
   
/*
 * for particular admin login 
 * login by super admin 
 * when super admin login then change the session admin
 * to current get record by admin login
 */
   public function adminLogin($par1=''){
       $result = $this->db->get_where('users', array('id'=>$par1))->result_array();
       //echo '<pre>'; print_r($result[0]);
       $userSessiondata = array('admin' => array('username' => $result[0]['username'],
                    'status' => $result[0]['status'],
                    'id' => $result[0]['id'],
                    'login' => TRUE
                ));
       //$data['admin'] = 
       $this->session->set_userdata($userSessiondata);
      $this->session->set_flashdata('flash_message', 'login Sucessfull');
      redirect('index.php/Dashboard/admin', 'refresh');
       
       
   }
   /*
    * for add user permission
    * if $par1 = create then add 
    * if $par1= edit thwen update 
    * if $par1 =  delete the delete permission
    */
   
   public function addPermission($par1='',$par2=''){
      // echo "hhh"; die;
        $pageData['par1']= $par1;
       $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['permission_name']= $this->db->get_where('permission_name', array('s_id'=>$s_id))->result_array();
        $pageData['Title'] = 'Add Permission'; 
        $pageData['pageName'] = 'Super Admin'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/addPermission' , $pageData);
        $this->load->view('superadmin/footer');
   }
   
    /*
    * for add user permission
    * if $par1 = create then add 
    * if $par1= edit thwen update 
    * if $par1 =  delete the delete permission
    */
   public function addPermissionFinal($par1='',$par2=''){
      //echo '<pre>';  print_r($_POST);
       $data['name'] = $this->input->post('name');
       $data['status'] = $this->input->post('status');
       if($this->input->post('status')==''){
           $data['status'] = 'Deactivated';
       }
       $data['date'] = date('Y-m-d H:i:s');
       $data['s_id'] =  $this->session->userdata['superadmin']['id']; 
       if($par1=='create'){
           $this->db->insert('permission_name',$data);
           $this->session->set_flashdata('flash_message', 'Insert Sucessfully');
           redirect('index.php/SuperAdminDashboard/addPermission', 'refresh');
       }if($par1=='edit'){
            //echo "kkk"; die;
           $id = $this->input->post('hid');
           $this->db->where('id',$id);
           $this->db->update('permission_name',$data);
           $this->session->set_flashdata('flash_message', 'Update Sucessfully');
           redirect('index.php/SuperAdminDashboard/addPermission', 'refresh');
       }if($par1=='delete'){
           $id = $this->input->post('id');
           $this->db->where('id',$id);
           $this->db->delete('permission_name');
           $this->session->set_flashdata('flash_message', 'Delete Sucessfully');
           redirect('index.php/SuperAdminDashboard/addPermissionFinal', 'refresh');
       }
       
       
   }
   
   /*
    * for Showing view permission 
    */
   public function viewPermission(){
        echo "ViewPermission module";
   }
    /*
    * for Showing view assign permission 
    */
   public function assignPermission($par1='', $par2='',$par3=''){
       
        $s_id =  $this->session->userdata['superadmin']['id']; 
        $pageData['par1'] = $par1;
        $pageData['permission_name'] = $this->db->get_where('permission_name',array('status'=>'Active'))->result_array();
        $pageData['permission'] = $this->SuperAdminDashboard_m->getPermissionList();
      //echo '<pre>';  print_r( $pageData['permission']); die;
        $pageData['Title'] = 'Assign Permission'; 
        $pageData['pageName'] = 'Super Admin'; 
        $this->load->view('superadmin/header');
        $this->load->view('superadmin/assignPermission' , $pageData);
        $this->load->view('superadmin/footer');
   }
   public function assignPermissionFinal($par1='', $par2='',$par3=''){
       
       // for checking permission listexist or not exist
       $result = $this->SuperAdminDashboard_m->checkPermissionList($this->input->post('permission_name')); 
      //echo '<pre>'; print_r($_POST);
       $data['status'] = $this->input->post('status');
       if($this->input->post('status')==''){
           $data['status'] = 'Deactivated';
       }
       $data['permission_id']= $this->input->post('permission_name');
       $module_function_name = $this->input->post('module_function_name');
       $module = '';
       foreach($module_function_name as $key=>$value){
           $module.= $value.','; 
       }
       $module =  substr(trim($module), 0, -1);
       $data['module_function_name'] = $module; 
       $data['date'] = date('Y-m-d H:i:s'); 
       //echo '<pre>'; print_r($data); 
        if($par1=='create'){
            if($result){
           $this->session->set_flashdata('permission_message', 'this permission is allready exist');
           redirect('index.php/SuperAdminDashboard/assignPermission', 'refresh');
           }else{
           $this->db->insert('permission',$data);
           $this->session->set_flashdata('flash_message', 'Insert Sucessfully');
           redirect('index.php/SuperAdminDashboard/assignPermission', 'refresh');
           }
       }if($par1=='edit'){
            //echo "kkk"; die;
            
           $id = $this->input->post('hid');
           $this->db->where('id',$id);
           $this->db->update('permission',$data);
           $this->session->set_flashdata('flash_message', 'Update Sucessfully');
           redirect('index.php/SuperAdminDashboard/assignPermission', 'refresh');
          
       }if($par1=='delete'){
           $id = $this->input->post('id');
           $this->db->where('id',$id);
           $this->db->delete('permission');
           $this->session->set_flashdata('flash_message', 'Delete Sucessfully');
           redirect('index.php/SuperAdminDashboard/assignPermission', 'refresh');
       }
       //print_r($data);
   }
   
   
   
   
   
}

?>