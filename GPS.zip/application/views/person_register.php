<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>Client Registration</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
	<meta name="description" content="">
	<meta name="author" content="">
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/cloud-admin.css" >
	<link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>assets/css/themes/default.css" id="skin-switcher" >
	<link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>assets/css/responsive.css" >
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/bootstrap-daterangepicker/daterangepicker-bs3.css" />
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
</head>

</head>
<body>
	 <header class="navbar clearfix" id="header">
		<div class="container">
				<div class="navbar-brand">
					
					<a href="#">
                                            <img src="<?php echo base_url(); ?>assets/img/logo.png" alt=" " class="img-responsive">
					</a>
					
					<div id="sidebar-collapse" class="sidebar-collapse btn">
						<i class="fa fa-bars" 
							data-icon1="fa fa-bars" 
							data-icon2="fa fa-bars" ></i>
					</div>
				
				</div>				
				
		</div>
	</header>
	
	<section id="page">

            <div id="main-content" style="margin-left: 0px;">
			<div class="container">
				<div class="row">
					<div id="content" class="col-lg-12">
						<!-- PAGE HEADER-->
						<div class="row">
							<div class="col-sm-12">
								<div class="page-header">
									<!-- BREADCRUMBS -->
									<ul class="breadcrumb">
										<li>
											<i class="fa fa-home"></i>
											<a href="#">Home</a>
										</li>										
										<li><?php echo $page_name;?></li>
									</ul>
									<!-- /BREADCRUMBS -->
									<div class="clearfix">
										<h3 class="content-title pull-left"><?php echo $page_title; ?></h3>
								</div>
							</div>
						</div>
						<!-- /PAGE HEADER -->
        <div class="col-md-2"></div>
        <div class="col-md-8">
        
        
        <?php if($this->session->flashdata('flash_message')){ ?>
    <div class="alert alert-block alert-success fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
    </div>
    <? }
     if($this->session->flashdata('permission_message')){ ?>
    <div class="alert alert-block alert-warning fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
    </div>
    <? }?>
        
        
        <?php echo form_open('Home/person_register_setting/create' , array('id' => 'usersForm1', 'class' => 'form-horizontal'));?>
           
    
          <!-- <div class="form-group">
                  <label class="col-sm-4 control-label">Contact Person *</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="contact_person" data-validation="required" placeholder=" Enter Contact  Name" data-validation-error-msg="Please input valid Contact Name">
                 
                  </div>
            </div>-->
           
           
           <div class="form-group">
                  <label class="col-sm-4 control-label">Email :</label>
                  <div class="col-sm-8">
                     <input type="text" class="form-control"  name="email"  data-validation="server" data-validation-url="<?php echo base_url(); ?>Home/chkemail_user"data-validation-error-msg="Please input valid Email" placeholder="Pls Enter Email">
                  </div>
            </div>
           
           
           <!-- 
            <div class="form-group">
                <label class="col-sm-4 control-label">Address line1*</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="line1" data-validation="required" placeholder="Enter Address Line 1" data-validation-error-msg="Please input valid Address Line 1">
               
                </div>
            </div>
            <div class="form-group">
                  <label class="col-sm-4 control-label">Address line2*</label>
                  <div class="col-sm-8">
                   <input type="text" class="form-control" name="line2"  data-validation="required" placeholder="Enter Address Line 2" data-validation-error-msg="Please input valid Address Line 2">
                  </div>
            </div>
            <div class="form-group">
                  <label class="col-sm-4 control-label">City *</label>
                  <div class="col-sm-8">
                  
                  <select   name="city" class="form-control"  data-validation="required"  data-validation-error-msg="Please select City">
                  <option value=""> Select City</option>
				  <?php foreach ($tblcitylist as $key=>$value)
				  { ?>
                  <option value="<?php echo $value['City_bcty'];  ?>"><?php echo $value['City_bcty']; ?></option>
                  <?php } ?>
                  </select>
                  
                  </div>
            </div>
            <div class="form-group">
                  <label class="col-sm-4 control-label">Country*</label>
                  <div class="col-sm-8">
                   <input type="text" class="form-control" name="country"   data-validation="required"    placeholder="Enter Country Name" data-validation-error-msg="Please input valid Country ">
                  
                  </div>
            </div>
            
            <div class="form-group">
                  <label class="col-sm-4 control-label">Postcode *</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control"  name="postcode"  placeholder=" Enter Postcode"  onkeypress="javascript:return isNumber (event)"  data-validation="required" minlength="4"  maxlength="6"  data-validation-error-msg="Please input valid Postcode"  />
                  
                  </div>
            </div>
            
            
            
            <div class="form-group">
                  <label class="col-sm-4 control-label">Phone  :</label>
                  <div class="col-sm-8">
                    <input type="text" name="phone" class="form-control"  placeholder="Enter Phone Number"    onkeypress="javascript:return isNumber (event)"  data-validation="required"   maxlength="12"  data-validation-error-msg="Please input valid Phone number"/>
                 
                  </div>
            </div>
            -->
            
             <div class="form-group">
                  <label class="col-sm-4 control-label">Password  :</label>
                  <div class="col-sm-8">
                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control"  placeholder="Enter Password" data-validation="strength" data-validation-strength="2" />
                 
                  </div>
            </div>
            
            
            <div class="form-group">
                  <label class="col-sm-4 control-label">Confirm Password  :</label>
                  <div class="col-sm-8">
                    <input type="password"  name="password" id="password" class="form-control"  placeholder="Enter Confirm Password" data-validation="confirmation"  />
                 
                  </div>
            </div>
            
            
            <div class="form-group">
                  <div class="col-sm-offset-4 col-sm-8">
                    <button type="submit" name="submit" class="btn btn-primary btn-lg">SUBMIT</button>
                  </div>
            </div>
         
          <?php echo form_close();?>
        </div>
        <div class="col-md-2"></div>
												
					</div>
				</div>
			</div>
		</div>           
	</section>


</body>
</html>
