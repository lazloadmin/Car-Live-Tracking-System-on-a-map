



    <!--Start of Tawk.to Script-->
<script type="text/javascript">
//var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
//(function(){
//var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
//s1.async=true;
//s1.src='https://embed.tawk.to/582bec5b651e34097a90f68c/default';
//s1.charset='UTF-8';
//s1.setAttribute('crossorigin','*');
//s0.parentNode.insertBefore(s1,s0);
//})();
</script>
<!--End of Tawk.to Script-->

    
<style>

    div.upload {
        width: 157px;
        height: 57px;
        overflow: hidden;
        background-image: url('<?php echo base_url(); ?>/assets/img/upload.png');
    }

    div.upload input {
        display: block !important;
        width: 157px !important;
        height: 57px !important;
        opacity: 0 !important;
        overflow: hidden !important;
    }

</style>

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/SuperAdmin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                       
                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i> Payment list</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <table id="datatable1" cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>User Name</th>
                                                        <th>Transaction Id</th>
                                                        <th>Amount</th>
                                                        <th>Pay Date</th>
                                                        <th>Status</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    if($payment){
                                                        $i = 1;
                                                 
                                                      foreach($payment as $key=>$value){
                                                    ?> 
                                                    <tr>
                                                        <td> <?php echo $i; ?>  </td>
                                                        <td> <?php echo $value['user_name']; ?> </td>
                                                        <td> <?php echo $value['order_id']; ?> </td>
                                                        <td> <?php echo $value['amount']; ?>   </td>
                                                        <td> <?php echo $value['pay_date']; ?>  </td>
                                                        <td> <?php echo $value['status']; ?>  </td>
                                                    
<!--                                                      <a href="<?php echo base_url() . 'Client/discount/edit/' . $tbldiscount1['ID_disc']; ?>">Edit</a>-->
                                                    
                                                    </tr>
                                                      <?php   $i++; } } ?> 

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                       <th>Sr. No.</th>
                                                        <th>User Name</th>
                                                        <th>Transaction Id</th>
                                                        <th>Amount</th>
                                                        <th>Pay Date</th>
                                                        <th>Status</th>

                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>           
</section>
                
                
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
       // for delete item from list
        $(".fa-trash-o1").click(function(e) {
         var conf = confirm("Are you sure want to delete!");
    if(conf==true){
        var id = this.id;
        $.ajax({
         url: '<?php echo base_url(); ?>index.php/SuperAdminDashboard/addBannerFinal/delete',
           type:"POST",
            data:{'id':id,
              },
            success: function(response)
            {
                location.reload();
            }
         });
      }

    });


    });
    </script>

