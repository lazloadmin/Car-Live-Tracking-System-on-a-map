<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title> Super Admin </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
        <meta name="description" content="">
        <meta name="author" content="">





<!-- STYLESHEETS --><!--[if lt IE 9]><script src="js/flot/excanvas.min.js"></script><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/cloud-admin.css" >
        <link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>assets/css/themes/default.css" id="skin-switcher" >
        <link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>assets/css/responsive.css" >
        <link rel="stylesheet" type="text/css"  href="<?php echo base_url(); ?>assets/css/extra.css" >




        <!--jquery plugin start -->
        <script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>
        <!--jquery plugin End-->



        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" />
        <link href="<?php echo base_url(); ?>poss_user/css/style.css" rel="stylesheet" />
        <link href="<?php echo base_url(); ?>poss_user/css/style12.css" rel="stylesheet" />
        <!--   START DATEtimepicker FUNCTION  -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datetimepicker-master/jquery.datetimepicker.css"/>

        <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- DATE RANGE PICKER -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/bootstrap-daterangepicker/daterangepicker-bs3.css" />
        <!-- FONTS -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    </head>
    <body >
        <!-- HEADER -->
        <header class="navbar clearfix" id="header">
            <div class="container">
                <div class="navbar-brand">
                    <!-- COMPANY LOGO -->

                    <a href="#" style="color:#FFF; text-decoration:none; margin-left:50px;">
                        World Track
                    </a>
                    <!-- SIDEBAR COLLAPSE -->
                    <div id="sidebar-collapse" class="sidebar-collapse btn">
                        <i class="fa fa-bars" 
                           data-icon1="fa fa-bars" 
                           data-icon2="fa fa-bars" ></i>
                    </div>
                    <!-- /SIDEBAR COLLAPSE -->
                </div>				
                <!-- BEGIN TOP NAVIGATION MENU -->					
                <ul class="nav navbar-nav pull-right">
                    <!-- BEGIN USER LOGIN DROPDOWN -->
                    <li class="dropdown user" id="header-user">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img alt="" src="<?php echo base_url(); ?>assets/img/avatars/avatar3.jpg" />
                            <span class="username"><?php echo $this->session->userdata['superadmin']['username']; ?> </span>
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu">

                            <li><a href="<?php echo base_url(); ?>index.php/Home/superadminlogout"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- END USER LOGIN DROPDOWN -->
                </ul>
                <!-- END TOP NAVIGATION MENU -->
            </div>
        </header>
        <section id="page">
            <!-- SIDEBAR -->
            <div id="sidebar" class="sidebar">
                <div class="sidebar-menu nav-collapse">
                    <!-- SIDEBAR MENU -->
                    <ul>
                        <li>
                            <a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/SuperAdmin"> <i class="fa fa-desktop fa-fw"></i> <span class="menu-text">Dashboard</span> </a>
                        </li>

                        <!--user Managent menu-->
                        <li class="has-sub">
                            <a href="javascript:;" class="">
                                <i class="fa fa-users"></i> <span class="menu-text">User Management</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub">
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/adduser">Add/Edit User</a></li>
<!--                                <li><a href="<?php echo base_url(); ?>index.php/Dashboard/MobileAppUser">Mobile App Users</a></li>
                                <li><a href="#">Main User Details</a></li>
                                <li><a href="#">Barred User Details</a></li>-->
                            </ul>
                        </li>

                        <!--                        Device Management Menu
                                                <li class="has-sub">
                                                    <a href="javascript:;" class="">
                                                        <i class="fa fa-cog"></i> <span class="menu-text">Device Management</span>
                                                        <span class="arrow"></span>
                                                    </a>
                                                    <ul class="sub">
                                                        <li><a href="#">Add/Edit Device Details</a></li>
                                                        <li><a href="#"> Barred Device Details</a></li>
                                                        <li><a href="<?php echo base_url(); ?>index.php/Dashboard/vehicalAllocation">Vehicle Allocation</a></li>
                                                    </ul>
                                                </li>
                                                
                                                Reports Menu 
                                                <li class="has-sub">
                                                    <a href="javascript:;" class="">
                                                        <i class="fa fa-download"></i> <span class="menu-text">Reports</span>
                                                        <span class="arrow"></span>
                                                    </a>
                                                    <ul class="sub">
                                                        <li><a href="#">Device Added  Details</a></li>
                                                        <li><a href="#">Unknown Vehicles</a></li>
                                                        <li><a href="#">Alert Log</a></li>
                                                        <li><a href="#">Vehicle Specific Details</a></li>
                                                        <li><a href="#">Sim Operator Details</a></li>
                                                    </ul>
                                                </li>
                                                
                                                Advance Setting Menu 
                                                <li class="has-sub">
                                                    <a href="javascript:;" class="">
                                                        <i class="fa fa-cogs"></i> <span class="menu-text">Advance Setting</span>
                                                        <span class="arrow"></span>
                                                    </a>
                                                    <ul class="sub">
                                                        <li><a href="#">User Credential</a></li>
                                                        <li><a href="#">Authorized Setting</a></li>
                                                        <li><a href="#">Fuel Caliberation </a></li>
                                                        <li><a href="#">  SMS Allocation </a></li>
                                                    </ul>
                                                </li> -->




                        <li class="has-sub">
                            <a href="javascript:;" class="">
                                <i class="fa fa-cogs"></i> <span class="menu-text">Permissions</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub">
<!--                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/viewPermission">View Permission</a></li>-->
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/addPermission">Add Permission</a></li>
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/assignPermission">Assign Permission</a></li>
                               
                            </ul>
                        </li>

                        <!--                        Admin Menu-->
                        <li class="has-sub">
                            <a href="javascript:;" class="">
                                <i class="fa fa-credit-card"></i> <span class="menu-text">Site Settings</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub">
                                <li><a href="<?php echo base_url(); ?>index.php/Dashboard/mobilePortalFeature"> Mobile Portal Features</a></li>
                               
                                <li><a href="#"> Remove Devices</a></li>
                                <li><a href="#"> Menu Allocation</a></li>
                                 <li><a href="<?php echo base_url(); ?>index.php/Dashboard/employeeManagement">Employee Management </a></li>
                                <li><a href="#"> Send Message</a></li>
                                <li><a href="#"> Update Distance </a></li>
                              
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/addBanner"> Banner Manage </a></li>
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/addLiveChat"> Add/Edit Live Chat </a></li>
                                <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/paymentTransaction"> Payment Transaction </a></li>
                              <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/addDeviceType"> Device Type </a></li>
                              <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/simOperator"> Sim Operator </a></li>
                              <li><a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/addVehicalType"> Vehical Type </a></li>
                                
                            </ul>
                        </li>


                    </ul>
                    <!-- /SIDEBAR MENU -->
                </div>
            </div>
            <!-- /SIDEBAR -->