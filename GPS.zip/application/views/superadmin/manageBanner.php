



    <!--Start of Tawk.to Script-->
<script type="text/javascript">
//var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
//(function(){
//var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
//s1.async=true;
//s1.src='https://embed.tawk.to/582bec5b651e34097a90f68c/default';
//s1.charset='UTF-8';
//s1.setAttribute('crossorigin','*');
//s0.parentNode.insertBefore(s1,s0);
//})();
</script>
<!--End of Tawk.to Script-->

    
<style>

    div.upload {
        width: 157px;
        height: 57px;
        overflow: hidden;
        background-image: url('<?php echo base_url(); ?>/assets/img/upload.png');
    }

    div.upload input {
        display: block !important;
        width: 157px !important;
        height: 57px !important;
        opacity: 0 !important;
        overflow: hidden !important;
    }

</style>

<?php
if ($par1) {
    $edit = $this->db->get_where('banner', array('id' => $par1))->row_array();
   // print_r($edit);
    $formaction = 'edit';
} else {
    $formaction = 'create';
}
?>

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/SuperAdmin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Manage Banner</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>

                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <?php
                                            echo form_open_multipart('index.php/SuperAdminDashboard/addBannerFinal/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal'));
                                            ?>
<!--                                            <form  action='Dashboard/addBannerFinal/.$formaction' id="userForm" class="form-horizontal" enctype="multipart"-->


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Title</label>
                                                <div class="col-sm-8">
                                                    <input type="hidden" name="hid" id="hid" value="<?php echo $edit['id']; ?> "/>
                                                    <input type="text" class="form-control datetime1" name="title" id="title" placeholder="Enter title here" value="<?php echo $edit['title']; ?> " />
                                                </div>
                                            </div>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Name</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control datetime1" name="name" id="name" placeholder="Enter name here" value="<?php echo $edit['name']; ?> " />
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Image</label>
                                                <div class="col-sm-8">
<!--                                                    <input type="file" name="image" id="image" value="<?php  echo base_url() ?>/uploads/<?php echo $edit['image'];  ?> "/>-->
                                               <div class="upload"> 
                                                     <input type="file" name="image" id="image" value="<?php echo $edit['image']; ?> "/>
                                                       
                                                   </div>
                                                </div>
                                            </div>

                                           <div class="form-group">
                                                <label class="col-sm-3 control-label">Description</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control datetime1" name="description" id="name" placeholder="Enter description" value="<?php echo $edit['description']; ?> " />
                                                </div>
                                            </div>

                                        <div class="form-group">
                                                <label class="col-sm-3 control-label">Heading1</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control datetime1" name="heading1" id="name" placeholder="Enter Heading Here" value="<?php echo $edit['heading1']; ?> " />
                                                </div>
                                            </div>

                                         <div class="form-group">
                                                <label class="col-sm-3 control-label">Heading2</label>
                                                <div class="col-sm-8">
                                                    <!--<textarea class="form-control datetime1" name="description" placeholder="Enter Description"> <?php echo $edit['description']; ?> </textarea>-->
                                                    <input type="text" class="form-control datetime1" name="heading2" placeholder="Enter Heading Here"   value="<?php echo $edit['heading2']; ?> " />
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Heading3</label>
                                                <div class="col-sm-8">
                                                    <!--<textarea class="form-control datetime1" name="description" placeholder="Enter Description"> <?php echo $edit['description']; ?> </textarea>-->
                                                    <input type="text" class="form-control datetime1" name="heading3" placeholder="Enter Heading Here"   value="<?php echo $edit['heading3']; ?> " />
                                                </div>
                                            </div>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Status</label>
                                                <div class="col-sm-8">
                                                    <input type="checkbox" class="posCheckBox" name ="status" id="status" value="Active" <?php if($edit['status']=='Active'){echo "checked";} ?>  />
                                                </div>
                                            </div>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"></label>
                                                <div class="col-sm-5">
                                                    <div class="input-group">
                                                        <input type="submit" name="sub" value="SAVE" class="btn-primary" style="width: 100px; height: 40px;" />

                                                    </div>
                                                </div>
                                            </div>



                                            <?php
                                            echo form_close();
                                            ?>



                                        </div>





                                    </div>

                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Banner list</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <table id="datatable1" cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Title</th>
                                                        <th>Name</th>
                                                        <th>Image</th>
                                                        <th>status</th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    if($banner){
                                                        $i = 1;
                                                 
                                                      foreach($banner as $key=>$value){
                                                    ?> 
                                                    <tr>
                                                        <td> <?php echo $i; ?>  </td>
                                                        <td> <?php echo $value['title']; ?> </td>
                                                        <td> <?php echo $value['name']; ?> </td>
                                                        <td> <img src="<?php echo base_url().'uploads/'.$value['image']; ?>" style="height:100px; width: 200px;"/>   </td>
                                                        <td> <?php echo $value['status']; ?> </td>
                                                        <td> <a href="<?php echo base_url().'index.php/SuperAdminDashboard/addBanner/'.$value['id'];?>"> <i class="fa fa-edit"></i>  </a>&nbsp;  <i id="<?php echo $value['id'];?> " class="fa fa-trash-o"></i>  </td>
                                                    
<!--                                                      <a href="<?php echo base_url() . 'Client/discount/edit/' . $tbldiscount1['ID_disc']; ?>">Edit</a>-->
                                                    
                                                    </tr>
                                                      <?php   $i++; } } ?> 

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>Sr. No.</th>
                                                    <th>Title</th>
                                                    <th>Name</th>
                                                    <th>Image</th>
                                                    <th>status</th>
                                                    <th>Action</th>

                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>           
</section>
   
                <script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script> 
    <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script>
    $(document).ready(function() {
       // for delete item from list
        $(".fa-trash-o").click(function(e) {
         var conf = confirm("Are you sure want to delete!");
    if(conf==true){
        var id = this.id;
        $.ajax({
         url: '<?php echo base_url(); ?>index.php/SuperAdminDashboard/addBannerFinal/delete',
           type:"POST",
            data:{'id':id,
              },
            success: function(response)
            {
                location.reload();
            }
         });
      }

    });


    });
    </script>

