

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="#">Super Admin </a>
                                </li>										
                                <li>Dashboard</li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left">Dashboard</h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                </div>
                                <? }?>



<!--                                <div class="box border primary">
                                    <div class="box-title">
                                        <h4><i class="fa fa-table"></i>Map</h4>
                                        <div class="tools hidden-xs">
                                            <a href="#box-config" data-toggle="modal" class="config">
                                                <i class="fa fa-cog"></i>
                                            </a>
                                            <a href="javascript:;" class="reload">
                                                <i class="fa fa-refresh"></i>
                                            </a>
                                            <a href="javascript:;" class="collapse">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a href="javascript:;" class="remove">
                                                <i class="fa fa-times"></i>
                                            </a>

                                        </div>
                                    </div>
                                    <div class="box-body">

<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
    <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>
                                    </div>
                                </div>-->

                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>           
</section>
