<style>

    div.upload {
        width: 157px;
        height: 57px;
        overflow: hidden;
        background-image: url('<?php echo base_url(); ?>/assets/img/upload.png');
    }

    div.upload input {
        display: block !important;
        width: 157px !important;
        height: 57px !important;
        opacity: 0 !important;
        overflow: hidden !important;
    }

</style>

<?php
if ($par1) {
    $edit = $this->db->get_where('vehicaltype', array('id' => $par1))->row_array();
   // print_r($edit);
    $formaction = 'edit';
} else {
    $formaction = 'create';
}
?>

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/SuperAdminDashboard/SuperAdmin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Add Vehical Type</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>

                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <?php
                                            echo form_open_multipart('index.php/SuperAdminDashboard/addVehicalTypeFinal/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal'));
                                            ?>
<!--                                            <form  action='Dashboard/addBannerFinal/.$formaction' id="userForm" class="form-horizontal" enctype="multipart"-->


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"> Vehical Name</label>
                                                <div class="col-sm-8">
                                                    <input type="hidden" name="hid" id="hid" value="<?php echo $edit['id']; ?> "/>
                                                    <input type="text" class="form-control" name="vehicalname" id="vehicalname" placeholder="Enter vehical name" value="<?php echo $edit['vehicalname']; ?> " data-validation="required" data-validation-error-msg="Pls Enter Vehical Name"  />
                                                </div>
                                            </div>

                                            
                  
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Status</label>
                                                <div class="col-sm-8">
                                                    <input type="checkbox" class="posCheckBox" name ="status" id="status" value="Active" <?php if($edit['status']=='Active'){echo "checked";} ?>  />
                                                </div>
                                            </div>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"></label>
                                                <div class="col-sm-5">
                                                    <div class="input-group">
                                                        <input type="submit" name="sub" value="SAVE" class="btn-primary" style="width: 100px; height: 40px;" />

                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            echo form_close();
                                            ?>

                                        </div>





                                    </div>

                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Vehical Type list</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <table id="datatable1" cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th> Vehical Name</th>
                                                        <th>status</th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    if($vehicaltype){
                                                        $i = 1;
                                                 
                                                      foreach($vehicaltype as $key=>$value){
                                                    ?> 
                                                    <tr>
                                                        <td> <?php echo $i; ?>  </td>
                                                        <td> <?php echo $value['vehicalname']; ?> </td>
                                                        <td> <?php echo $value['status']; ?> </td>
                                                        <td> <a href="<?php echo base_url().'index.php/SuperAdminDashboard/addVehicalType/'.$value['id'];?>"> <i class="fa fa-edit"></i>  </a>&nbsp;  <i id="<?php echo $value['id'];?> " class="fa fa-trash-o"></i>  </td>
                                                    </tr>
                                                      <?php   $i++; } } ?> 

                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                        <th>Sr. No.</th>
                                                        <th> Vehical Name</th>
                                                        <th>status</th>
                                                        <th>Action</th>

                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>           
</section>
   
                <script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script> 
    <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script>
    $(document).ready(function() {
       // for delete item from list
        $(".fa-trash-o").click(function(e) {
         var conf = confirm("Are you sure want to delete!");
    if(conf==true){
        var id = this.id;
        $.ajax({
         url: '<?php echo base_url(); ?>index.php/SuperAdminDashboard/addVehicalTypeFinal/delete',
           type:"POST",
            data:{'id':id,
              },
            success: function(response)
            {
                location.reload();
            }
         });
      }

    });


    });
    </script>

