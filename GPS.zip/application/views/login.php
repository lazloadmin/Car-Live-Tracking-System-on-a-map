<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>World Track</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Le styles -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/onlinejquery.js"></script>
        <!--  <link rel="stylesheet" href="assets/css/style.css"> -->
        <link href="<?php echo base_url(); ?>assets/css/signin.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
        <link href="<?php echo base_url();?>assets/css/awwward.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/skin-select.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/dipricon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/entypo-icon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/maki-icon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/skin-select.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/jquery-easypiechart.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/jquery-pnotify.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/pacethemecnter.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/slidebars.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/tooltipster.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/number-pb.css">
        <link href="<?php echo base_url();?>assets/css/weather-icon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/open-sans.css" rel="stylesheet">

        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
            <![endif]-->
        <!-- Fav and touch icons -->

    </head>

    <body><div id="awwwards" class="right black"><a href="#" target="_blank">best websites of the world</a></div>
        <!-- Preloader -->
        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>
        <div class="container">
            <div class="" id="login-wrapper">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div id="logo-login">
                            <h1>World Track
                                <span></span>
                            </h1>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="account-box">

                             <?php echo form_open("index.php/Home/userLogin"); ?>
                                
                                 <div class="form-group">
                                     </br>
                                 </div>
                                
                                
                                <div class="form-group">
<!--                                    <a href="#" class="pull-right label-forgot">Forgot email?</a>-->
                                    <label for="inputUsernameEmail">User Id</label>
                                    <input type="text"  name="userId"  id="userId" class="form-control">
                                </div>
                                
                                
                                
                                <div class="form-group">
<!--                                    <a href="#" class="pull-right label-forgot">Forgot password?</a>-->
                                    <label for="inputPassword">Password</label>
                                    <input type="password" name="password" id="password" class="form-control">
                                </div>
                                
                                 <div class="form-group">
                                     </br>
                                </div>
                                
                                <div class="checkbox pull-left">
                                       <label>  <input type="checkbox">Remember me</label>
                                </div>
                                <button class="btn btn btn-primary pull-right" type="submit">
                                    Log In
                                </button>
                                
                                <div class="form-group">
                                     </br>
                                </div>
                               </form>

                        </div>
                    </div>
                </div>
            </div>





            <div style="text-align:center;margin:0 auto;">
                <h6 style="color:#fff;"> Powered by � Live Software Solution 2017</h6>
            </div>

        </div>
        <div id="test1" class="gmap3"></div>

        <!-- MAIN EFFECT -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/preloader.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
<!--        <script type="text/javascript" src="<?php echo base_url();?>assets/js/app.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/load.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/main.js"></script>

        <script type="text/javascript" src="<?php echo base_url();?>assets/js/mapapi.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/gmap3.js"></script>-->
     <!-- <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkSEXMA8K4fhZLuF1fIwBIdFoHUjYVmsk"
    type="text/javascript"></script>-->
<!--        <script type="text/javascript">
            $(function () {

                $("#test1").gmap3({
                    marker: {
                        latLng: [-7.782893, 110.402645],
                        options: {
                            draggable: true
                        },
                        events: {
                            dragend: function (marker) {
                                $(this).gmap3({
                                    getaddress: {
                                        latLng: marker.getPosition(),
                                        callback: function (results) {
                                            var map = $(this).gmap3("get"),
                                                    infowindow = $(this).gmap3({
                                                get: "infowindow"
                                            }),
                                                    content = results && results[1] ? results && results[1].formatted_address : "no address";
                                            if (infowindow) {
                                                infowindow.open(map, marker);
                                                infowindow.setContent(content);
                                            } else {
                                                $(this).gmap3({
                                                    infowindow: {
                                                        anchor: marker,
                                                        options: {
                                                            content: content
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    },
                    map: {
                        options: {
                            zoom: 15
                        }
                    }
                });

            });
        </script>-->

    </body>

</html>
