<style>
/*#content {
    padding-top: 60px;
    overflow: auto;
    clear: both;
}*/

.control-label em {
    font-size: 90%;
    display: block;
    color: #888;
}

.nav li {
    position: relative;
}

.nav .arr {
    position: absolute;
    right: 6px;
}

a.active .arr {
    color: #FFF !important;
}

#submenu-container {
    border-radius: 0;
    padding-top: 0;
    padding-bottom: 0;
}

.submenu {
    padding-bottom: 10px;
}

.submenu li {
    padding-top: 7px;
}

.nav-list>.active>a, .nav-list>.active>a:hover {
    background-color: #4185ad;
}

.brand {
    float: left;
}

.top-menu {
    float: right;
}

    .top-menu a {
        display: block;
        float: left;
        padding: 8px 22px;
        font-size: 14px;
        font-weight: bold;
        color: rgba(255,255,255, .8);
        border: rgba(255,255,255, .2) solid 1px;
        border-width: 0 1px;
        border-right-color: rgba(0,0,0, .2);
    }

    .top-menu a i {
        opacity: 0.8;
        vertical-align: -2px;
    }

    .top-menu a:hover,
    .top-menu a.active,
    .top-menu a:hover i,
    .top-menu a.active i {
        color: #FFF;
        opacity: 1;
        text-decoration: none;
    }

    .top-menu a:first-child {
        border-left: 0;
    }

    .top-menu a:last-child {
        border-right: 0;
    }





.help-block {
    display: inline;
    padding-left: 6px;
    font-size: 85%;
}

span.form-error.help-block {
    display: block;
    color: #cd3335;
    margin-top: 6px;
    padding-left: 0;font-weight: bold; font-size:13px
}


input.valid {
    background:url(tic.png) no-repeat right center #e3ffe5;
    color: #002f00;
    border-color: #96b796 !important;
}

input.error {
    background:url(download.png) no-repeat right center #ffebef;
    color: #480000;
}

select.valid {
    background: url(../img/icon-ok.png) no-repeat right center #e3ffe5;
    color: #002f00;
    border-color: #96b796 !important;
}


select.error {
    background: url(../img/icon-fail.png) no-repeat right center #ffebef;
    color: #480000 !important;
}


.chosen-select {
    background: url(../img/icon-fail.png) no-repeat right center #ffebef;
    color: #480000 !important;
}


.form-suggest-element {
    padding: 4px;
}

form.validating-server-side .server-validation {
    background: url(../img/loader2.gif?v=2) no-repeat center right #ffebef;
    opacity: 0.5;
}

.max-chars {
    background: #EEE;
    color: #999;
}

.form-help {
    padding-left: 6px;
    font-size: 90%;
    color: #888;
}





.com { color: #93a1a1; }
.lit { color: #195f91; }
.pun, .opn, .clo { color: #93a1a1; }
.fun { color: #dc322f; }
.str, .atv { color: #D14; }
.kwd, .prettyprint .tag { color: #1e347b; }
.typ, .atn, .dec, .var { color: teal; }
.pln { color: #48484c; }

.prettyprint {
    font-size: 11px;
    padding: 8px;
    background-color: #f7f7f9;
    border: 1px solid #e1e1e8;
}
.prettyprint.linenums {
    -webkit-box-shadow: inset 40px 0 0 #fbfbfc, inset 41px 0 0 #ececf0;
    -moz-box-shadow: inset 40px 0 0 #fbfbfc, inset 41px 0 0 #ececf0;
    box-shadow: inset 40px 0 0 #fbfbfc, inset 41px 0 0 #ececf0;
}


ol.linenums {
    margin: 0 0 0 33px; 
}
ol.linenums li {
    padding-left: 12px;
    color: #bebec5;
    line-height: 20px;
    text-shadow: 0 1px 0 #fff;
}

.prettyprint {
    margin-top: 22px;
}
.convert-code {
    display: none;
}

.pre-title {
    margin-bottom: -12px;
}



.page {
    display: none;
}
</style>
<link href="http://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.2.8/theme-default.min.css" rel="stylesheet" type="text/css" />
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.2.43/jquery.form-validator.min.js"></script>
<script>

  $.validate({
    modules : 'location, date, security, file',
    onModulesLoaded : function() {
      $('#country').suggestCountry();
    }
  });

  // Restrict presentation length
  $('#presentation').restrictLength( $('#pres-max-length') );
  $.validate({
 modules : 'security',
  borderColorOnError : '#FFF',
  addValidClassOnAll : true
});


  function isNumber(evt) {
        var iKeyCode = (evt.which) ? evt.which : evt.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }    
</script>
