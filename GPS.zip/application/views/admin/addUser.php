<?php
if ($par1) {
    $edit = $this->db->get_where('porat_user', array('id' => $par1))->row_array();
    //print_r($edit);
    $formaction = 'edit';
} else {
    $formaction = 'create';
}
?>




<!--  PAPER WRAP -->
<div class="wrap-fluid" style="width: auto; margin-left: 250px;">
    <div class="container-fluid paper-wrap bevel tlbr">

        <div class="row">
            <div id="paper-top">
                <div class="col-lg-3">
                    <h2 class="tittle-content-header">
<!--                                <i class="icon-window"></i> -->
                        <ul class="breadcrumb">
                            <li>
                                <i class="fa fa-home"></i>
                                <a href="<?php echo base_url(); ?>index.php/Dashboard/Admin "><?php echo $pageName; ?> </a>
                            </li>										
                            <li><?php echo $Title; ?> </li>
                        </ul>



<!--                                <span>Add Edit User
 </span>-->
                    </h2>

                </div>
            </div>
        </div>
        <div class="content-wrap">
            <div class="row">
                <div class="col-sm-12">
                    <div class="nest" id="inlineClose">
                        <div class="title-alt">
                            <!--                                <h6>
                                                                Add / EDit User</h6>-->
                            <h6 class="content-title pull-left"><?php echo $Title; ?></h6>
                            <div class="titleClose">
                                <a class="gone" href="#inlineClose">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                            <div class="titleToggle">
                                <a class="nav-toggle-alt" href="#inline">
                                    <span class="entypo-up-open"></span>
                                </a>
                            </div>

                        </div>

                        <div class="body-nest" id="inline">

                            <div class="form_center1">


                                <div>

                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs mytab" role="tablist">
                                        <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">New</a></li>
                                        <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">List</a></li>
                                    </ul>

                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane active" id="home">



                                            <div class="content-wrap">
                                                <div class="row">


                                                    <div class="col-sm-12">
                                                        <div class="nest" id="basicClose">
                                                            <!--                            <div class="title-alt">
                                                                                            <h6>Basic</h6>
                                                                                            <div class="titleClose">
                                                                                                <a class="gone" href="#basicClose">
                                                                                                    <span class="entypo-cancel"></span>
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="titleToggle">
                                                                                                <a class="nav-toggle-alt" href="#basic">
                                                                                                    <span class="entypo-up-open"></span>
                                                                                                </a>
                                                                                            </div>
                                                            
                                                                                        </div>-->

                                                            <div class="body-nest" id="basic">
                                                                <div class="form_center">
                                                                    <!--                                    <form role="form">-->
                                                                    <?php echo form_open_multipart('index.php/Dashboard/saveUser/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal')); ?>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">User Id</label>
                                                                        <input type="hidden" name="hid" id="hid" value="<?php echo $edit['id'] ?>"/>

                                                                        <input class="form-control" type="text" name="userId" onkeyup="checkUserId();" id="userId" placeholder="Enter User Id" value="<?php echo $edit['user_id']; ?>" data-validation="length alphanumeric" data-validation-length="3-12"  data-validation-error-msg="User Id has to be an alphanumeric value (3-12 chars)"/>
                                                                        <span id="checkUserSpan" style="color:red;"></span>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">User Name</label>
                                                                        <input class="form-control" type="text" name="userName" id="userName"  placeholder="Enter User Name" value="<?php echo $edit['username']; ?>" data-validation="required"    data-validation-error-msg="Enter user name" />
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword1">Password</label>
                                                                        <input class="form-control" type="password" name="password" id="password" placeholder="Enter Password " value="<?php echo $edit['password']; ?>" data-validation="required length"  data-validation-length="3-10"  data-validation-error-msg="password has to be an alphanumeric value (3-10) chars)"/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">User Type</label>
                                                                        <select id="userType" name="usertype" class="form-control" data-validation="required"    data-validation-error-msg="Plz Select User type">
                                                                            <option></option>
                                                                            <option value="Main" <?php
                                                                            if ($edit['user_type'] == 'Main') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> > Main</option>
                                                                            <option value="Sub" <?php
                                                                            if ($edit['user_type'] == 'Sub') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> > Sub</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Phone No.</label>
                                                                        <input class="form-control" type="text" name="phoneNumber" id="phoneNumber" placeholder="Enter Phone number" value="<?php echo $edit['phone']; ?>"  data-validation="number length" data-validation-length="10-12"     data-validation-error-msg="Please input valid Phone number" />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Email Id</label>
                                                                        <input class="form-control" type="text" name="emailId" id="emailId" placeholder="Enter Email Id " value="<?php echo $edit['email']; ?>" data-validation="email"/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">DOB</label>
                                                                        <input class="form-control"  type="text" name="dob" id="don" placeholder="Enter Dob " value="<?php echo $edit['dob']; ?>" data-validation="required" data-validation-error-msg="Plz enter date of birth"  />
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Gender</label>

                                                                        <select id="userType" name="gender" class="form-control" data-validation="required"    data-validation-error-msg="Plz Select Gender">
                                                                            <option> </option>
                                                                            <option value="unknown" <?php
                                                                            if ($edit['gender'] == 'unknown') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> > Unknown</option>
                                                                            <option value="mail" <?php
                                                                            if ($edit['gender'] == 'mail') {
                                                                                echo "selected";
                                                                            }
                                                                            ?>> Male</option>
                                                                            <option value="femail" <?php
                                                                            if ($edit['gender'] == 'femail') {
                                                                                echo "selected";
                                                                            }
                                                                            ?>> Female</option>
                                                                        </select>  
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Mobile App</label>
                                                                        <input  tabindex="20" type="radio" id="line-radio-2" name="onoffswitch2" checked>

                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Portal Login</label>
                                                                        <input   tabindex="20" type="radio" id="line-radio-2" name="onoffswitch1" checked>

                                                                    </div>


                                                                    <div class="form-group">
                                                                        <label for="exampleInputFile">Image</label>
                                                                        <input type="file" name="upload"/>
                                                                        <p class="help-block">Example block-level help text here.</p>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Address</label>

                                                                        <textarea rows="2" cols="5" class="form-control"  name="address" id="address" > <?php echo $edit['address']; ?>  </textarea>

                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Fleet Size</label>

                                                                        <input type="number" id="fleetSize" name="fleetSize" class="form-control" value="<?php echo $edit['fleet_size']; ?>"/>

                                                                    </div>

                                                                    <div class="checkbox">
                                                                        <label>Must Set Password
                                                                            <input type="checkbox" name="mustSetPassword" id="mustSetPassword" value="1" <?php
                                                                            if ($edit['must_set_password'] == '1') {
                                                                                echo "checked";
                                                                            }
                                                                            ?> data-validation="required"  data-validation-error-msg="Must Set Password"  />
                                                                        </label>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Date Format</label>

                                                                        <select class="form-control" id="dateFormat" name="dateFormate">
                                                                            <option value="m-d-Y" <?php
                                                                            if ($edit['date_formate'] == 'm-d-Y') {
                                                                                echo "selected";
                                                                            }
                                                                            ?>/>
                                                                            mm-dd-yyyy
                                                                            </option>
                                                                        </select>

                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Time Zone</label>

                                                                        <<input type="hidden" name="portalexpiryDta" id="portalexpiryDta" />

                                                                        <select class="form-control" id="timeZone" name="timeZone">
                                                                            <option value="Asia/Calcutta" <?php
                                                                            if ($edit['timezone'] == 'Asia/Calcutta') {
                                                                                echo "selected";
                                                                            }
                                                                            ?>>(UTC) Asia/Calcutta</option>
                                                                            <!--                                                                    <option value="(UTC)Coordinated Universal Time" <?php
                                                                            if ($edit['timezone'] == '(UTC)Coordinated Universal Time') {
                                                                                echo "selected";
                                                                            }
                                                                            ?>>(UTC) Coordinated Universal Time</option>
                                                                                                                                                <option value="(UTC)Dublin, Edinburgh, Lisbon, London" <?php
                                                                            if ($edit['timezone'] == '(UTC)Dublin, Edinburgh, Lisbon, London') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> >(UTC) Dublin, Edinburgh, Lisbon, London</option>
                                                                                                                                                <option value="(UTC)Dublin, Edinburgh, Lisbon, London" <?php
                                                                            if ($edit['timezone'] == '(UTC)Dublin, Edinburgh, Lisbon, London') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> >(UTC) Dublin, Edinburgh, Lisbon, London</option>
                                                                                                                                                <option value="(UTC) Monrovia, Reykjavik" <?php
                                                                            if ($edit['timezone'] == '(UTC) Monrovia, Reykjavik') {
                                                                                echo "selected";
                                                                            }
                                                                            ?> >(UTC) Monrovia, Reykjavik </option>-->
                                                                        </select>

                                                                    </div>
                                                                    <!--                                        <button class="btn btn-info" type="submit">Submit</button>-->
                                                                    <input type="submit"  id="submitBtn" name="sub" value="Save" class="btn btn-info" style="width:100px; height: 40px;"/>
                                                                    </form>
                                                                    <?php
                                                                    echo form_close();
                                                                    ?>
                                                                </div>


                                                            </div>

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>

                                        <div role="tabpanel" class="tab-pane" id="profile">

                                            <form id="userForm1" class="form-horizontal" name="peopleform" novalidate>
                                                <div class="divide-10"></div>
                                                <p>




                                                <div class="box-body">

                                                    <div class="content-wrap">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <div class="nest" id="FilteringClose">
                                                                    <div class="title-alt">
                                                                        <h6>
                                                                            Footable Filtering</h6>
                                                                        <div class="titleClose">
                                                                            <a class="gone" href="#FilteringClose">
                                                                                <span class="entypo-cancel"></span>
                                                                            </a>
                                                                        </div>
                                                                        <div class="titleToggle">
                                                                            <a class="nav-toggle-alt" href="#Filtering">
                                                                                <span class="entypo-up-open"></span>
                                                                            </a>
                                                                        </div>

                                                                    </div>

                                                                    <div class="body-nest" id="Filtering">

                                                                        <div class="row" style="margin-bottom:10px;">
                                                                            
<!--                                                                            <div class="col-sm-6" id="dbtn">
                                                                            
                                                                            </div>-->
                                                                            
                                                                            <div class="col-sm-4">
                                                                                <input class="form-control" id="filter" placeholder="Search..." type="text" />
                                                                            </div>
                                                                            <div class="col-sm-2">
                                                                                <select class="filter-status form-control">
                                                                                    <option value='Main'>Main</option>
                                                                                    <option value='Sub'>Sub</option>
                                                                                </select>
                                                                            </div>
                                                                                                                

                                                                        </div>

                                                                        <table id="footable-res2" class="demo" data-filter="#filter" data-filter-text-only="true">
                                                                            <thead id="abcaaa">
                                                                        <tr>
                                                                            <th>Sr. No.</th>
                                                                            <th>User Id</th>
                                                                            <th>User Name</th>
                                                                            <th style="display:none;">User Type</th>
                                                                            <th>Phone Number</th>
                                                                            <th>Portal Login</th>
                                                                            <th>Mobile App</th>
                                                                            <th>Email Id</th>
                                                                            <th>Creation time</th>
                                                                            <th>Action</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <?php
                                                                    //echo '<pre>'; print_r($portal_user);
                                                                    if ($portal_user) {
                                                                        $i = 1;
                                                                        foreach ($portal_user as $key => $value) {
                                                                            ?> 

                                                                            <tr class="abc1111">
                                                                                <td> <?php echo $i; ?>  </td>
                                                                                <td> <?php echo $value['user_id']; ?></td>
                                                                                <td> <?php echo $value['username']; ?></td>
                                                                                <td style="display:none;"> <?php echo $value['usertype']; ?></td>
                                                                                <td> <?php echo $value['phone']; ?></td>
                                                                                <td> <?php
                                                                                    if ($value['portal_login'] == '0') {
                                                                                        echo "Deactivated";
                                                                                    }
                                                                                    if ($value['portal_login'] == '1') {
                                                                                        echo "Active";
                                                                                    }
                                                                                    ?>
                                                                                </td>
                                                                                <td> 
                                                                                    <?php
                                                                                    if ($value['mobile_app'] == '0') {
                                                                                        echo "Not Assigned";
                                                                                    }
                                                                                    if ($value['mobile_app'] == '1') {
                                                                                        echo "Assigned";
                                                                                    }
                                                                                    ?>
                                                                                </td>
                                                                                <td> <?php echo $value['email']; ?></td>
                                                                                <td>
                                                                                    <a href="#" title="<?php echo $time = date('G:i:s', $value['date']); ?> " style="text-decoration:none;"> <?php   echo $date = date('d-m-Y',$value['date']);
                                                                                           ?> </a>
                                                                                </td>
                                                                                <td> <a href="<?php echo base_url() . 'index.php/Dashboard/addUser/' . $value['id']; ?>"> <i class="fa fa-edit"> </i> </a> &nbsp;
                                                                                    <i class="fa fa-trash-o" id="<?php echo $value['id']; ?> "></i>  
                                                                                </td>

                                                                            </tr>
                                                                            <?php
                                                                            $i++;
                                                                        }
                                                                    }
                                                                    ?> 
                                                                    <tfoot>
                                                                        <tr>
                                                                            <th>Sr. No.</th>
                                                                            <th>User Id</th>
                                                                            <th>User Name</th>
                                                                            <th style="display:none;">User Type</th>
                                                                            <th>Phone Number</th>
                                                                            <th>Portal Login</th>
                                                                            <th>Mobile App</th>
                                                                            <th>Email Id</th>
                                                                            <th>Creation time</th>
                                                                            <th>Action</th>
                                                                        </tr>
                                                                    </tfoot>
                                                                        </table>

                                                                    </div>

                                                                </div>


                                                            </div>

                                                        </div>
                                                    </div>



<!--                                                    <table id="example" class="display" cellspacing="0" style="width:100%">
                                                        <thead id="abcaaa">
                                                            <tr>
                                                                <th>Sr. No.</th>
                                                                <th>User Id</th>
                                                                <th>User Name</th>
                                                                <th style="display:none;">User Type</th>
                                                                <th>Phone Number</th>
                                                                <th>Portal Login</th>
                                                                <th>Mobile App</th>
                                                                <th>Email Id</th>
                                                                <th>Creation time</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                    <?php
                                                    //echo '<pre>'; print_r($portal_user);
                                                    if ($portal_user) {
                                                        $i = 1;
                                                        foreach ($portal_user as $key => $value) {
                                                            ?> 

                                                                        <tr class="abc1111">
                                                                            <td> <?php echo $i; ?>  </td>
                                                                            <td> <?php echo $value['user_id']; ?></td>
                                                                            <td> <?php echo $value['username']; ?></td>
                                                                            <td style="display:none;"> <?php echo $value['usertype']; ?></td>
                                                                            <td> <?php echo $value['phone']; ?></td>
                                                                            <td> <?php
                                                            if ($value['portal_login'] == '0') {
                                                                echo "Deactivated";
                                                            }
                                                            if ($value['portal_login'] == '1') {
                                                                echo "Active";
                                                            }
                                                            ?>
                                                                            </td>
                                                                            <td> 
                                                            <?php
                                                            if ($value['mobile_app'] == '0') {
                                                                echo "Not Assigned";
                                                            }
                                                            if ($value['mobile_app'] == '1') {
                                                                echo "Assigned";
                                                            }
                                                            ?>
                                                                            </td>
                                                                            <td> <?php echo $value['email']; ?></td>
                                                                            <td>
                                                                                <a href="#" title="<?php echo $time = date('G:i:s', $value['date']); ?> " style="text-decoration:none;"> <?php echo $date = date('d-m-Y', $value['date']);
                                                            ?> </a>
                                                                            </td>
                                                                            <td> <a href="<?php echo base_url() . 'index.php/Dashboard/addUser/' . $value['id']; ?>"> <i class="fa fa-edit"> </i> </a> &nbsp;
                                                                                <i class="fa fa-trash-o" id="<?php echo $value['id']; ?> "></i>  
                                                                            </td>

                                                                        </tr>
                                                            <?php
                                                            $i++;
                                                        }
                                                    }
                                                    ?> 
                                                        <tfoot>
                                                            <tr>
                                                                <th>Sr. No.</th>
                                                                <th>User Id</th>
                                                                <th>User Name</th>
                                                                <th style="display:none;">User Type</th>
                                                                <th>Phone Number</th>
                                                                <th>Portal Login</th>
                                                                <th>Mobile App</th>
                                                                <th>Email Id</th>
                                                                <th>Creation time</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </tfoot>
                                                    </table>-->



                                                </div>


                                                </p>
                                            </form>






                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


<script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>
<script type="text/javascript">
    $(function () {
        $('.footable-res').footable();
    });

    /* Custom filtering function which will search data in column four between two values */
//    $.fn.dataTable.ext.search.push(
//            function (settings, data, dataIndex) {
//                var min = $('#min').val();
//                var max = $('#max').val();
//                var age = data[3]; // use data for the age column
//                if ((min) == age) {
//                    return true;
//                }
//                return false;
//            }
//    );
    // end custom add table 
    $(document).ready(function () {
        // for showinng radio button value
        $("#myonoffswitch2").click(function (e) {
            var mobileApp = $('input[name=onoffswitch2]:checked').val();
            if (mobileApp == '1') {
                $("#applogin").modal('show');
            }
        });


        $("#apploginBtn").click(function (e) {
            $("#applogin").modal('hide');
        });

        // for showinng radio button value
        $("#myonoffswitch1").click(function (e) {
            var mobileApp = $('input[name=onoffswitch1]:checked').val();
            if (mobileApp == '1') {
                $("#portalLogin").modal('show');
            } else {
                $("#portalexpiryDta").val('');
            }
        });


        $("#portalloginBtn").click(function (e) {
            $("#portalLogin").modal('hide');
            var validexpiry = $('#validtillexpiry').val();
            $("#portalexpiryDta").val(validexpiry);
        });




        // for delete item from list
        $(".fa-trash-o").click(function (e) {
            var conf = confirm("Are you sure want to delete!");
            if (conf == true) {
                var id = this.id;
                $.ajax({
                    url: '<?php echo base_url(); ?>index.php/Dashboard/saveUser/delete',
                    type: "POST",
                    data: {'id': id,
                    },
                    success: function (response)
                    {
                        location.reload();
                    }
                });
            }
        });

        // search for type 
        $("#usType").change(function (e) {
            //alert(this.value);
            $.ajax({
                url: '<?php echo base_url(); ?>Dashboard/addUser1',
                type: "POST",
                data: {'type': this.value,
                },
                success: function (response)
                {

                    console.log(response);
                    //alert(response);
                    // console.log(response);
                    // $("#example").hide();
                    //abc1111
                    //var asd =   "<tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr>";
                    //$(".abc1111").hide();
                    //$(".abc1111").html(asd);


                    //location.reload();
                    //$("#New").removeClass("active");
                }
            });

        });

        // for dynamic data table add row 


$('#footable-res2').DataTable({
    dom: 'Bfrtip',
    buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
    ]
});





        // end dynamic data table here
    });






</script>

<script type="text/javascript">
    $(function () {
        $('#footable-res2').footable().bind('footable_filtering', function (e) {
            var selected = $('.filter-status').find(':selected').text();
            if (selected && selected.length > 0) {
                e.filter += (e.filter && e.filter.length > 0) ? ' ' + selected : selected;
                e.clear = !e.filter;
            }
        });

        $('.clear-filter').click(function (e) {
            e.preventDefault();
            $('.filter-status').val('');
            $('table.demo').trigger('footable_clear_filter');
        });

        $('.filter-status').change(function (e) {
            e.preventDefault();
            $('table.demo').trigger('footable_filter', {
                filter: $('#filter').val()
            });
        });

        $('.filter-api').click(function (e) {
            e.preventDefault();

            //get the footable filter object
            var footableFilter = $('table').data('footable-filter');

            alert('about to filter table by "tech"');
            //filter by 'tech'
            footableFilter.filter('tech');

            //clear the filter
            if (confirm('clear filter now?')) {
                footableFilter.clearFilter();
            }
        });
    });
</script>

            <script>





//          function checkUserId() {
//              var userId = $('#userId').val();
//              if (userId.length >= '3') {
//                  $.ajax({
//                      url: '<?php echo base_url(); ?>Dashboard/checkUserId',
//                      type: "POST",
//                      data: {'userId': userId,
//                      },
//                      success: function (response)
//                      {
//                          //  alert(response);
//
//                          if (response) {
//                              // alert("user Id  all ready exist");
//                              //$('#submitBtn').disable();
//                              $("#submitBtn").attr("disabled", true);
//                              $("#checkUserSpan").html('User id allready exist');
//                          } else {
//                              $('#submitBtn').attr("disabled", false);
//                              $("#checkUserSpan").html('');
//                          }
//                      }
//                  });
//              }
//          }
          /* Custom filtering function which will search data in column four between two values */
//                                                                            $.fn.dataTable.ext.search.push(
//                                                                                    function (settings, data, dataIndex) {
//                                                                                        var min = $('#min').val();
//                                                                                        var max = $('#max').val();
//                                                                                        var age = data[3]; // use data for the age column
//                                                                                        if ((min) == age) {
//                                                                                            return true;
//                                                                                        }
//                                                                                        return false;
//                                                                                    }
//                                                                            );
          // end custom add table 





            </script>









