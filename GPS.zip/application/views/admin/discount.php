<style type="text/css">

    .custom-date-style {
        background-color: red !important;
    }

    .input{	
    }
    .input-wide{
        width: 500px;
    }

</style>
<script>
    window.dvalue = '00:00';
    window.dvalue1 = '23:00';
</script>
<?php
if ($par1) {
    $edit = $this->db->get_where('tbldiscount', array('ID_disc' => $par2))->row_array();

    $formaction = 'edit';
    ?>
    <script>
        dvalue = '<?php echo $edit['ActiveTimeStart_disc']; ?>'
        dvalue1 = '<?php echo $edit['ActiveTimeEnd_disc']; ?>'
        console.log(dvalue);
        console.log(dvalue1);
    </script>

    <?php
} else {
    $formaction = 'create';
}
?>
<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>Client">Client</a>
                                </li>										
                                <li><?php echo $page_title; ?></li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $page_title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-3">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>

                                </div>



                            </div>

                        </div>


                        <div class="row">
                            <div class="col-lg-12">                                            
                                <div class="dashbox panel panel-default">
                                    <div class="panel-body">

                                        <div class="col-md-8">
                                            <div class="box border primary">
                                                <div class="box-title">
                                                    <h4><i class="fa fa-bars"></i>ADD Discount</h4>

                                                </div>
                                                <div class="box-body">
                                                    <?php
                                                    echo form_open('Client/adddiscount/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal'));
                                                    ?>


                                                    <div class="form-group">
                                                        <input type="hidden" name="hid" value="<?php echo $edit['ID_disc']; ?>" />
                                                        <label class="col-sm-3 control-label">Start Date</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control datetime1" name="start_time" id="start_time" placeholder="Enter Start Date and Time"  value="<?php echo $edit['DiscountStartTime_disc'] ?>"  readonly data-validation="required" data-validation-error-msg="Please Enter Start Date"/>
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">End Date</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control datetime1" name="end_time" id="end_time" placeholder="Enter End Date and Time"  value="<?php echo $edit['DiscountEndTime_disc'] ?>"  readonly data-validation="required" data-validation-error-msg="Please Enter End Date" />
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Active Week Days</label>
                                                        <div class="col-sm-8">
                                                            <?php $d = explode(',', $edit['ActiveWeekDays_disc']); ?>
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="sunday" <?php
                                                            if (in_array('sunday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> data-validation="checkbox_group"  data-validation-qty="min1" data-validation-error-msg="Please Checked At Least One Item " />Sunday
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="monday"<?php
                                                            if (in_array('monday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> />Monday
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="tuesday" <?php
                                                            if (in_array('tuesday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> />Tuesday
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="wednesday" <?php
                                                            if (in_array('wednesday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> />Wednesday
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="thursday" <?php
                                                            if (in_array('thursday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> />Thursday
                                                            <input type="checkbox" class="posCheckBox" name="a_w_days[]" id="a_w_days" value="friday" <?php
                                                            if (in_array('friday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?> />Friday
                                                            <input type="checkbox"  class="posCheckBox" name="a_w_days[]" id="a_w_days" value="saturday"  <?php
                                                            if (in_array('saturday', $d)) {
                                                                echo "checked";
                                                            }
                                                            ?>/>Saturday
                                                        </div>
                                                    </div>


                                                    <div class="form-group" >
                                                        <label class="col-sm-3 control-label">ActiveTime</label>
                                                        <div class="col-sm-4">
                                                            <input type="text" class="form-control" name="a_times" id="a_times" placeholder="From" value="<?php echo $edit['ActiveTimeStart_disc'] ?>" readonly data-validation="required" data-validation-error-msg="Please Enter Active Time" />
                                                        </div>
                                                        <div class="col-sm-4">
                                                            <input type="text" class="form-control" name="ea_times" id="ea_times" placeholder="To" value="<?php echo $edit['ActiveTimeEnd_disc'] ?>" readonly data-validation="required" data-validation-error-msg="Please Enter Active Time" />
                                                        </div>

                                                    </div>


                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label"> Discount By</label>
                                                        <div class="col-sm-8">
                                                            <select id="disc_by" name="disc_by" class="form-control" data-validation="required" data-validation-error-msg="Please Select Discount by" >
                                                                <!-- <option value="type">Type</option>-->

                                                                <?php
                                                                if ($edit['NeededAmount_disc']) {
                                                                    ?>
                                                                    <option value="item">Item</option>
                                                                    <option value="price" selected="selected">Amount</option>
                                                                <?php } elseif ($edit['ID_disc'] != '' & $edit['NeededAmount_disc'] == '') { ?>
                                                                    <option value="item" selected="selected" >Item</option>
                                                                    <option value="price" >Amount</option>

                                                                <?php } else { ?>
                                                                    <option value="item">Item</option>
                                                                    <option value="price" selected="selected">Amount</option>
                                                                <?php } ?>


                                                            </select>
                                                        </div>
                                                    </div>


                                                    <div class="form-group" style="display:none;" id="mtype">
                                                        <label class="col-sm-3 control-label">Menu Type</label>
                                                        <div class="col-sm-8">
                                                            <select id="menu_type" name="menu_type" class="form-control">
                                                                <option value="">Select Menu Type</option>
                                                                <?php
                                                                foreach ($tblmenutype as $tblmenutype1) {
                                                                    ?>
                                                                    <option <?php
                                                                    if ($tblmenutype1['ID_mnty'] == $edit['ID_mnty_disc']) {
                                                                        echo "selected";
                                                                    }
                                                                    ?>  value="<?php echo $tblmenutype1['ID_mnty']; ?>"> <?php echo $tblmenutype1['DisplayName_mnty']; ?></option>

                                                                <?php }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>


                                                    <div class="form-group" style="display:none;" id="mitem">
                                                        <label class="col-sm-3 control-label">Menu Item</label>
                                                        <div class="col-sm-8">
                                                            <select id="menu_item" name="menu_item" class="form-control">
                                                                <option value="">Select Menu Item</option>
                                                                <?php
                                                                if ($edit['ID_mnit_disc']) {
                                                                    $tblmenuitem = $this->db->get_where('tblmenuitem', array('ID_mnit' => $edit['ID_mnit_disc']))->result_array();
                                                                    foreach ($tblmenuitem as $tblmenuitem1) {
                                                                        ?>

                                                                        <option <?php
                                                                        if ($edit['ID_mnit_disc'] == $tblmenuitem1['ID_mnit']) {
                                                                            echo "selected";
                                                                        }
                                                                        ?> value="<?php echo $tblmenuitem1['ID_mnit']; ?>"> <?php echo $tblmenuitem1['DisplayName_mnit']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                            </select>
                                                        </div>
                                                    </div>


                                                    <div class="form-group" style="display:none;" id="mprice">
                                                        <label class="col-sm-3 control-label">Item Price</label>
                                                        <div class="col-sm-8">
                                                            <select id="item_price" name="item_price" class="form-control">
                                                                <option value="">Select Item Price</option>
                                                                <?php
                                                                if ($edit['ID_mnpr_disc']) {
                                                                    $tblmenuitemprice = $this->db->get_where('tblmenuitemprice', array('ID_mnpr' => $edit['ID_mnpr_disc']))->result_array();
                                                                    foreach ($tblmenuitemprice as $tblmenuitemprice1) {
                                                                        ?>
                                                                        <option  <?php
                                                                        if ($edit['ID_mnpr_disc'] == $tblmenuitemprice1['ID_mnpr']) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>  value="<?php echo $edit['ID_mnpr']; ?>"> <?php echo $tblmenuitemprice1['PriceHead_mnpr']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                            </select>
                                                        </div>
                                                    </div>


                                                    <div class="form-group" id="mneeded">
                                                        <label class="col-sm-3 control-label">Needed Amount</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" name="needed_amt" id="needed_amt" placeholder="Enter Total Order Amount Required To Get This Discount" value="<?php echo $edit['NeededAmount_disc'] ?>"  onkeypress="javascript:return isNumber(event)"  >
                                                        </div>
                                                    </div>


                                                    <div class="form-group" style="display:block;" id="mdisc">
                                                        <label class="col-sm-3 control-label">Discount Percent</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" name="disc_percent" id="disc_percent" placeholder="Enter Discount Percent" value="<?php echo $edit['DiscountPercent_disc'] ?>" onkeypress="javascript:return isNumber(event)" >
                                                        </div>
                                                    </div>

                                                    <div class="form-group" style="display:block;" id="mamt">
                                                        <label class="col-sm-3 control-label">Discount Amount</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" class="form-control" name="disc_amt" id="disc_amt"  placeholder="Enter Discount Amount" value="<?php echo $edit['DiscountAmount_disc'] ?>" onkeypress="javascript:return isNumber(event)" >
                                                        </div>
                                                    </div>





                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label"></label>
                                                        <div class="col-sm-5">
                                                            <div class="input-group">
                                                                <input type="submit" name="sub" value="SAVE" class="btn-primary" />

                                                            </div>
                                                        </div>
                                                    </div>



                                                    <?php
                                                    echo form_close();
                                                    ?>
                                                </div>
                                            </div>
                                        </div>


                                    </div>

                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Discount list</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <table id="datatable1" cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Start Date</th>
                                                        <th>End Date</th>
                                                        <th>Active Week Days</th>
                                                        <th>ActiveTime</th>
                                                        <th>Menu Type</th>
                                                        <th>Menu Item</th>
                                                        <th>Item Price</th>

                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    if ($tbldiscount) {
                                                        $i = '0';
                                                        foreach ($tbldiscount as $tbldiscount1) {
                                                            $i++;
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $i; ?> </td>
                                                                <td><?php echo $tbldiscount1['DiscountStartTime_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['DiscountEndTime_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['ActiveWeekDays_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['ActiveTimeStart_disc']; ?> To <?php echo $tbldiscount1['ActiveTimeEnd_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['ID_mnty_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['ID_mnit_disc']; ?></td>
                                                                <td><?php echo $tbldiscount1['ID_mnpr_disc']; ?></td>


                                                                <td><a href="<?php echo base_url() . 'Client/discount/edit/' . $tbldiscount1['ID_disc']; ?>">Edit</a> </td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Start Date</th>
                                                        <th>End Date</th>
                                                        <th>Active Week Days</th>
                                                        <th>ActiveTime</th>
                                                        <th>Menu Type</th>
                                                        <th>Menu Item</th>
                                                        <th>Item Price</th>

                                                        <th>Action</th>

                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>

                </div>


                </section>

                <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <link href="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.2.8/theme-default.min.css"
                      rel="stylesheet" type="text/css" />
                  <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                --><script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.2.43/jquery.form-validator.min.js"></script>
                <script>
                                                                $.validate({
                                                                    modules: 'location, date, security, file',
                                                                    onModulesLoaded: function () {
                                                                        $('#country').suggestCountry();
                                                                    }
                                                                });

                                                                function isNumber(evt) {
                                                                    var iKeyCode = (evt.which) ? evt.which : evt.keyCode
                                                                    if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
                                                                        return false;

                                                                    return true;
                                                                }

                </script>  


                <script>

                    window.onload = function ()
                    {
                        $('#disc_by').trigger('change');
                    }

                    $(document).ready(function () {



                        // for calendar
                        $.datetimepicker.setLocale('en');
                        $('.datetime1').datetimepicker();

                        //{value:'2016/03/15 00:00',step:5}
                        /*$('#start_time').datetimepicker({
                         datepicker:false,
                         format:'H:i',
                         step:5
                         });
                         
                         $('#a_times').datetimepicker({
                         //yearOffset:1950,
                         lang:'ch',
                         timepicker:false,
                         format:'d/m/Y',
                         formatDate:'Y/m/d',
                         });*/
                         
                         $('#a_times').timepicker();
                         $('#ea_times').timepicker();

//                        $('#a_times').datetimepicker({
//                            datepicker: false,
//                            format: 'H:i',
//                            value: dvalue,
//                            step: 10,
//                        });
//
//                        $('#ea_times').datetimepicker({
//                            datepicker: false,
//                            format: 'H:i',
//                            value: dvalue1,
//                            step: 10,
//                        });
//                        
                        


                        // hide and show functionality

                        //$('#disc_by').trigger('change');



                        $("#disc_by").change(function () {
                            var type = jQuery(this).val();
                            if (type == 'item')
                            {
                                $("#mtype").show();
                                $("#mitem").show();
                                $("#mprice").show();
                                $("#mdisc").show();
                                $("#mamt").show();
                                $("#mneeded").hide();
                            }
                            if (type == 'price')
                            {
                                $("#mtype").hide();
                                $("#mitem").hide();
                                $("#mprice").hide();
                                //$("#mdisc").hide();
                                //$("#mamt").hide();
                                $("#mneeded").show();
                            }
                        });


                        // select type item and price
                        $("#menu_type").change(function () {
                            var id = jQuery(this).val();

                            $.ajax({
                                url: '<?php echo base_url(); ?>Client/type/create/ajax',
                                type: "POST",
                                data: {'id': id},
                                success: function (response)
                                {
                                    $("#menu_item").html(response);
                                }

                            });
                        });


                        $("#menu_item").change(function () {
                            var id = jQuery(this).val();

                            $.ajax({
                                url: '<?php echo base_url(); ?>Client/type/item/ajax',
                            type: "POST",
                            data: {'id': id},
                            success: function (response)
                            {
                                //alert(response);
                                $("#item_price").html(response);
                            }

                        });
                    });



                });




            </script>
