<?php
if ($par1) {
    $edit = $this->db->get_where('employee', array('id' => $par1))->row_array();
    //print_r($edit);
    $formaction = 'edit';
} else {
    $formaction = 'create';
}
?>
<style>

    .onoffswitch {
        position: relative; width: 90px;
        -webkit-user-select:none; -moz-user-select:none; -ms-user-select: none;
    }
    .onoffswitch-checkbox {
        display: none;
    }
    .onoffswitch-label {
        display: block; overflow: hidden; cursor: pointer;
        border: 2px solid #999999; border-radius: 20px;
    }
    .onoffswitch-inner {
        display: block; width: 200%; margin-left: -100%;
        transition: margin 0.3s ease-in 0s;
    }
    .onoffswitch-inner:before, .onoffswitch-inner:after {
        display: block; float: left; width: 50%; height: 30px; padding: 0; line-height: 30px;
        font-size: 14px; color: white; font-family: Trebuchet, Arial, sans-serif; font-weight: bold;
        box-sizing: border-box;
    }
    .onoffswitch-inner:before {
        content: "ON";
        padding-left: 10px;
        background-color: #34A7C1; color: #FFFFFF;
    }
    .onoffswitch-inner:after {
        content: "OFF";
        padding-right: 10px;
        background-color: #EEEEEE; color: #999999;
        text-align: right;
    }
    .onoffswitch-switch {
        display: block; width: 18px; margin: 6px;
        background: #FFFFFF;
        position: absolute; top: 0; bottom: 0;
        right: 56px;
        border: 2px solid #999999; border-radius: 20px;
        transition: all 0.3s ease-in 0s; 
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-inner {
        margin-left: 0;
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-switch {
        right: 0px; 
    }

    div.upload {
        width: 157px;
        height: 57px;
        overflow: hidden;
        background-image: url('<?php echo base_url(); ?>/assets/img/upload.png');
    }

    div.upload input {
        display: block !important;
        width: 157px !important;
        height: 57px !important;
        opacity: 0 !important;
        overflow: hidden !important;
    }

</style>





<!--https://lh6.googleusercontent.com/-dqTIJRTqEAQ/UJaofTQm3hI/AAAAAAAABHo/w7ruR1SOIsA/s157/upload.png-->

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/Dashboard/Admin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i> Mobile Portal Feature  </h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>

                                            </div>
                                        </div>
                                        <div class="box-body">

                                            <div class="tabbable">
                                                <ul class="nav nav-tabs">
                                                    <li class="active" id="New"><a href="#tab_1_1" data-toggle="tab"> New </a></li>
                                                    <li id="List"><a href="#tab_1_2" data-toggle="tab"> List </a></li>

                                                </ul>

                                                <div class="tab-content">
                                                    <div class="tab-pane fade in active" id="tab_1_1">
                                                        <?php echo form_open_multipart('Dashboard/saveMobilePortalFeature/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal')); ?>
                                                        <div class="divide-10"></div>
                                                        <p>

                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Select User Id </label>
                                                            <div class="col-sm-8">
                                                                <input type="hidden" name="hid" id="hid" value="<?php echo $edit['id'] ?> "/>
                                                                <select id="username" name="username" class="form-control">
                                                                    <option value=""> Select user</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> DashBoard </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="dashboard" id="dashboard" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Live Track </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="live_tarck" id="live_track" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Is Feature Visible </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="is_feature_visible" id="is_feature_visible" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                      
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label ">  Is LogOut Required </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="is_logout_required" id="is_logout_required" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> History Replay </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="history_replay" id="history_replay" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> View All Vehicles </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="view_all_vehicles" id="view_all_vehicles" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> All Activities </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="all_activities" id="all_activities" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Check For Update </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="check_for_update" id="check_for_update" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Settings </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="settings" id="settings" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Rate This App </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="ratet_this_app" id="ratet_this_app" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label ">  Log Out </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="log_out" id="log_out" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Go On Map </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="go_on_map" id="go_on_map" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Last Locations </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="last_location" id="last_location" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Get Last Activities </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="get_last_astivities" id="get_last_astivities" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Ignition Enabled/Disabled </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="ignition_enabled_disabled" id="ignition_enabled_disabled" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Parking Enabled/Disabled </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="parking_enabled_disabled" id="parking_enabled_disabled" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Distance Report </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="distance_report" id="distance_report" class="form-comntrol"/>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "> Push Required </label>
                                                            <div class="col-sm-8">
                                                                <input type="checkbox" name="push_required" id="push_required" class="form-comntrol"/>
                                                            </div>
                                                        </div>




                                                        <div class="form-group">
                                                            <label class="col-sm-2 control-label "></label>
                                                            <div class="col-sm-8">
                                                                <input type="submit" name="sub" value="Save" class="btn-primary" style="width:100px; height: 40px;"/>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        


                                                        </p>
                                                        <?php
                                                        echo form_close();
                                                        ?>
                                                    </div>

                                                    <div class="tab-pane fade" id="tab_1_2">
                                                        <form id="userForm1" class="form-horizontal" name="peopleform" novalidate>
                                                            <div class="divide-10"></div>
                                                            <p>
                                                            <div class="box-body">
                                                                <table id="example" class="display" cellspacing="0" style="width:100%">
                                                                    <thead id="abcaaa">
                                                                        <tr>
                                                                            <th>Sr. No.</th>
                                                                            <th>Employee Name</th>
                                                                            <th>Employee Phone No</th>
                                                                            <th>Employee Address</th>
                                                                            <th>Employee Designation</th>
                                                                            <th>Action</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <?php
                                                                    //echo '<pre>'; print_r($portal_user);
                                                                    if ($employee) {
                                                                        $i = 1;
                                                                        foreach ($employee as $key => $value) {
                                                                            ?> 

                                                                            <tr class="abc1111">
                                                                                <td> <?php echo $i; ?>  </td>
                                                                                <td> <?php echo $value['name']; ?></td>
                                                                                <td> <?php echo $value['phone']; ?></td>
                                                                                <td> <?php echo $value['address']; ?></td>
                                                                                <td> <?php echo $value['desigination']; ?></td>
                                                                                <td> <a href="<?php echo base_url() . 'index.php/Dashboard/employeeManagement/' . $value['id']; ?>"> <i class="fa fa-edit"> </i> </a> &nbsp;
                                                                                    <i class="fa fa-trash-o" id="<?php echo $value['id']; ?> "></i>  
                                                                                </td>

                                                                            </tr>
                                                                            <?php
                                                                            $i++;
                                                                        }
                                                                    }
                                                                    ?> 
                                                                    <tfoot>
                                                                        <tr>
                                                                            <th>Sr. No.</th>
                                                                            <th>Employee Name</th>
                                                                            <th>Employee Phone No</th>
                                                                            <th>Employee Address</th>
                                                                            <th>Employee Designation</th>
                                                                            <th>Action</th>
                                                                        </tr>
                                                                    </tfoot>
                                                                </table>
                                                            </div>
                                                            </p>
                                                        </form>
                                                    </div>


                                                </div>
                                            </div>



                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                </div>
            </div>
        </div>
    </div>           
    </section>
    <!--<script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script>-->
    <!-- start for dynamic data tables--> 
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.css" >
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/buttons.dataTables.min.css" >
    <script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.print.min.js"></script>
    <!--End Dynamic data table--> 

                                                            <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script>

        $(document).ready(function () {
            // for delete item from list
            $(".fa-trash-o").click(function (e) {
                var conf = confirm("Are you sure want to delete!");
                if (conf == true) {
                    var id = this.id;
                    $.ajax({
                        url: '<?php echo base_url(); ?>Dashboard/saveEmployeeManagement/delete',
                    type: "POST",
                    data: {'id': id,
                    },
                    success: function (response)
                    {
                        location.reload();
                    }
                });
            }
        });

// for dynamic data table add row 
        $('#example').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });

        var t = $('#example').DataTable();
        var counter = 1;
        $('#addRow').on('click', function () {
            t.row.add([
                counter + '.1',
                counter + '.2',
                counter + '.3',
                counter + '.4',
                counter + '.5'
            ]).draw(false);
            counter++;
        });
// Automatically add a first row of data
        $('#addRow').click();
// end dynamic data table here
    });
</script>



<script>




    $(document).ready(function () {
        // for calendar
        $.datetimepicker.setLocale('en');

//                                            $('#startDateSearch').datetimepicker({
//                                            lang:'ch',
//                                            timepicker:false,
//                                            format:'Y-m-d',
//                                          });
//                                            $('#endDateSearch').datetimepicker({
//                                            lang:'ch',
//                                            timepicker:false,
//                                            format:'Y-m-d',
//                                           });
//                                           
//                                           
        $('#dob1').datepicker({
            dateFormat: 'yy-mm-dd ',
        });

        $('#endDateSearch').datepicker({
            dateFormat: 'yy-mm-dd ',
        });
//                                           
        $('#dob').datetimepicker({
            lang: 'ch',
            timepicker: false,
            format: 'Y-m-d',
        });
        $('#edate').datetimepicker({
            lang: 'ch',
            timepicker: false,
            format: 'Y-m-d',
        });
        // for start date and end date
//                                            $('#StartTime_emsh_d_sqt').datetimepicker({
//                                            datepicker: false,
//                                            format: 'H:i',
//                                            step:10,
//                                          });

//                                          $('#StartTime_emsh_d_sqt').timepicker({
//                                          // dateFormat: 'yy-mm-dd ',
//                                             onClose: function() { 
//                                              alert($('#StartTime_emsh_d_sqt').val());
//                                              
//                                            $('#StartTime_emsh_d_sqt').trigger('blur');
//                                            }
//                                          });

//                                           $('#EndTime_emsh_d_sqt').timepicker({
//                                          // dateFormat: 'yy-mm-dd ',
//                                           });

//                                           $('#EndTime_emsh_d_sqt').datetimepicker({
//                                            datepicker: false,
//                                            format: 'H:i',
//                                            step:10,
//                                          });

    });

</script>


