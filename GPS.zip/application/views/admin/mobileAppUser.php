
<style>

    .onoffswitch {
        position: relative; width: 90px;
        -webkit-user-select:none; -moz-user-select:none; -ms-user-select: none;
    }
    .onoffswitch-checkbox {
        display: none;
    }
    .onoffswitch-label {
        display: block; overflow: hidden; cursor: pointer;
        border: 2px solid #999999; border-radius: 20px;
    }
    .onoffswitch-inner {
        display: block; width: 200%; margin-left: -100%;
        transition: margin 0.3s ease-in 0s;
    }
    .onoffswitch-inner:before, .onoffswitch-inner:after {
        display: block; float: left; width: 50%; height: 30px; padding: 0; line-height: 30px;
        font-size: 14px; color: white; font-family: Trebuchet, Arial, sans-serif; font-weight: bold;
        box-sizing: border-box;
    }
    .onoffswitch-inner:before {
        content: "ON";
        padding-left: 10px;
        background-color: #34A7C1; color: #FFFFFF;
    }
    .onoffswitch-inner:after {
        content: "OFF";
        padding-right: 10px;
        background-color: #EEEEEE; color: #999999;
        text-align: right;
    }
    .onoffswitch-switch {
        display: block; width: 18px; margin: 6px;
        background: #FFFFFF;
        position: absolute; top: 0; bottom: 0;
        right: 56px;
        border: 2px solid #999999; border-radius: 20px;
        transition: all 0.3s ease-in 0s; 
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-inner {
        margin-left: 0;
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-switch {
        right: 0px; 
    }

    div.upload {
        width: 157px;
        height: 57px;
        overflow: hidden;
        background-image: url('<?php echo base_url(); ?>/assets/img/upload.png');
    }

    div.upload input {
        display: block !important;
        width: 157px !important;
        height: 57px !important;
        opacity: 0 !important;
        overflow: hidden !important;
    }

</style>





<!--https://lh6.googleusercontent.com/-dqTIJRTqEAQ/UJaofTQm3hI/AAAAAAAABHo/w7ruR1SOIsA/s157/upload.png-->

<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/Dashboard/Admin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Mobile App User  </h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>

                                            </div>
                                        </div>
                                        <div class="box-body">

                                            <div class="tabbable">
                                                <div class="tab-content">
                                                    <form id="userForm1" class="form-horizontal" name="peopleform" novalidate>
                                                        <div class="divide-10"></div>
                                                        <p>
                                                        <div class="box-body">

                                                            <div style="height:50px;">

                                                                <table>
                                                                    <tr>
                                                                        <td > <b>User Information </b> &nbsp; &nbsp; </td>
                                                                        <td>  
                                                                            <select id="min" name="min" class="form-control" style="width:80px;"> 
                                                                                <option value='Main'>Main</option>
                                                                                <option value='Sub'>Sub</option>
                                                                            </select>
                                                                        </td>

                                                                    </tr>
                                                                </table>


                                                            </div>
    <!--                                                                <tbody><tr>
                                                                    <td>User Information:</td>
                                                                    <td><input type="text" id="min" name="min"></td>
                                                                    <td><select id="min" name="min" class="form-control" style="width:200px;"> 
                                                                            <option value='Main'>Main</option>
                                                                            <option value='Sub'>Sub</option>
                                                                        </select></td>
                                                                       <td> <input type="text" id="myInputTextField"> 
                                                                       <select id="myInputTextField">
                                                                       <option value="Tokyo">22</option>
                                                                        <option value="55">55</option>
                                                                        </select>
                                                                        </td>
                                                                </tr>

                                                            </tbody>-->


                                                            <table id="example" class="display" cellspacing="0" style="width:100%">
                                                                <thead id="abcaaa">
                                                                    <tr>
                                                                        <th>Sr. No.</th>
                                                                        <th>User Id</th>
                                                                         <th>Phone Number</th>
                                                                        <th >User Type</th>
                                                                        <th>Mobile App</th>
                                                                    </tr>
                                                                </thead>
                                                                <?php
                                                                //echo '<pre>'; print_r($portal_user);
                                                                if ($portal_user) {
                                                                    $i = 1;
                                                                    foreach ($portal_user as $key => $value) {
                                                                        ?> 

                                                                        <tr class="abc1111">
                                                                            <td> <?php echo $i; ?>  </td>
                                                                            <td> <?php echo $value['user_id']; ?></td>
                                                                            <td> <?php echo $value['phone']; ?></td>
                                                                            <td > <?php echo $value['usertype']; ?></td>
                                                                            
                                                                            <td> 
                                                                                <?php
//                                                                                if ($value['mobile_app'] == '0') {
//                                                                                    echo "Deactivated";
//                                                                                }
                                                                                if ($value['mobile_app'] == '1') {
                                                                                    echo "Assigned";
                                                                                }
                                                                                ?>
                                                                            </td>
                                                                            
                                                                            

                                                                        </tr>
                                                                        <?php
                                                                        $i++;
                                                                    }
                                                                }
                                                                ?> 
                                                                <tfoot>
                                                                    <tr>
                                                                         <th>Sr. No.</th>
                                                                        <th>User Id</th>
                                                                         <th>Phone Number</th>
                                                                        <th >User Type</th>
                                                                        <th>Mobile App</th>
                                                                     
                                                                    </tr>
                                                                </tfoot>
                                                            </table>



                                                        </div>


                                                        </p>
                                                    </form>


                                                </div>
                                            </div>



                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                </div>
            </div>
        </div>
    </div>           
    </section>
    <!--<script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script>-->
    <!-- start for dynamic data tables--> 
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.css" >
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/buttons.dataTables.min.css" >
    <script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.flash.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datatable/buttons.print.min.js"></script>
    <!--End Dynamic data table--> 

                                                                                <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script>
        /* Custom filtering function which will search data in column four between two values */
        $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min').val();
                    var max = $('#max').val();
                    var age = data[3]; // use data for the age column
                    if ((min) == age) {
                        return true;
                    }
                    return false;
                }
        );
        // end custom add table 


        $(document).ready(function () {
            // for delete item from list
            $(".fa-trash-o").click(function (e) {
                var conf = confirm("Are you sure want to delete!");
                if (conf == true) {
                    var id = this.id;
                    $.ajax({
                        url: '<?php echo base_url(); ?>Dashboard/saveUser/delete',
                        type: "POST",
                        data: {'id': id,
                        },
                        success: function (response)
                        {
                            location.reload();
                        }
                    });
                }
            });

            // search for type 
            $("#usType").change(function (e) {
                //alert(this.value);
                $.ajax({
                    url: '<?php echo base_url(); ?>Dashboard/addUser1',
                type: "POST",
                data: {'type': this.value,
                },
                success: function (response)
                {



                    console.log(response);
                    //alert(response);
                    // console.log(response);
                    // $("#example").hide();
                    //abc1111
                    //var asd =   "<tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr><tr><td>qqq</td><td>qqq</td></tr> <tr><td>qqq</td><td>qqq</td></tr>";
                    //$(".abc1111").hide();
                    //$(".abc1111").html(asd);


                    //location.reload();
                    //$("#New").removeClass("active");
                }
            });

        });

// for dynamic data table add row 




        $('#example').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });






        var t = $('#example').DataTable();
        var counter = 1;
        $('#addRow').on('click', function () {
            t.row.add([
                counter + '.1',
                counter + '.2',
                counter + '.3',
                counter + '.4',
                counter + '.5'
            ]).draw(false);
            counter++;
        });
// Automatically add a first row of data
        $('#addRow').click();


        var table = $('#example').DataTable();

// Event listener to the two range filtering inputs to redraw on input
        $('#min').change(function () {
            table.draw();
        });


        var oTable = $('#example').DataTable();
        $('#myInputTextField').change(function () {
            oTable.search($(this).val()).draw();

        })



// end dynamic data table here
    });
</script>


