

<div id="main-content" ng-app="myApp" ng-controller="controller_restuTakeOrder">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="#">Admin</a>
                                </li>										
                                <li>Dashboard</li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left">Dashboard</h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>



                                    <div class="col-md-12">


                                        <!-- STATISTICS -->
                                        <div class="col-md-12">
                                            <div class="row">

                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4> All Vehicle(s) </h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row" >
<!--                                                                <div style="border:1px solid coral">-->
                                                                    <image src="<?php echo base_url(); ?>assets/img/AllVeh.png"/>
                                                                    
                                                                <!--</div>-->
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4>Working Vehicle(s)</h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row">
                                                                <image src="<?php echo base_url(); ?>assets/img/AllVehgreen.png"/>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4>Not Working 30 Min</h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row">
                                                                <image src="<?php echo base_url(); ?>assets/img/AllVehred.png"/>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4>Not Working 1 Hour</h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row">
                                                               <image src="<?php echo base_url(); ?>assets/img/AllVehblue.png"/>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4>Total Not Working</h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row">
                                                                <image src="<?php echo base_url(); ?>assets/img/AllVehgrey.png"/>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-md-2">
                                                    <div class="box border primary">
                                                        <div class="box-title">
                                                            <h4>Logged In User(s)</h4>
                                                            <div class="tools">												
                                                                <a href="javascript:;" class="reload">
                                                                    <i class="fa fa-refresh"></i>
                                                                </a>
                                                                <a href="javascript:;" class="remove">
                                                                    <i class="fa fa-times"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="box-body">
                                                            <div class="sparkline-row">
                                                                 <image src="<?php echo base_url(); ?>assets/img/AllVeh.png"/>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>




                                            </div>
                                        </div>
                                        <!-- /STATISTICS -->



                                        <div class="col-md-7">
                                            <div class="box border primary">
                                                <div class="box-title">
                                                    <h4><i class="fa fa-table"></i>Vehicle(s) Details On Map</h4>
                                                    <div class="tools hidden-xs">
                                                        <a href="#box-config" data-toggle="modal" class="config">
                                                            <i class="fa fa-cog"></i>
                                                        </a>
                                                        <a href="javascript:;" class="reload">
                                                            <i class="fa fa-refresh"></i>
                                                        </a>
                                                        <a href="javascript:;" class="collapse">
                                                            <i class="fa fa-chevron-up"></i>
                                                        </a>
                                                        <a href="javascript:;" class="remove">
                                                            <i class="fa fa-times"></i>
                                                        </a>

                                                    </div>
                                                </div>
                                                <div class="box-body" >



                                                    <div style="margin-top:5px;">
                                                        <div class="text-right col-xs-4 col-sm-3 col-md-3 col-lg-3">
                                                            <div class="form-group">


                                                                <select id="userId" ng-model="userId" class="form-control" style="width:250px;" ng-change="getGpsData(userId);">
                                                                    <option>Select user </option>
                                                                    <option ng-repeat="userDatas in userData" value="{{userDatas.user_id}}">
                                                                        {{userDatas.user_id}}
                                                                    </option>


                                                                </select> 

                                                            </div>
                                                        </div>
                                                        <div class="text-right col-xs-4 col-sm-3 col-md-3 col-lg-3 ">
                                                            <div class="form-group">
                                                               <!--<input type="checkbox" name="check" ng-model="autoReferesh" class="posCheckBox"/>--> 
                                                            </div>
                                                        </div>
                                                    </div>



                                                    <div id="dvMap" style="height:450px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                                    <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                                        <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="box border primary">
                                                <div class="box-title">
                                                    <h4>User Wise Working Vehicle(s)</h4>
                                                    <div class="tools hidden-xs">
                                                        <a href="#box-config" data-toggle="modal" class="config">
                                                            <i class="fa fa-cog"></i>
                                                        </a>
                                                        <a href="javascript:;" class="reload">
                                                            <i class="fa fa-refresh"></i>
                                                        </a>
                                                        <a href="javascript:;" class="collapse">
                                                            <i class="fa fa-chevron-up"></i>
                                                        </a>
                                                        <a href="javascript:;" class="remove">
                                                            <i class="fa fa-times"></i>
                                                        </a>

                                                    </div>
                                                </div>
                                                <div class="box-body" >

                                                   


                                                    <div id="dvMap1" style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                                    <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                                        <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-7">
                                            <div class="box border primary">
                                                <div class="box-title">
                                                    <h4>Vehicle Details</h4>
                                                    <div class="tools hidden-xs">
                                                        <a href="#box-config" data-toggle="modal" class="config">
                                                            <i class="fa fa-cog"></i>
                                                        </a>
                                                        <a href="javascript:;" class="reload">
                                                            <i class="fa fa-refresh"></i>
                                                        </a>
                                                        <a href="javascript:;" class="collapse">
                                                            <i class="fa fa-chevron-up"></i>
                                                        </a>
                                                        <a href="javascript:;" class="remove">
                                                            <i class="fa fa-times"></i>
                                                        </a>

                                                    </div>
                                                </div>
                                                <div class="box-body" >




                                                    <div id="dvMap1" style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                                    <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                                        <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                                </div>
                                            </div>
                                        </div>



                                        <div class="col-md-5">
                                            <div class="box border primary">
                                                <div class="box-title">
                                                    <h4>Device Wise Working Vehicle(s)</h4>
                                                    <div class="tools hidden-xs">
                                                        <a href="#box-config" data-toggle="modal" class="config">
                                                            <i class="fa fa-cog"></i>
                                                        </a>
                                                        <a href="javascript:;" class="reload">
                                                            <i class="fa fa-refresh"></i>
                                                        </a>
                                                        <a href="javascript:;" class="collapse">
                                                            <i class="fa fa-chevron-up"></i>
                                                        </a>
                                                        <a href="javascript:;" class="remove">
                                                            <i class="fa fa-times"></i>
                                                        </a>

                                                    </div>
                                                </div>
                                                <div class="box-body" >




                                                    <div id="dvMap1" style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                                    <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                                        <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                                </div>
                                            </div>
                                        </div>




                                    </div>

                                </div>

                            </div>

                        </div>
                </div>
            </div>
        </div>           
    </section>


    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkSEXMA8K4fhZLuF1fIwBIdFoHUjYVmsk"
    type="text/javascript"></script>



    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


    <script>
                                                            var app = angular.module('myApp', []);
                                                            app.controller('controller_restuTakeOrder', function ($scope, $http, $filter, $timeout) {

                                                                //console.log('Active');
                                                                $scope.gpsData = [];
                                                                //                                                      

                                                                // function for get all user list 
                                                                $scope.getuserList = function () {
                                                                    $scope.userData = [];
                                                                    $http({
                                                                        method: 'POST',
                                                                        url: '<?php echo base_url(); ?>index.php/Dashboard/getuserList',
                                                                        data: '', //forms user object
                                                                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                                    })
                                                                            .success(function (data) {
                                                                                $scope.userData = data;
                                                                            });
                                                                    //                                    
                                                                }
                                                                $scope.getuserList();

                                                                // for getting gps data 
                                                                $scope.getGpsData = function (x) {

                                                                    $http({
                                                                        method: 'POST',
                                                                        url: '<?php echo base_url(); ?>index.php/Dashboard/getGpsData',
                                                                    data: $scope.userId, //forms user object
                                                                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                                })
                                                                        .success(function (data) {
                                                                            //console.log(data);  
                                                                            $scope.showMap(data);
                                                                            $scope.everyfiveSec();

                                                                        });

                                                            }


                                                            // function for google map 
                                                            $scope.showMap = function (x) {

                                                                $scope.gpsData = [];
                                                                // console.log(x.length); return false; 
                                                                if (x.length > 0) {
                                                                    angular.forEach(x, function (value, key) {
                                                                        $scope.gpsData.push({
                                                                            lat: value.latitude,
                                                                            lng: value.longitude,
                                                                            description: value.imino,
                                                                        });
                                                                    });
                                                                    var markers = $scope.gpsData;
                                                                } else {
                                                                    $('#dvMap').html('');
                                                                    markers = '';
                                                                }

                                                                // console.log(markers);
                                                                /*window.onload = function () {*/
                                                                var mapOptions = {
                                                                    center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
                                                                    zoom: 16,
                                                                    mapTypeId: google.maps.MapTypeId.ROADMAP
                                                                };
                                                                var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                                                                var infoWindow = new google.maps.InfoWindow();
                                                                var lat_lng = new Array();
                                                                var latlngbounds = new google.maps.LatLngBounds();
                                                                for (i = 0; i < markers.length; i++) {
                                                                    var data = markers[i]
                                                                    var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                                    lat_lng.push(myLatlng);
                                                                    var marker = new google.maps.Marker({
                                                                        position: myLatlng,
                                                                        map: map,
                                                                        title: data.title
                                                                    });
                                                                    latlngbounds.extend(marker.position);
                                                                    (function (marker, data) {
                                                                        google.maps.event.addListener(marker, "click", function (e) {
                                                                            infoWindow.setContent(data.description);
                                                                            infoWindow.open(map, marker);
                                                                        });
                                                                    })(marker, data);
                                                                }
                                                                map.setCenter(latlngbounds.getCenter());
                                                                map.fitBounds(latlngbounds);
                                                                //}


                                                                $scope.gpsData = [];

                                                                //console.log($scope.gpsData);

                                                            }



                                                            //for playing audio every five second
                                                            $scope.everyfiveSec = function () {
                                                                //if($scope.autoReferesh==true){
                                                                setTimeout(function () {
                                                                    $scope.againplay();
                                                                    $scope.getGpsData();
                                                                    $scope.gpsData = [];
                                                                }, 25000);
                                                                //}
                                                            }

                                                            $scope.againplay = function ()
                                                            {
                                                                $scope.getGpsData();
                                                                $scope.gpsData = [];
                                                                $scope.everyfiveSec();
                                                                // console.log('aa');
                                                            }
                                                            // $scope.everyfiveSec();








                                                        });
</script>