<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>World Track</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Le styles -->



        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
        <!--    <link rel="stylesheet" href="css/loader-style.css">-->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css">
        <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">

        <link href="<?php echo base_url();?>assets/css/awwward.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/skin-select.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/dipricon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/entypo-icon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/maki-icon.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/jquery-easypiechart.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/slidebars.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/jquery-pnotify.css" rel="stylesheet">
        <link href="<?php echo base_url();?>assets/css/pacethemecnter.css" rel="stylesheet">

        <link href="<?php echo base_url();?>assets/css/tooltipster.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/number-pb.css">
        <link href="<?php echo base_url();?>assets/css/weather-icon.css" rel="stylesheet">

        <link href="<?php echo base_url();?>assets/css/open-sans.css" rel="stylesheet">
        <link href="http://localhost/gpscrnt/assets/js/datetimepicker-master/jquery.datetimepicker.css" rel="stylesheet">
        
           <!-- <style type="text/css">
            canvas#canvas4 {
                position: relative;
                top: 20px;
            }
            </style>-->

<script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>


        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
            <![endif]-->
        <!-- Fav and touch icons -->
<!--        <link rel="shortcut icon" href="assets/ico/minus.png">-->
    </head>

    <body>
        <div id="awwwards" class="right black"><a href="#" target="_blank">best websites of the world</a></div>
        <!-- Preloader -->
        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>
        <!-- TOP NAVBAR -->
        <nav role="navigation" class="navbar navbar-static-top" style="margin-left: 240px;">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="entypo-menu"></span>
                    </button>
                    <button class="navbar-toggle toggle-menu-mobile toggle-left" type="button">
                        <span class="entypo-list-add"></span>
                    </button>




                    <div id="logo-mobile" class="visible-xs">
                        <h1>Apricot<span>v1.3</span></h1>
                    </div>

                </div>


                <!-- Collect the nav links, forms, and other content for toggling -->
                <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">

<!--                        <li class="dropdown">

                            <a data-toggle="dropdown" class="dropdown-toggle" href="#"><i style="font-size:20px;" class="fa fa-comments-o"></i><div class="noft-red">23</div></a>


                            <ul style="margin: 11px 0px 0px 9px; position: absolute; left: 0px; top: 53px;" role="menu" class="dropdown-menu dropdown-wrap">
                                <li>
                                    <a href="#">
                                        <img alt="" class="img-msg img-circle" src="<?php echo base_url();?>assets/img/1.jpg">Jhon Doe <b>Just Now</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <img alt="" class="img-msg img-circle" src="<?php echo base_url();?>assets/img/5.jpg">Jeniffer <b>3 Min Ago</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <img alt="" class="img-msg img-circle" src="<?php echo base_url();?>assets/img/2.jpg">Dave <b>2 Hours Ago</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <img alt="" class="img-msg img-circle" src="<?php echo base_url();?>assets/img/3.jpg"><i>Keanu</i>  <b>1 Day Ago</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <img alt="" class="img-msg img-circle" src="<?php echo base_url();?>assets/img/4.jpg"><i>Masashi</i>  <b>2 Month Ago</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <div>See All Messege</div>
                                </li>
                            </ul>
                        </li>-->
<!--                        <li class="">

                            <a data-toggle="dropdown" class="dropdown-toggle" href="#"><i style="font-size:19px;" class="fa fa-exclamation-triangle" data-original-title="" title=""></i><div class="noft-green">5</div></a>
                            <ul style="margin: 12px 0px 0px; position: absolute; left: 0px; top: 53px;" role="menu" class="dropdown-menu dropdown-wrap">
                                <li>
                                    <a href="#">
                                        <span style="background:#DF2135" class="noft-icon maki-bus"></span><i>From Station</i>  <b>01B</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <span style="background:#AB6DB0" class="noft-icon maki-ferry"></span><i>Departing at</i>  <b>9:00 AM</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <span style="background:#FFA200" class="noft-icon maki-aboveground-rail"></span><i>Delay for</i>  <b>09 Min</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <span style="background:#86C440" class="noft-icon maki-airport"></span><i>Take of</i>  <b>08:30 AM</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <a href="#">
                                        <span style="background:#0DB8DF" class="noft-icon maki-bicycle"></span><i>Take of</i>  <b>08:30 AM</b>
                                    </a>
                                </li>
                                <li class="divider"></li>
                                <li>
                                    <div>See All Notification</div>
                                </li>
                            </ul>
                        </li>-->
<!--                        <li><a href="#"><i data-toggle="tooltip" data-placement="bottom" title="" style="font-size:20px;" class="fa fa-life-ring" data-original-title="Help"></i></a>
                        </li>-->

                    </ul>
                    <div id="nt-title-container" class="navbar-left running-text visible-lg">
                        <ul class="date-top">
                            <li class="entypo-calendar" style="margin-right:5px"></li>
                            <li id="Date">Tue,  17 January 2017</li>


                        </ul>

                        <ul id="digital-clock" class="digital">
                            <li class="entypo-clock" style="margin-right:5px"></li>
                            <li class="hour">16</li>
                            <li>:</li>
                            <li class="min">20</li>
                            <li>:</li>
                            <li class="sec">56</li>
                            <li class="meridiem">PM</li>
                        </ul>
                        <ul id="nt-title" style="height: 18px; overflow: hidden;">









                            <li style="margin-top: 0px;"><i class="wi-day-lightning"></i>&nbsp;&nbsp;Yogyakarta&nbsp;
                                <b>85</b><i class="wi-fahrenheit"></i>&nbsp;; Tonight- 72 �F (22.2 �C)
                            </li><li style="margin-top: 0px;"><i class="wi-day-lightning"></i>&nbsp;&nbsp;Sttugart&nbsp;
                                <b>85</b><i class="wi-fahrenheit"></i>&nbsp;; 15km/h
                            </li><li style="margin-top: 0px;"><i class="wi-day-lightning"></i>&nbsp;&nbsp;Muchen&nbsp;
                                <b>85</b><i class="wi-fahrenheit"></i>&nbsp;; 15km/h
                            </li><li style="margin-top: 0px;"><i class="wi-day-lightning"></i>&nbsp;&nbsp;Frankurt&nbsp;
                                <b>85</b><i class="wi-fahrenheit"></i>&nbsp;; 15km/h
                            </li><li style="margin-top: 0px;"><i class="wi-day-lightning"></i>&nbsp;&nbsp;Berlin&nbsp;
                                <b>85</b><i class="wi-fahrenheit"></i>&nbsp;; 15km/h
                            </li></ul>
                    </div>

                    <ul style="margin-right:0;" class="nav navbar-nav navbar-right">
                        <li class="">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <img alt="" class="admin-pic img-circle" src="<?php echo base_url();?>assets/img/10.jpg">Hi, Dave Mattew <b class="caret"></b>
                            </a>
                            <ul style="margin-top:14px;" role="menu" class="dropdown-setting dropdown-menu">
                                <li>
                                    <a href="#">
                                        <span class="entypo-user"></span>&nbsp;&nbsp;My Profile</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="entypo-vcard"></span>&nbsp;&nbsp;Account Setting</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <span class="entypo-lifebuoy"></span>&nbsp;&nbsp;Help</a>
                                </li>
                                <li class="divider"></li>
                                <li>

                                        <span class="entypo-basket"></span>&nbsp;&nbsp; Purchase</a>
                                </li>
                            </ul>
                        </li>
<!--                        <li>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="icon-gear"></span>&#160;&#160;Setting</a>
                            <ul role="menu" class="dropdown-setting dropdown-menu">

                                <li class="theme-bg">
                                    <div id="button-bg"></div>
                                    <div id="button-bg2"></div>
                                    <div id="button-bg3"></div>
                                    <div id="button-bg5"></div>
                                    <div id="button-bg6"></div>
                                    <div id="button-bg7"></div>
                                    <div id="button-bg8"></div>
                                    <div id="button-bg9"></div>
                                    <div id="button-bg10"></div>
                                    <div id="button-bg11"></div>
                                    <div id="button-bg12"></div>
                                    <div id="button-bg13"></div>
                                </li>
                            </ul>
                        </li>-->
                        <li class="hidden-xs">
                            <!-- <a class="toggle-left" href="#">
                                 <span style="font-size:20px;" class="entypo-list-add"></span>
                             </a>-->

                            <button type="button" class="btn popbut" data-toggle="modal" data-target="#myModal">
                                <span style="font-size:20px;" class="entypo-list-add"></span>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index:1000;">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="myModalLabel">Modal title</h4>
                                        </div>
                                        <div class="modal-body">


                                            <div class="table-responsive" style="overflow:auto; width:550px; height:300px;">
                                                <table class="table table-bordered" >
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td></tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                        <td>7</td>
                                                        <td>8</td>
                                                        <td>9</td>
                                                        <td>10</td>
                                                        <td>11</td>
                                                        <td>12</td>
                                                        <td>13</td>
                                                        <td>1</td>
                                                        <td>2</td>
                                                        <td>3</td>
                                                        <td>4</td>
                                                        <td>5</td>
                                                        <td>6</td>
                                                    </tr>




                                                </table>
                                            </div>  










                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <button type="button" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>































                        </li>
                    </ul>

                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>

        <!-- /END OF TOP NAVBAR -->

        <!-- SIDE MENU -->
        <div id="skin-select" style="left: 0px;">
            <div id="logo">
                <h1>World Track<span>v1.3</span></h1>
            </div>

            <a id="toggle" class="">
                <span class="entypo-menu"></span>
            </a>
            <div class="dark" style="visibility: visible;">
                <form action="#">
                    <span>
                        <input type="text" name="search" value="" class="search rounded id_search" placeholder="Search Menu..." autofocus>
                    </span>
                </form>
            </div>

            <div class="search-hover" style="display: none;">
                <form id="demo-2">
                    <input type="search" placeholder="Search Menu..." class="id_search">
                </form>
            </div>




            <div class="skin-part" style="visibility: visible;">
                <div id="tree-wrap">
                    <div class="side-bar">


                        <ul id="menu-showhide" class="topnav menu-left-nest">
                               
                              
                              <li>
                                <a class="tooltip-tip ajax-load" href="<?php echo base_url(); ?>index.php/Dashboard/admin" title="Dashboard">
                                    <i class="icon-window"></i>
                                    <span>Dashboard</span>

                                </a>
                              </li>
                              
                              
                               <li>
                            <a class="tooltip-tip" href="#" title="Extra Pages">
                                <i class="icon-document-new"></i>
                                <span>User Management</span>
                            </a>
                            <ul>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="<?php echo base_url(); ?>index.php/Dashboard/adduser" title="Blank Page"><i class="icon-media-record"></i><span>Add/Edit User Details</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Mobile App User</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Main User Details</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="pricing_table.html" title="Pricing Table"><i class="fontawesome-money"></i><span>Barred User Details</span></a>
                                </li>
                               
                            </ul>
                        </li>


                         
                           
                         
                             
                              <li>
                            <a class="tooltip-tip" href="#" title="Extra Pages">
                                <i class="icon-document-new"></i>
                              <span>Device Management</span>
                            </a>
                            <ul>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="<?php echo base_url(); ?>index.php/Dashboard/adduser" title="Blank Page"><i class="icon-media-record"></i><span>Add/Edit Device Details</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Barred Device Details</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Vehicle Allocation</span></a>
                                </li>
                               
                               
                            </ul>
                        </li>
                        
                         <li>
                            <a class="tooltip-tip" href="#" title="Extra Pages">
                                <i class="icon-document-new"></i>
                              <span>Reports</span>
                            </a>
                            <ul>
                               
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Device Added  Details</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Unknown Vehicles</span></a>
                                </li>
                               <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Alert Log</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Vehicle Specific Details</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Sim Operator Details</span></a>
                                </li>
                               
                            </ul>
                        </li>
                             
                               <li>
                            <a class="tooltip-tip" href="#" title="Extra Pages">
                                <i class="icon-document-new"></i>
                              <span>Advance Setting</span>
                            </a>
                            <ul>
                               
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>User Credential</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Authorized Setting</span></a>
                                </li>
                               <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Fuel Caliberation</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>SMS Allocation</span></a>
                                </li>
                                 
                               
                            </ul>
                        </li>
                             
                        
                         <li>
                            <a class="tooltip-tip" href="#" title="Extra Pages">
                                <i class="icon-document-new"></i>
                              <span>Admin</span>
                            </a>
                            <ul>
                               
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Mobile Portal Features</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Device Type</span></a>
                                </li>
                               <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Remove Devices</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Menu Allocation</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Employee Management</span></a>
                                </li>
                                <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Banner Manage</span></a>
                                </li>
                               <li>
                                    <a class="tooltip-tip2 ajax-load" href="invoice.html" title="Invoice"><i class="entypo-newspaper"></i><span>Add/Edit Live Chat</span></a>
                                </li>
                                 <li>
                                    <a class="tooltip-tip2 ajax-load" href="profile.html" title="Profile Page"><i class="icon-user"></i><span>Payment Transaction</span></a>
                                </li>
                                 
                               
                            </ul>
                        </li>
                        
                             
                           
<!--                            <li>
                                <a class="tooltip-tip" href="#" title="Form">
                                    <i class="icon-document"></i>
                                    <span>Form</span>
                                </a>
                                <ul>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="form-element.html" title="Form Elements"><i class="icon-document-edit"></i><span>Form Elements</span></a>
                                    </li>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="andvance-form.html" title="Andvance Form"><i class="icon-map"></i><span>Andvance Form</span></a>
                                    </li>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="text-editor.html" title="Text Editor"><i class="icon-code"></i><span>Text Editor</span></a>
                                    </li>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="file-upload.html" title="File Upload"><i class="icon-upload"></i><span>File Upload</span></a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a class="tooltip-tip" href="#" title="Tables">
                                    <i class="icon-view-thumb"></i>
                                    <span>Tables</span>
                                </a>
                                <ul>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="table-static.html" title="Table Static"><i class="entypo-layout"></i><span>Table Static</span></a>
                                    </li>
                                    <li>
                                        <a class="tooltip-tip2 ajax-load" href="table-dynamic.html" title="Table Dynamic"><i class="entypo-menu"></i><span>Table Dynamic</span></a>
                                    </li>
                                </ul>
                            </li>

                            <li>
                                <a class="tooltip-tip ajax-load" href="map.html" title="Map">
                                    <i class="icon-location"></i>
                                    <span>Map</span>

                                </a>
                            </li>-->
                        </ul>


                        <div class="side-dash">
                            <h3>
                                <span>Device</span>
                            </h3>
                            <ul class="side-dashh-list">
                                <li>Avg. Traffic
                                    <span>25k<i style="color:#44BBC1;" class="fa fa-arrow-circle-up"></i>
                                    </span>
                                </li>
                                <li>Visitors
                                    <span>80%<i style="color:#AB6DB0;" class="fa fa-arrow-circle-down"></i>
                                    </span>
                                </li>
                                <li>Convertion Rate
                                    <span>13m<i style="color:#19A1F9;" class="fa fa-arrow-circle-up"></i>
                                    </span>
                                </li>
                            </ul>
                            <h3>
                                <span>Traffic</span>
                            </h3>
                            <ul class="side-bar-list">
                                <li>Avg. Traffic
                                    <div class="linebar">5,7,8,9,3,5,3,8,5</div>
                                </li>
                                <li>Visitors
                                    <div class="linebar2">9,7,8,9,5,9,6,8,7</div>
                                </li>
                                <li>Convertion Rate
                                    <div class="linebar3">5,7,8,9,3,5,3,8,5</div>
                                </li>
                            </ul>
                            <h3>
                                <span>Visitors</span>
                            </h3>
                            <div id="g1" style="height:180px" class="gauge"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END OF SIDE MENU -->



    