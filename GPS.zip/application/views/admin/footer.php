<!-- RIGHT SLIDER CONTENT -->
<div class="sb-slidebar sb-right">
    <div class="right-wrapper">
        <div class="row">
            <h3>
                <span><i class="entypo-gauge"></i>&nbsp;&nbsp;MAIN WIDGET</span>
            </h3>
            <div class="col-lg-12">

                <div class="widget-knob">
                    <span class="chart" style="position:relative" data-percent="86">
                        <span class="percent"></span>
                    </span>
                </div>
                <div class="widget-def">
                    <b>Distance traveled</b>
                    <br>
                    <i>86% to the check point</i>
                </div>

                <div class="widget-knob">
                    <span class="speed-car" style="position:relative" data-percent="60">
                        <span class="percent2"></span>
                    </span>
                </div>
                <div class="widget-def">
                    <b>The average speed</b>
                    <br>
                    <i>30KM/h avarage speed</i>
                </div>


                <div class="widget-knob">
                    <span class="overall" style="position:relative" data-percent="25">
                        <span class="percent3"></span>
                    </span>
                </div>
                <div class="widget-def">
                    <b>Overall result</b>
                    <br>
                    <i>30KM/h avarage Result</i>
                </div>
            </div>
        </div>
    </div>


</div>



<!-- END OF RIGHT SLIDER CONTENT-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/onlinejquery.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.velocity.js"></script>
<script src="<?php echo base_url(); ?>assets/js/number-pb.js"></script>
<script src="<?php echo base_url(); ?>assets/js/progress-app.js"></script>



<!-- MAIN EFFECT -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/preloader.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/load.js"></script>



<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main.js"></script>


<!-- DATE time PICKER -->


<!-- GAGE -->


  <!--  <script type="text/javascript" src="js/jquery-float.js"></script>
    <script type="text/javascript" src="js/jquery-flot-resize.js"></script>
    <script type="text/javascript" src="js/realtime.js"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/canvasgauge-custom.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-countdown.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jhere-custom.js"></script>
<script>
    var gauge4 = new Gauge("canvas4", {
        'mode': 'needle',
        'range': {
            'min': 0,
            'max': 90
        }
    });
    gauge4.draw(Math.floor(Math.random() * 90));
    var run = setInterval(function () {
        gauge4.draw(Math.floor(Math.random() * 90));
    }, 3500);
</script>
<script type="text/javascript">
    /* Javascript
     *
     * See http://jhere.net/docs.html for full documentation
     */
    $(window).on('load', function () {
        $('#mapContainer').jHERE({
            center: [52.500556, 13.398889],
            type: 'smart',
            zoom: 10
        }).jHERE('marker', [52.500556, 13.338889], {
            // icon: 'assets/img/marker.png',
            anchor: {
                x: 12,
                y: 32
            },
            click: function () {
                alert('Hallo from Berlin!');
            }
        })
                .jHERE('route', [52.711, 13.011], [52.514, 13.453], {
                    color: '#FFA200',
                    marker: {
                        fill: '#86c440',
                        text: '#'
                    }
                });
    });
</script>
<script type="text/javascript">
    var output, started, duration, desired;

    // Constants
    duration = 5000;
    desired = '50';

    // Initial setup
    output = $('#speed');
    started = new Date().getTime();

    // Animate!
    animationTimer = setInterval(function () {
        // If the value is what we want, stop animating
        // or if the duration has been exceeded, stop animating
        if (output.text().trim() === desired || new Date().getTime() - started > duration) {
            console.log('animating');
            // Generate a random string to use for the next animation step
            output.text('' + Math.floor(Math.random() * 60)

                    );

        } else {
            console.log('animating');
            // Generate a random string to use for the next animation step
            output.text('' + Math.floor(Math.random() * 120)

                    );
        }
    }, 5000);
</script>
<script type="text/javascript">
    $('#getting-started').countdown('2015/01/01', function (event) {
        $(this).html(event.strftime(
                '<span>%M</span>' + '<span class="start-min">:</span>' + '<span class="start-min">%S</span>'));
    });
</script>



<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.css" >
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/js/datatable/buttons.dataTables.min.css" >



<script src="<?php echo base_url(); ?>assets/js/datatable/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/buttons.flash.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/datatable/buttons.print.min.js"></script>

 <script src="<?php echo base_url(); ?>assets/step/build-step/jquery.steps.js"></script>  

<!-- /MAIN EFFECT -->
<!-- GAGE -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/toggle-close.js"></script>
<script src="<?php echo base_url(); ?>assets/js/footable.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/footable-sort.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/footable-filter.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/footable-paginate.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/footable-paginate.js" type="text/javascript"></script>

<script src="<?php echo base_url(); ?>assets/js/datetimepicker-master/build/jquery.datetimepicker.full.js"></script>
<script>
      
    $(document).ready(function () {
        // for calendar
        $.datetimepicker.setLocale('en');
        $('#don').datetimepicker({
            lang: 'ch',
            timepicker: false,
            format: 'm-d-Y',
        });
        
       $('#validtillexpiry').datetimepicker({
            lang: 'ch',
            timepicker: false,
            format: 'm-d-Y',
        });

    });

</script>


    
    

</body>

</html>
