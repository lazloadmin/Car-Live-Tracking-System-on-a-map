<!--  PAPER WRAP -->
<div class="wrap-fluid" style="width: auto; margin-left: 250px;" ng-app="myApp" ng-controller="controller_restuTakeOrder">
    <div class="container-fluid paper-wrap bevel tlbr">
        <!-- CONTENT -->
        <!--TITLE -->
        <div class="row">
            <div id="paper-top">
                <div class="col-lg-3">
                    <h2 class="tittle-content-header">
                        <i class="icon-window"></i> 
                        <span>Dashboard
                        </span>
                    </h2>

                </div>

                <div class="col-lg-7">
                    <div class="devider-vertical visible-lg"></div>
                    <div class="tittle-middle-header">
                        <div class="alert">
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!--/ TITLE -->

        <!-- BREADCRUMB -->
        <ul id="breadcrumb">
            <li>
                <span class="entypo-home"></span>
            </li>
            <li><i class="fa fa-lg fa-angle-right"></i>
            </li>
            <li><a href="<?php echo base_url(); ?>index.php/Dashboard/admin" title="Dashboard">Home</a>
            </li>
            <li><i class="fa fa-lg fa-angle-right"></i>
            </li>
            <li><a href="<?php echo base_url(); ?>index.php/Dashboard/admin" title="Dashboard">Dashboard</a>
            </li>
            <li class="pull-right">
                <div class="input-group input-widget">

                    <!--<input type="text" name="vehicalNo" style="width:200px;" id="vehicalNo" ng-model="vehicalNo" class="form-control" placeholder="Vehical Number"/>-->
                </div>
            </li>
        </ul>

        <!-- END OF BREADCRUMB -->


        <!--
                <div id="paper-middle">
                    <div id="mapContainer_">
                        <div id="dvMap" style="height:400px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>
                    </div>
                </div>-->

        <!--  DEVICE MANAGER -->
        <div class="content-wrap">
            <div class="row">

                <!--all vehical-->
                <div class="col-lg-3">
                    <div class="profit" id="profitClose">
                        <div class="headline ">
                            <h3>
                                <span>
                                    <i class="fa fa-truck"></i> &#160;&#160; All Vehicle(s)</span>
                            </h3>
                            <div class="titleClose">
                                <a href="#profitClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>

                        <div class="value">
                            <!--<span class="pull-left"> <i class="fa fa-clock-o clock-position"></i>-->
                            </span>
                            <div id="getting-started1111">
                                200
                            </div>
                        </div>

                        <div class="progress-tinny">
                            <div style="width: 50%" class="bar"></div>
                        </div>
                        <div class="profit-line">
<!--                                    <i class="fa fa-caret-up fa-lg"></i>-->
                        </div>
                    </div>
                </div>


                <!--all working vehical-->




                <div class="col-lg-3">
                    <div class="order" id="orderClose">
                        <div class="headline ">
                            <h3>
                                <span>
                                    <i class="fa fa-truck"></i> &#160;&#160; Working Vehicle(s)</span>
                            </h3>
                            <div class="titleClose">
                                <a href="#orderClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>
                        <div class="value" id="workingVehical">
                            180
                        </div>

                        <div class="progress-tinny">
                            <div style="width: 10%" class="bar"></div>
                        </div>
                        <div class="profit-line">
                            <!--<i class="fa fa-caret-down fa-lg"></i>&#160;&#160;Rate : 20 Plane/Hour</div>-->
                        </div>
                    </div>
                </div>




                <!--not working 30 minutes-->

                <div class="col-lg-3">
                    <div class="revenue" id="revenueClose">
                        <div class="headline ">
                            <h3>
                                <span>  <i class="fa fa-truck"></i> &#160;&#160; Not Working 30 Min</span>
                            </h3>
                            <div class="titleClose">
                                <a href="#revenueClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>
                        <div class="value">
                            <!--<span class="pull-left"><i class="entypo-gauge gauge-position"></i>-->
                            </span>
<!--                            <canvas id="canvas4111" width="70" height="70"></canvas>-->
                            <div id="getting-started1111">
                                10
                            </div>
<!--                            <i class="pull-right">fdj</i>-->

                        </div>

                        <div class="progress-tinny">
                            <!--                            <div style="width: 25%" class="bar"></div>-->
                        </div>
                        <div class="profit-line">
<!--                            <i class="fa fa-caret-down fa-lg"></i>&#160;&#160;Rate : 20 km/Hour-->
                        </div>
                    </div>
                </div>



                <!--Not Working 1 Hour-->


                <div class="col-lg-3">
                    <div class=" member" id="memberClose">
                        <div class="headline ">
                            <h3>
                                <span>
                                    <i class="fa fa-truck"></i>
                                    &#160;&#160;  Not Working 1 Hour
                                </span>
                            </h3>
                            <div class="titleClose">
                                <a href="#memberClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>
                        <div class="value">
                            <span>
                            </span>20
                            <!--<b>Sent</b>-->

                        </div>
                        <div class="progress-tinny">
                            <div style="width: 50%" class="bar"></div>
                        </div>
                        <div class="profit-line">
                            <!--<span class="entypo-down-circled"></span>&#160;50% From Last Month</div>-->
                        </div>
                    </div>


                </div>
            </div>
        </div>





        <!--  / DEVICE MANAGER -->
        <!--  DEVICE MANAGER -->
        <div class="content-wrap">
            <div class="row">
                <div class="col-lg-3">
                    <div class="profit" id="profitClose">
                        <div class="headline ">
                            <h3>
                                <span>
                                    <i class="fa fa-truck"></i>
                                    &#160;&#160; Total Not Working</span>
                            </h3>
                            <div class="titleClose">
                                <a href="#profitClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>

                        <div class="value">
                            <span class="pull-left">
                                <!--<i class="fa fa-clock-o clock-position"></i>-->
                            </span>
                            <div id="getting-startedqqqq">
                                15
                            </div>
                        </div>

                        <div class="progress-tinny">
                            <div style="width: 50%" class="bar"></div>
                        </div>
                        <div class="profit-line">
<!--                                    <i class="fa fa-caret-up fa-lg"></i>-->
                        </div>
                    </div>
                </div>

                <!--login user--> 


                <div class="col-lg-3">
                    <div class="revenue" id="revenueClose">
                        <div class="headline ">

                            <h3>
                                <span>
                                    <i class="fa fa-user"></i>&#160;&#160; Logged In User(s) </span>
                            </h3>

                            <div class="titleClose">
                                <a href="#revenueClose" class="gone">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                        </div>
                        <div class="value">
                            <span class="pull-left">
<!--                                <i class="entypo-gauge gauge-position"></i>-->
                            </span>
                            2
                            <!--<canvas id="canvas4" width="70" height="70"></canvas>-->
<!--                            <i class="pull-right">/Km</i>-->

                        </div>


                        <div class="progress-tinny">
                            <div style="width: 25%" class="bar"></div>
                        </div>
                        <div class="profit-line">
<!--                            <i class="fa fa-caret-down fa-lg"></i>&#160;&#160;Rate : 20 km/Hour</div>-->
                        </div>
                    </div>
                </div>




                <!--                <div class="col-lg-3">
                                    <div class="order" id="orderClose">
                                        <div class="headline ">
                                            <h3>
                                                <span>
                                                    <i class="maki-airport"></i>&#160;&#160;AIR PORT TRAFFIC</span>
                                            </h3>
                                            <div class="titleClose">
                                                <a href="#orderClose" class="gone">
                                                    <span class="entypo-cancel"></span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="value">
                                            <span><i class="fa fa-plane fa-2x"></i>
                                            </span><b id="speed"></b><b>Take Off</b>
                
                                        </div>
                
                                        <div class="progress-tinny">
                                            <div style="width: 10%" class="bar"></div>
                                        </div>
                                        <div class="profit-line">
                                            <i class="fa fa-caret-down fa-lg"></i>&#160;&#160;Rate : 20 Plane/Hour</div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class=" member" id="memberClose">
                                        <div class="headline ">
                                            <h3>
                                                <span>
                                                    <i class="fa fa-truck"></i>
                                                    &#160;&#160;CARGO
                                                </span>
                                            </h3>
                                            <div class="titleClose">
                                                <a href="#memberClose" class="gone">
                                                    <span class="entypo-cancel"></span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="value">
                                            <span><i class="maki-warehouse"></i>
                                            </span>45<b>Sent</b>
                
                                        </div>
                                        <div class="progress-tinny">
                                            <div style="width: 50%" class="bar"></div>
                                        </div>
                                        <div class="profit-line">
                                            <span class="entypo-down-circled"></span>&#160;50% From Last Month</div>
                                    </div>
                                </div>-->


            </div>
        </div>
        <!--  / DEVICE MANAGER -->









        <div class="content-wrap">
            <div class="row">
                <div class="col-sm-12">
                    <div class="nest" id="tableStaticClose">
                        <div class="title-alt">
                            <h6> Position Map </h6>
                            <div class="titleClose">
                                <a class="gone" href="#tableStaticClose">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                            <div class="titleToggle">
                                <a class="nav-toggle-alt" href="#tableStatic">
                                    <span class="entypo-up-open"></span>
                                </a>
                            </div>
                        </div>

                        <div class="body-nest" id="tableStatic">


                            <section id="flip-scroll">
                                <div class="table-responsive" style="overflow:auto; width:100%; height:500px;">
                                    <input type="text" name="vehicalNo" style="width:200px;" id="vehicalNo" ng-model="vehicalNo" class="form-control" placeholder="Vehical Number"/>
                                    <div id="paper-middle">
                                        <div id="mapContainer_">
                                            <div id="dvMap" style="height:450px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>
                                        </div>
                                    </div>
                                </div>
                            </section>

                        </div>

                    </div>


                </div>

            </div>
        </div>


        <!--user wise working vehical-->
        <div class="content-wrap">
            <div class="row">


                <div class="col-sm-12">

                    <div class="nest" id="tableStaticClose">
                        <div class="title-alt">

                            <h6> User Wise Working Vehicle(s) </h6>
                            <div class="titleClose">
                                <a class="gone" href="#tableStaticClose">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                            <div class="titleToggle">
                                <a class="nav-toggle-alt" href="#tableStatic">
                                    <span class="entypo-up-open"></span>
                                </a>
                            </div>

                        </div>

                        <div class="body-nest" id="tableStatic">


                            <section id="flip-scroll">
                                <div class="table-responsive" style="overflow:auto; width:100%; height:300px;">
                                    <table class="table table-bordered table-striped cf">
                                        <thead class="cf">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>User Id</th>
                                                <th> Working Vehicle/All Vehicle </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr ng-repeat=" (key, userwiseWorkingDatas) in userwiseWorkingData">
                                                <td>{{$index + 1}}</td>
                                                <td ng-click="showWserWiseMap(key);"> {{key}}</td>
                                                <td>{{ userwiseWorkingDatas.working}} / {{ userwiseWorkingDatas.total}}</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </section>

                        </div>

                    </div>


                </div>

            </div>
        </div>


        <!--device wise working vehical-->
        <div class="content-wrap">
            <div class="row">


                <div class="col-sm-12">

                    <div class="nest" id="tableStaticClose">
                        <div class="title-alt">

                            <h6> Vehicals  </h6>
                            <div class="titleClose">
                                <a class="gone" href="#tableStaticClose">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                            <div class="titleToggle">
                                <a class="nav-toggle-alt" href="#tableStatic">
                                    <span class="entypo-up-open"></span>
                                </a>
                            </div>

                        </div>

                        <div class="body-nest" id="tableStatic">


                            <section id="flip-scroll">
                                <div class="table-responsive" style="overflow:auto; width:100%; height:300px;">
                                    <table class="table table-bordered table-striped cf">
                                        <thead class="cf">
                                            <tr>
                                                <th>#</th>
                                                <th> Device Sr. No.</th>
                                                <th> Vehical No</th>
                                                <th>Last Update</th>
                                                <th>Status</th>
                                                <th>Speed</th>
                                                <th>Activation St.</th>
                                                <th>Ac St.</th>
                                                <th> Power St.</th>
                                                <th> Door St.</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr ng-repeat=" userDatavehicalDatas in userDatavehicalData">
                                                <td> {{$index + 1}} </td>
                                                 <td>  </td>
                                                <td>{{userDatavehicalDatas.vehicalnumber}}</td>
                                                <td> {{userDatavehicalDatas.date}}</td>
                                                <td></td>
                                                <td></td>
                                                <td> </td>
                                                <td></td>
                                                <td> </td>
                                                <td></td>

                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </section>

                        </div>

                    </div>


                </div>

            </div>
        </div>

        <!--device wise working vehical-->
        <div class="content-wrap">
            <div class="row">
                <div class="col-sm-12">
                    <div class="nest" id="tableStaticClose">
                        <div class="title-alt">

                            <h6> Device Wise Working Vehicle(s) </h6>
                            <div class="titleClose">
                                <a class="gone" href="#tableStaticClose">
                                    <span class="entypo-cancel"></span>
                                </a>
                            </div>
                            <div class="titleToggle">
                                <a class="nav-toggle-alt" href="#tableStatic">
                                    <span class="entypo-up-open"></span>
                                </a>
                            </div>

                        </div>

                        <div class="body-nest" id="tableStatic">


                            <section id="flip-scroll">
                                <div class="table-responsive" style="overflow:auto; width:100%; height:300px;">
                                    <table class="table table-bordered table-striped cf">
                                        <thead class="cf">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>User Id</th>
                                                <th> Working Vehicle/All Vehicle </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Abhishake</td>
                                                <td>20/21</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </section>

                        </div>

                    </div>


                </div>

            </div>
        </div>



    </div>







    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkSEXMA8K4fhZLuF1fIwBIdFoHUjYVmsk" type="text/javascript"></script>



    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


    <script>
                                                    var app = angular.module('myApp', []);
                                                    app.controller('controller_restuTakeOrder', function ($scope, $http, $filter, $timeout) {

                                                        //console.log('Active');
                                                        $scope.gpsData = [];

                                                        $scope.asd = "hhfgg";

                                                        // function for get all user list 
                                                        $scope.getuserList = function () {
                                                            $scope.userData = [];
                                                            $http({
                                                                method: 'POST',
                                                                url: '<?php echo base_url(); ?>index.php/Dashboard/getuserList',
                                                                data: '', //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                        $scope.userData = data;
                                                                    });
                                                            //                                    
                                                        }
                                                        $scope.getuserList();

                                                        // for getting gps data 
                                                        $scope.getGpsData = function (x) {

                                                            $http({
                                                                method: 'POST',
                                                                url: '<?php echo base_url(); ?>index.php/Dashboard/getGpsData',
                                                                data: $scope.userId, //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                        //console.log(data);  
                                                                        $scope.showMap(data);
                                                                        $scope.everyfiveSec();

                                                                    });

                                                        }


                                                        // function for google map 
                                                        $scope.showMap = function (x) {

                                                            $scope.gpsData = [];
                                                            // console.log(x.length); return false; 
                                                            if (x.length > 0) {
                                                                angular.forEach(x, function (value, key) {
                                                                    $scope.gpsData.push({
                                                                        lat: value.latitude,
                                                                        lng: value.longitude,
                                                                        description: value.imino,
                                                                    });
                                                                });
                                                                var markers = $scope.gpsData;
                                                            } else {
                                                                $('#dvMap').html('');
                                                                markers = '';
                                                            }

                                                            // console.log(markers);
                                                            /*window.onload = function () {*/
                                                            var mapOptions = {
                                                                center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
                                                                zoom: 16,
                                                                mapTypeId: google.maps.MapTypeId.ROADMAP
                                                            };
                                                            var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                                                            var infoWindow = new google.maps.InfoWindow();
                                                            var lat_lng = new Array();
                                                            var latlngbounds = new google.maps.LatLngBounds();
                                                            for (i = 0; i < markers.length; i++) {
                                                                var data = markers[i]
                                                                var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                                lat_lng.push(myLatlng);
                                                                var marker = new google.maps.Marker({
                                                                    position: myLatlng,
                                                                    map: map,
                                                                    title: data.title
                                                                });
                                                                latlngbounds.extend(marker.position);
                                                                (function (marker, data) {
                                                                    google.maps.event.addListener(marker, "click", function (e) {
                                                                        infoWindow.setContent(data.description);
                                                                        infoWindow.open(map, marker);
                                                                    });
                                                                })(marker, data);
                                                            }
                                                            map.setCenter(latlngbounds.getCenter());
                                                            map.fitBounds(latlngbounds);
                                                            //}


                                                            $scope.gpsData = [];

                                                            //console.log($scope.gpsData);

                                                        }



                                                        //for playing audio every five second
                                                        $scope.everyfiveSec = function () {
                                                            //if($scope.autoReferesh==true){
                                                            setTimeout(function () {
                                                                $scope.againplay();
                                                                $scope.getGpsData();
                                                                $scope.gpsData = [];
                                                            }, 25000);
                                                            //}
                                                        }

                                                        $scope.againplay = function ()
                                                        {
                                                            $scope.getGpsData();
                                                            $scope.gpsData = [];
                                                            $scope.everyfiveSec();
                                                            // console.log('aa');
                                                        }
                                                        // $scope.everyfiveSec();


                                                        // function for get device details 
                                                        $scope.getGpsDataAllUser = function () {
                                                            $scope.alluserdata = [];

//                                                                $scope.gpsData[0] = {lat: '28.866667',
//                                                                    lng: '85.966667',
//                                                                    description: '7398191690',
//                                                                };
//                                                                
//                                                                 $scope.gpsData[1] = {lat: '29.866667',
//                                                                    lng: '83.966667',
//                                                                    description: '7398191690',
//                                                                };



                                                            $http({
                                                                method: 'POST',
                                                                url: '<?php echo base_url(); ?>index.php/Dashboard/getFinalGpasData',
                                                                data: $scope.vehicalNo, //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                        console.log(data);

                                                                        // initMap(); return false;

                                                                        //return false;
                                                                        if (data) {
                                                                            // console.log(data.length); return false;


                                                                            //$scope.userData = data;
                                                                            angular.forEach(data, function (value, key) {
                                                                                $scope.gpsData.push({
                                                                                    lat: value.latitude,
                                                                                    lng: value.longitude,
                                                                                    description: value.imino,
                                                                                });
                                                                            });

//                                                                         if(data.length=='1'){
//                                                                               initMap( $scope.gpsData);
//                                                                             // console.log(data);
//                                                                          }else{
                                                                            // console.log($scope.gpsData);

                                                                            var markers = $scope.gpsData;

                                                                            var mapOptions = {
                                                                                center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
                                                                                zoom: 16,
                                                                                mapTypeId: google.maps.MapTypeId.ROADMAP
                                                                            };
                                                                            var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                                                                            var infoWindow = new google.maps.InfoWindow();

                                                                            var lat_lng = new Array();
                                                                            var latlngbounds = new google.maps.LatLngBounds();

                                                                            for (i = 0; i < markers.length; i++) {
                                                                                var data = markers[i]
                                                                                var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                                                lat_lng.push(myLatlng);
                                                                                var marker = new google.maps.Marker({
                                                                                    position: myLatlng,
                                                                                    map: map,
                                                                                    title: data.title
                                                                                });
                                                                                latlngbounds.extend(marker.position);
                                                                                (function (marker, data) {
                                                                                    google.maps.event.addListener(marker, "click", function (e) {
                                                                                        infoWindow.setContent(data.description);
                                                                                        infoWindow.open(map, marker);
                                                                                    });
                                                                                })(marker, data);
                                                                            }
                                                                            map.setCenter(latlngbounds.getCenter());
                                                                            map.fitBounds(latlngbounds);
                                                                        }
                                                                        //}
                                                                        //

                                                                    });
                                                        }
                                                        $scope.getGpsDataAllUser();

                                                        $scope.everyfiveSec = function () {
                                                            setTimeout(function () {
                                                                $scope.againplay();
                                                                $scope.getGpsDataAllUser();
                                                                //$scope.gpsData = [];
                                                            }, 30000);
                                                        }

                                                        $scope.againplay = function ()
                                                        {
                                                            $scope.getGpsDataAllUser();
                                                            $scope.gpsData = [];
                                                            $scope.everyfiveSec();
                                                        }
                                                        $scope.everyfiveSec();





                                                        function initMap(data) {
                                                            //console.log(data); return false;
                                                            // console.log(data[0].lat);
                                                            // console.log(data[0].lng); return false;
                                                            var markers = data;
                                                            var map = new google.maps.Map(document.getElementById('dvMap'), {
                                                                center: {lat: Number(data[0].lat), lng: Number(data[0].lng)},
                                                                zoom: 16
                                                            });

                                                            //var infowindow = new google.maps.InfoWindow();

                                                            var map = new google.maps.Map(document.getElementById("dvMap"), map);
                                                            var infoWindow = new google.maps.InfoWindow();

                                                            var lat_lng = new Array();
                                                            var latlngbounds = new google.maps.LatLngBounds();

                                                            var data = markers[0]
                                                            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                            lat_lng.push(myLatlng);
                                                            var marker = new google.maps.Marker({
                                                                position: myLatlng,
                                                                map: map,
                                                                title: data.title
                                                            });
                                                            latlngbounds.extend(marker.position);
                                                            (function (marker, data) {
                                                                google.maps.event.addListener(marker, "click", function (e) {
                                                                    infoWindow.setContent(data.description);
                                                                    infoWindow.open(map, marker);
                                                                });
                                                            })(marker, data);


                                                            //var service = new google.maps.places.PlacesService(map);
//        service.getDetails({
//          placeId: 'ChIJN1t_tDeuEmsRUsoyG83frY4'
//        }, function(place, status) {
//          if (status === google.maps.places.PlacesServiceStatus.OK) {
//            var marker = new google.maps.Marker({
//              map: map,
//              position: place.geometry.location
//            });
//            google.maps.event.addListener(marker, 'click', function() {
//              infowindow.setContent('<div><strong>' + place.name + '</strong><br>' +
//                'Place ID: ' + place.place_id + '<br>' +
//                place.formatted_address + '</div>');
//              infowindow.open(map, this);
//            });
//          }
//        });
                                                        }



// for get user userwise working vehical
                                                        $scope.getUserWiseWokingVehical = function () {
                                                            $http({
                                                                method: 'POST',
                                                                url: '<?php echo base_url(); ?>index.php/Dashboard/getUserWiseWokingVehical',
                                                                data: '', //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                        // $scope.userData = data;
                                                                        console.log(data);
                                                                        $scope.userwiseWorkingData = data;
                                                                    });
                                                        }
                                                        $scope.getUserWiseWokingVehical();


                                                        $scope.everyfiveSecuserWise = function () {
                                                            setTimeout(function () {
                                                                $scope.againplayUserWise();
                                                                $scope.getUserWiseWokingVehical();
                                                                //$scope.gpsData = [];
                                                            }, 30000);
                                                        }

                                                        $scope.againplayUserWise = function ()
                                                        {
                                                            $scope.getUserWiseWokingVehical();
                                                            $scope.userwiseWorkingData = [];
                                                            $scope.everyfiveSecuserWise();
                                                        }
                                                        $scope.everyfiveSecuserWise();









                                                        // for show user wise map 
                                                        $scope.showWserWiseMap = function (x) {
                                                            //alert(x);
                                                            $http({
                                                                method: 'POST',
                                                                url: '<?php echo base_url(); ?>index.php/Dashboard/getVehicaldDetailsUserWise',
                                                                data: x, //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                        $scope.userDatavehicalData = data;
                                                                        console.log(data);
                                                                    });

                                                        }




                                                    });
    </script>













<!--    <script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>
<script type="text/javascript">
    $(function () {
        $('.footable-res').footable();
    });

    /* Custom filtering function which will search data in column four between two values */
//    $.fn.dataTable.ext.search.push(
//            function (settings, data, dataIndex) {
//                var min = $('#min').val();
//                var max = $('#max').val();
//                var age = data[3]; // use data for the age column
//                if ((min) == age) {
//                    return true;
//                }
//                return false;
//            }
//    );
    // end custom add table 
    $(document).ready(function () {
        // for showinng radio button value
        $("#myonoffswitch2").click(function (e) {
            var mobileApp = $('input[name=onoffswitch2]:checked').val();
            if (mobileApp == '1') {
                $("#applogin").modal('show');
            }
        });


        $("#apploginBtn").click(function (e) {
            $("#applogin").modal('hide');
        });

        // for showinng radio button value
        $("#myonoffswitch1").click(function (e) {
            var mobileApp = $('input[name=onoffswitch1]:checked').val();
            if (mobileApp == '1') {
                $("#portalLogin").modal('show');
            } else {
                $("#portalexpiryDta").val('');
            }
        });


        $("#portalloginBtn").click(function (e) {
            $("#portalLogin").modal('hide');
            var validexpiry = $('#validtillexpiry').val();
            $("#portalexpiryDta").val(validexpiry);
        });






        $('#footable-res').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
        
         $('#footable-res2').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
        // end dynamic data table here
    });






</script>

<script type="text/javascript">
    $(function () {
        $('#footable-res2').footable().bind('footable_filtering', function (e) {
            var selected = $('.filter-status').find(':selected').text();
            if (selected && selected.length > 0) {
                e.filter += (e.filter && e.filter.length > 0) ? ' ' + selected : selected;
                e.clear = !e.filter;
            }
        });
        
         $('#footable-res').footable().bind('footable_filtering', function (e) {
            var selected = $('.filter-status').find(':selected').text();
            if (selected && selected.length > 0) {
                e.filter += (e.filter && e.filter.length > 0) ? ' ' + selected : selected;
                e.clear = !e.filter;
            }
        });
        

//            $('.clear-filter').click(function (e) {
//                e.preventDefault();
//                $('.filter-status').val('');
//                $('table.demo').trigger('footable_clear_filter');
//            });

//            $('.filter-status').change(function (e) {
//                e.preventDefault();
//                $('table.demo').trigger('footable_filter', {
//                    filter: $('#filter').val()
//                });
//            });

//            $('.filter-api').click(function (e) {
//                e.preventDefault();
//
//                //get the footable filter object
//                var footableFilter = $('table').data('footable-filter');
//
//                alert('about to filter table by "tech"');
//                //filter by 'tech'
//                footableFilter.filter('tech');
//
//                //clear the filter
//                if (confirm('clear filter now?')) {
//                    footableFilter.clearFilter();
//                }
//            });
    });
</script>

<script>-->


