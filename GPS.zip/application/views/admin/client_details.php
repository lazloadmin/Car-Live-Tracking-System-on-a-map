
<ul></ul>
<div id="main-content" 
     <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREAD CRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="#">Admin</a>
                                </li>										
                                <li><?php echo $page_name; ?></li>
                            </ul>
                            <!-- BREAD CRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $page_title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>                                  
                                    <div class="col-md-12">
                                        <? }?>



                                        <div class="tabbable">
                                            <ul class="nav nav-tabs">
                                                <li class="active"><a href="#tab_1_1" data-toggle="tab">Person</a></li>


                                                <li><a href="#tab_1_2" data-toggle="tab"> Business </a></li>
                                                <li><a href="#tab_1_3" data-toggle="tab"> Loyalty Cards </a></li>
                                                <li><a href="#tab_1_4" data-toggle="tab"> Change Password </a></li>


                                            </ul>
                                            <div class="tab-content">
                                                <div class="tab-pane fade in active" id="tab_1_1">
                                                    <form id="userForm1" class="form-horizontal" name="peopleform" novalidate>
                                                        <div class="divide-10"></div>
                                                        <p>
                                                        <div class="form-group">
                                                            <label class="col-sm-4 control-label ">User Status</label>
                                                            <div class="col-sm-8">
                                                                <select class="form-control"  name="status" required style="width:200px;">
                                                                    <option  value="">Select People Status</option>
                                                                    <option value="Active">Active</option>
                                                                    <option value="Deactive">Deactive</option>
                                                                    <option value="New">New</option>
                                                                    <option value="Verify">Verify</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        
                                                          <div class="form-group">
                                                            <label class="col-sm-4 control-label ">User Status</label>
                                                            <div class="col-sm-8">
                                                                <select class="form-control"  name="status" required style="width:200px;">
                                                                    <option  value="">Select People Status</option>
                                                                    <option value="Active">Active</option>
                                                                    <option value="Deactive">Deactive</option>
                                                                    <option value="New">New</option>
                                                                    <option value="Verify">Verify</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                       
                                                        </p>
                                                    </form>
                                                </div>
                                            </div>





