<style>
    .reslt {
        display: block;
        font-size: 17px;
        padding: 5px;
    }
    .reslt:hover {
        color: #fff;
        cursor: pointer;
        background: red;
    }
</style>
<!--  PAPER WRAP -->
<div class="wrap-fluid" style="width: auto; margin-left: 250px;">
    <div class="container-fluid paper-wrap bevel tlbr">

        <div class="row">
            <div id="paper-top">
                <div class="col-lg-3">
                    <h2 class="tittle-content-header">
<!--                                <i class="icon-window"></i> -->
                        <ul class="breadcrumb">


                            <li>
                                <i class="fa fa-home"></i>

                                <a href="<?php echo base_url(); ?>index.php/Dashboard/Admin "><?php echo $pageName; ?> </a>
                            </li>										
                            <li><?php echo $Title; ?> </li>
                        </ul>
<!--                                <span>Add Edit User
</span>-->
                    </h2>

                </div>
            </div>
        </div>

        <div class="content-wrap">
            <div class="row">
                <div class="col-sm-12">
                    <?php if ($this->session->flashdata('flash_message')) { ?>
                        <div class="alert alert-block alert-success fade in">
                            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                            <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                        </div>
                        <? }
                        if($this->session->flashdata('permission_message')){ ?>
                        <div class="alert alert-block alert-warning fade in">
                            <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                            <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                        </div>
                        <? }?>

                        <h4>Vehicle Allocation</h4>

                    </div>
                </div>

            </div>



            <div class="content-wrap">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="nest" id="tableStaticClose">
                            <div class="title-alt">
                                <h6> Position Map </h6>
                                <div class="titleClose">
                                    <a class="gone" href="#tableStaticClose">
                                        <span class="entypo-cancel"></span>
                                    </a>
                                </div>
                                <div class="titleToggle">
                                    <a class="nav-toggle-alt" href="#tableStatic">
                                        <span class="entypo-up-open"></span>
                                    </a>
                                </div>
                            </div>

                            <div class="body-nest" id="tableStatic">


                                <div id="wizard">
                                    <h2>First Step</h2>
                                    <section style="height:100px">
                                        User Id <input type="text" name="userid" id="userid" class="form-control userid"/>
                                        <div id="result" style="background: #fff;  min-height: 250px;  max-height: 300px; overflow: auto; border: 1px solid rgba(0, 0, 0, 0.2);  box-shadow: 0 5px 10px rgba(0,0,0,.2);  margin-top: 5px;  border-radius: 5px;"> </div>

                                    </section>

                                    <h2>Second Step</h2>
                                    <section>
                                        User Id : <span id="selecteduerId" style="color:red;"></span>  <br>


                                        <table>
                                            <tr> 
                                                <td> Selected User Id : </td>
                                                <td> <select  style="width:300px;" class="form-control"> 
                                                        <option value="unknown">Unknow</option> 

                                                    </select></td>
                                                <td> &nbsp; <button class="btn-primary" style="width:80px; height:30px;">Find</button></td>
                                            </tr>


                                            <tr style="height:15px;"> 
                                                <td>  </td>
                                                <td> </td>
                                                <td>  </td>
                                            </tr>


                                            <tr> 
                                                <td>  </td>
                                                <td style="width:250px;">  </td>
                                                <td style="width:250px;"> </td>
                                            </tr>


                                            <tr style="height:15px;"> 
                                                <td>  </td>
                                                <td> </td>
                                                <td>  </td>
                                            </tr>

                                            <tr> 
                                                <td>  </td>
                                                <td> <button class="form-control" id="addVehicleButton">  &twoheadrightarrow; &twoheadrightarrow;  </button> </td>
                                                <td> <button class="form-control" id="removeVehicleButton">  &twoheadleftarrow; &twoheadleftarrow; </button> </td>
                                            </tr>


                                            <tr>

                                                <td>
                                                    <!--<a href="JavaScript:void(0);" id="btn-add">Add &raquo;</a>-->
                                                    <!--<a href="JavaScript:void(0);" id="btn-remove">&laquo; Remove</a>-->
                                                </td>

                                                <td>
                                                    <select name="vehiclelist[]" id="select-from" multiple size="10" class="form-control1 add">
                                                        <?php foreach ($devicedetails as $key => $value) { ?> 
                                                            <option value="<?php echo $value['id']; ?>"> <?php echo $value['vehicalname']; ?> </option>
                                                        <?php } ?> 
                                                    </select> 
                                                    <a href="JavaScript:void(0);" id="btn-add">Add &raquo;</a>
                                                </td>

                                                <td  >
                                                    <span id="abc">
                                                        <select name="assignvehical[]" id="select-to" multiple size="10"  class="form-control1">

                                                        </select>
                                                    </span>

                                                    <a href="JavaScript:void(0);" id="btn-remove">&laquo; Remove</a>
                                                </td>

                                            </tr>


                                        </table>







                <!--                                                    <table>
                                                                        <tr >
                                                                           
                                                                            <td>
                                                                                <select name="" id="select-from" multiple size="10" class="form-control">
                                        <?php foreach ($devicedetails as $key => $value) { ?> 
                                                                                                        <option value="<?php echo $value['id']; ?>"> <?php echo $value['vehicalname']; ?> </option>
                                        <?php } ?> 
                                                                                </select> 
                                                                            </td>
                                                                            <td>
                                                                                <a href="JavaScript:void(0);" id="btn-add">Add &raquo;</a>
                                                                                <a href="JavaScript:void(0);" id="btn-remove">&laquo; Remove</a>
                                                                            </td>
                                                                            <td>
                                                                                <select name="assignvehical[]" id="select-to" multiple size="10"  class="form-control">
                                                                                </select>
                                                                            </td>
                                                                        </tr>
                                                                    </table>-->



                                    </section>

                                    <h2>Third Step</h2>
                                    <section>
                                        User Id <input type="text" name="userid" id="userid" class="form-control"/>
                                        vehical Assign 
                                        <textarea rows="10" cols="20" class="form-control"></textarea>
                                    </section>


                                </div>

                            </div>

                        </div>


                    </div>

                </div>
            </div>


        </div>


        <!--app login modal Start -->


                        <!--<script src="<?php echo base_url(); ?>assets/js/datatable/jquery-1.12.3.js"></script>-->


        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/step/css-step/normalize.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/step/css-step/main.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/step/css-step/jquery.steps.css">
        <script src="<?php echo base_url(); ?>assets/step/lib-step/modernizr-2.6.2.min.js"></script>

            <!--<script src="<?php echo base_url(); ?>assets/step/lib-step/jquery-1.9.1.min.js"></script>-->

    <!--    <script src="<?php echo base_url(); ?>assets/step/lib-step/jquery.cookie-1.3.1.js"></script>-->

        <script>
            $(function ()
            {
                $("#wizard").steps({
                    headerTag: "h2",
                    bodyTag: "section",
                    transitionEffect: "slideLeft",
                    //stepsOrientation: "vertical"
                });
            });
            //#userid
        </script>
        <script>

            $(document).ready(function () {
                $('#result').hide(); // result hide
                $(".userid").keyup(function (e) {
                    var abc = $('.userid').val();
                    if (abc) {
                        $.ajax({
                            url: '<?php echo base_url(); ?>index.php/Dashboard/searchUser',
                            type: "POST",
                            data: {'searchtext': abc},
                            success: function (response)
                            {
                                // alert(response);
                                $('#result').show();
                                $('#result').html(response);

                                $(".reslt").click(function () { // for get and paste value 

                                    $('#result').hide();
                                    $(".userid").val(this.id);
                                    $('#selecteduerId').html(this.id);
                                    getAssignVehicalDataPartularUser(this.id); // for getting user details data
                                });

                            }
                        });
                    } else {
                        $('#result').html('');
                        $('#result').hide();
                    }

                });

                // function for getting data of agains user id
                function getAssignVehicalDataPartularUser(val) {
                    var assignData = '';
                    $.ajax({
                        url: '<?php echo base_url(); ?>index.php/Dashboard/getAssignVehicalDataPartularUser',
                        type: "POST",
                        data: {'userId': val},
                        success: function (response)
                        {
                            //console.log(response);
                            assignData = response;
                            //console.log(assignData);
                            $("#abc").html(assignData);
                        }
                    });
                }


                // for add button 
                $('#btn-add').click(function () {

                    var userId = $('#selecteduerId').html();
                    $('#select-from option:selected').each(function () {
                        addRemoveVehical('add', $(this).val(), userId);
                        $('#select-to').append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
                        $(this).remove();
                    });
                });

                $('#btn-remove').click(function () {
                    var userId = $('#selecteduerId').html();
                    $('#select-to option:selected').each(function () {
                        addRemoveVehical('remove', $(this).val(), userId);
                        $('#select-from').append("<option value='" + $(this).val() + "'>" + $(this).text() + "</option>");
                        $(this).remove();
                    });
                });
                // for vehical assign
                function addRemoveVehical(x, y, user_id) {
                    $.ajax({
                        url: '<?php echo base_url(); ?>index.php/Dashboard/addDeleteVehicalAssign',
                    type: "POST",
                    data: {'action': x,
                        'id': y,
                        'userId': user_id,
                    },
                    success: function (response)
                    {
                        console.log(response);
                        //alert(response);
                    }
                });
            }


            // for add vehicle button
            $("#addVehicleButton").click(function (e) {
                //alert("addvehicle");

                $.each($(".add option:selected"), function () {
                    // console.log($(this).val());
                    //  countries.push($(this).val());
                });

            });
            // for remove vehicvle button
            $("#removeVehicleButton").click(function (e) {
                // alert("removevehicle");
            });


            // for add vehical button
            $('#addVehicleButton').click(function (e) {
                $('#select-from option').prop('selected', true);
                $('#btn-add').click();
            });


            // for mltiple remove 
            $('#removeVehicleButton').click(function (e) {
                $('#select-to option').prop('selected', true);
                $('#btn-remove').click();
            });





        });
    </script>







