<?php
if ($par1) {
    $edit = $this->db->get_where('devicedetails', array('id' => $par1))->row_array();
    //print_r($edit);
    $formaction = 'edit';
} else {
    $formaction = 'create';
}
?>



<div id="main-content">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="<?php echo base_url(); ?>index.php/Dashboard/Admin "><?php echo $pageName; ?> </a>
                                </li>										
                                <li><?php echo $Title; ?> </li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left"><?php echo $Title; ?></h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>




                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Add  Device</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <?php
                                            echo form_open_multipart('index.php/Dashboard/addEditDeviceFinal/' . $formaction, array('id' => 'usersForm', 'class' => 'form-horizontal'));
                                            ?>
                                            <!--                                            <form  action='Dashboard/addBannerFinal/.$formaction' id="userForm" class="form-horizontal" enctype="multipart"-->


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device Installation Date</label>
                                                <div class="col-sm-8">
                                                    <input type="hidden" name="hid" id="hid" value="<?php echo $edit['id']; ?> "/>
                                                    <input type="text" class="form-control datetime1" name="instalationdate" id="instalationdate" value="<?php if($edit['instalationdate']==''){echo date('Y-m-d');}else{ echo $edit['instalationdate'];} ?> " readonly data-validation="required"    />
                                                </div>
                                            </div>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device Id * </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="deviceid" id="deviceid" placeholder="Enter Device Id" value="<?php echo $edit['deviceid']; ?> " data-validation="required"    data-validation-error-msg="Plz enter device id" />
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device Type * </label>
                                                <div class="col-sm-8">
                                                    <select class="form-control" name="devicetype" id="devicetype" data-validation="required"    data-validation-error-msg="Plz select device type">
                                                        <option value=""> Choose Device</option>
                                                        <?php foreach($devicetype as $value){ ?> 
                                                        <option <?php if($value['id'] == $edit['devicetype'] ){ echo "selected";} ?>  value="<?php echo $value['id']?> "> <?php echo $value['displayname']; ?> </option>
                                                        <?php } ?> 
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device IMEI * </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="deviceimi" id="deviceimi" placeholder="Enter Device IMI" value="<?php echo $edit['deviceimi']; ?> " data-validation="required"    data-validation-error-msg="Plz enter device imi " />
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"> Sim Phone No * </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="simphoneno" id="simphoneno" placeholder="Enter Sim Phone Number" value="<?php echo $edit['simphoneno']; ?> " data-validation="required"    data-validation-error-msg="Plz enter Phone number" />
                                                </div>
                                            </div>

<!--                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"> Sim IMEI  </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="simimi" id="simimi" placeholder="Enter Sim IMI" value="<?php echo $edit['simimi']; ?> "  <?php if($formaction=='edit'){ echo "readonly"; } ?> />
                                                </div>
                                            </div>-->
                                            
                                            
                                            
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" class="form-control">Sim Selection  </label>
                                                <div class="col-sm-8">
                                                    <select  class="form-control" name="simselection" id="simselection">
                                                         <!--<option value="" > Choose Sim Selection</option>-->
                                                        <option value="company" <?php if($edit['simselection']=='company' ){ echo "selected";} ?> > Company</option>
                                                        <option value="user" <?php if($edit['simselection']=='user' ){ echo "selected";} ?>> User</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label" class="form-control">Sim Operator  * </label>
                                                <div class="col-sm-8">
                                                     <select class="form-control" name="simoperator" id="simoperator" data-validation="required"    data-validation-error-msg="Plz select sim operator">
                                                         <option value=""> Choose Sim Operator</option>
                                                         <?php foreach($simoperator as $value){ ?> 
                                                         <option <?php if($value['id'] == $edit['simoperator'] ){ echo "selected";} ?> value="<?php echo $value['id']; ?> "><?php echo $value['name']; ?> </option>
                                                         <?php } ?> 
                                                    </select>
                                                </div>
                                                
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"> Vehicle Type * </label>
                                                <div class="col-sm-8">
                                                     <select class="form-control" name="vehicaltype" id="vehicaltype" data-validation="required"    data-validation-error-msg="Plz select vehical type">
                                                         <option value=""> Choose Vehical Type</option>
                                                         <?php foreach($vehicaltype as $value){ ?> 
                                                         <option <?php if($value['id'] == $edit['vehicaltype'] ){ echo "selected";} ?> value="<?php echo $value['id']; ?> "><?php echo $value['vehicalname']; ?> </option>
                                                         <?php } ?> 
                                                    </select>
                                                    
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Vehical Number * </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="vehicalnumber" id="vehicalnumber" placeholder="Enter vehical number" value="<?php echo $edit['vehicalnumber']; ?> " data-validation="required"    data-validation-error-msg="Plz enter vehical number" />
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"> Vehical Details </label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="vehicaldetails" id="vehicaldetails" placeholder="Enter vehical details" value="<?php echo $edit['vehicaldetails']; ?> " />
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device Sold By </label>
                                                <div class="col-sm-8">
                                                  
                                                    <select name="devicesoldby" id="devicesoldby" class="form-control">
                                                          <option > Choose Device Soled by</option>
                                                         <?php   foreach($Sales as $value){ 
                                                             
                                                             if($edit['devicesoldby']==$value['id']){ $ab = 'selected';} else{$ab='';}
                                                         ?> 
                                                          
                                                         <option value="<?php echo $value['id']; ?> " <?php echo $ab;  ?> > <?php echo $value['name'];  ?> </option>
                                                         <?php } ?> 
                                                    </select>
                                                
                                                
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Device Installed By  </label>
                                                <div class="col-sm-8">
                                                    
                                                     <select class="form-control" name="deviceinstalledby" id="deviceinstalledby">
                                                         <option value=""> Choose Device Installed by</option>
                                                         <?php foreach($Installer as $value){ ?> 
                                                         <option  <?php if($value['id'] == $edit['deviceinstalledby'] ){ echo "selected";} ?> value="<?php echo $value['id']; ?> "><?php echo $value['name']; ?> </option>
                                                         <?php } ?> 
                                                    </select>
                                                    
                                                </div>
                                            </div>

                                          

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"></label>
                                                <div class="col-sm-5">
                                                    <div class="input-group">
                                                        <input type="submit" name="sub" value="SAVE" class="btn-primary" style="width: 100px; height: 40px;" />

                                                    </div>
                                                </div>
                                            </div>



                                            <?php
                                            echo form_close();
                                            ?>



                                        </div>
                                    </div>

                                    <div class="box border primary">
                                        <div class="box-title">
                                            <h4><i class="fa fa-table"></i>Device List</h4>
                                            <div class="tools hidden-xs">
                                                <a href="#box-config" data-toggle="modal" class="config">
                                                    <i class="fa fa-cog"></i>
                                                </a>
                                                <a href="javascript:;" class="reload">
                                                    <i class="fa fa-refresh"></i>
                                                </a>
                                                <a href="javascript:;" class="collapse">
                                                    <i class="fa fa-chevron-up"></i>
                                                </a>
                                                <a href="javascript:;" class="remove">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="box-body">
                                            <table id="datatable1" cellpadding="0" cellspacing="0" border="0" class="datatable table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Device id</th>
                                                        <th>Device Type</th>
                                                        <th>Sim Phone Number</th>
                                                        <th>Sim IMI No</th>
                                                        <th>Sim Operator</th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    if ($devicedetails) {
                                                        $i = 1;
                                                        foreach ($devicedetails as $key => $value) {
                                                            ?> 
                                                            <tr>
                                                                <td> <?php echo $i; ?>  </td>
                                                                <td> <?php echo $value['deviceid']; ?> </td>
                                                                <td> <?php echo $value['devicetype']; ?> </td>
                                                                <td> <?php echo $value['simphoneno'];  ?>  </td>
                                                                <td> <?php echo $value['simimi']; ?> </td>
                                                                 <td> <?php echo $value['simoperator'];  ?>  </td>
                                                                <td> <a href="<?php echo base_url() . 'index.php/Dashboard/addEditDevice/' . $value['id']; ?>"> <i class="fa fa-edit"></i>  </a>&nbsp;  <i id="<?php echo $value['id']; ?> " class="fa fa-trash-o"></i>  </td>
                                                            </tr>
                                                            <?php $i++;
                                                        }
                                                    } ?> 

                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                       <th>Sr. No.</th>
                                                        <th>Device id</th>
                                                        <th>Device Type</th>
                                                        <th>Sim Phone Number</th>
                                                        <th>Sim IMI No</th>
                                                        <th>Sim Operator</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                </div>
            </div>
        </div>
    </div>           
    </section>

    <script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script> 
    <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script>
        $(document).ready(function () {
            // for delete item from list
            $(".fa-trash-o").click(function (e) {
                var conf = confirm("Are you sure want to delete!");
                if (conf == true) {
                    var id = this.id;
                    $.ajax({
                        url: '<?php echo base_url(); ?>Dashboard/addEditDeviceFinal/delete',
                    type: "POST",
                    data: {'id': id,
                    },
                    success: function (response)
                    {
                        location.reload();
                    }
                });
            }

        });



    


    });
</script>

<script>
    $(document).ready(function () {
        // for calendar
        $.datetimepicker.setLocale('en');
        $('#instalationdate').datetimepicker({
            lang: 'ch',
            timepicker: false,
            format: 'Y-m-d',
        });
    });

</script>



