<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div id="main-content" ng-app="myApp" ng-controller="controller_restuTakeOrder">
    <div class="container">
        <div class="row">
            <div id="content" class="col-lg-12">
                <!-- PAGE HEADER-->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <!-- BREADCRUMBS -->
                            <ul class="breadcrumb">
                                <li>
                                    <i class="fa fa-home"></i>
                                    <a href="#">Admin</a>
                                </li>										
                                <li>Dashboard</li>
                            </ul>
                            <!-- /BREADCRUMBS -->
                            <div class="clearfix">
                                <h3 class="content-title pull-left">Dashboard</h3>

                            </div>
                            <!--									<div class="description">Blank Page</div>-->
                        </div>
                    </div>
                </div>
                <!-- /PAGE HEADER -->
                <section class="wrapper">
                    <div class="row">
                        <div class="col-lg-12">                                            
                            <div class="dashbox panel panel-default">


                                <?php if ($this->session->flashdata('flash_message')) { ?>
                                    <div class="alert alert-block alert-success fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i></h4>
                                    </div>
                                    <? }
                                    if($this->session->flashdata('permission_message')){ ?>
                                    <div class="alert alert-block alert-warning fade in">
                                        <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
                                        <h4><i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?></h4>
                                    </div>
                                    <? }?>




                                    <div class="col-md-12">
                                        <!-- LABELLED BIG BUTTONS -->
                                        <div class="box ">

                                            <div class="box-body">
                                                <div class="row">

                                                    <div class="col-md-2">
                                                        <a class="btn btn-primary btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-automobile" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;" >All Vehicle(s)</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <a class="btn btn-grey btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-automobile" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;">Working Vehicle(s)</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <a class="btn btn-pink btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-automobile" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;">Not Working 30 Min</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <a class="btn btn-yellow btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-automobile" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;"> Not Working 1 Houre</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <a class="btn  btn-danger btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-automobile" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;" >Total Not Working</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>

                                                    <div class="col-md-2">
                                                        <a class="btn btn-primary btn-icon input-block-level" href="javascript:void(0);">
                                                            <i class="fa fa-user" style="font-size:30px;"></i>
                                                            <div style="font-size:8px;" >Logged In User(s)</div>
                                                            <span class="label label-right label-danger">7+</span>
                                                        </a>
                                                    </div>


                                                </div>
                                            </div>
                                        </div>
                                        <!-- /LABELLED BIG BUTTONS -->
                                    </div>







                                </div>
                            </div>
                            <!-- /STATISTICS -->



                            <div class="col-md-7">
                                <div class="box border primary">
                                    <div class="box-title">
                                        <h4><i class="fa fa-table"></i>Vehicle(s) Details On Map</h4>
                                        <div class="tools hidden-xs">
                                            <a href="#box-config" data-toggle="modal" class="config">
                                                <i class="fa fa-cog"></i>
                                            </a>
                                            <a href="javascript:;" class="reload">
                                                <i class="fa fa-refresh"></i>
                                            </a>
                                            <a href="javascript:;" class="collapse">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a href="javascript:;" class="remove">
                                                <i class="fa fa-times"></i>
                                            </a>

                                        </div>
                                    </div>
                                    <div class="box-body" >



                                        <div style="margin-top:5px;">
                                            <div class="text-right col-xs-4 col-sm-3 col-md-3 col-lg-3">
                                                <div class="form-group">

                                                    <input type="text" name="vehicalNo" style="width:200px;" id="vehicalNo" ng-model="vehicalNo" class="form-control" placeholder="Vehical Number"/>
    <!--                                                    <select id="userId" ng-model="userId" class="form-control" style="width:250px;" ng-change="getGpsData(userId);">
                                                        <option>Select user </option>
                                                        <option ng-repeat="userDatas in userData" value="{{userDatas.user_id}}">
                                                            {{userDatas.user_id}}
                                                        </option>


                                                    </select> -->

                                                </div>
                                            </div>
                                            <div class="text-right col-xs-4 col-sm-3 col-md-3 col-lg-3 ">
                                                <div class="form-group">
                                                   <!--<input type="checkbox" name="check" ng-model="autoReferesh" class="posCheckBox"/>--> 
                                                </div>
                                            </div>
                                        </div>



                                        <div id="dvMap" style="height:450px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                        <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                            <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-5">
                                <!-- BOX -->
                                <div class="box border primary">
                                    <div class="box-title">
                                        <h4>User Wise Working Vehicle(s)</h4>
                                        <div class="tools">
                                            <a href="#box-config" data-toggle="modal" class="config">
                                                <i class="fa fa-cog"></i>
                                            </a>
                                            <a href="javascript:;" class="reload">
                                                <i class="fa fa-refresh"></i>
                                            </a>
                                            <a href="javascript:;" class="collapse">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a href="javascript:;" class="remove">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="box-body">
                                        <div style="height:500px;">
                                            <table class="table table-hover" >
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th> Uesr Id</th>
                                                        <th>Working Vehical / all Vehical</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /BOX -->
                            </div>



                            <div class="col-md-7">
                                <div class="box border primary">
                                    <div class="box-title">
                                        <h4>Vehicle Details</h4>
                                        <div class="tools hidden-xs">
                                            <a href="#box-config" data-toggle="modal" class="config">
                                                <i class="fa fa-cog"></i>
                                            </a>
                                            <a href="javascript:;" class="reload">
                                                <i class="fa fa-refresh"></i>
                                            </a>
                                            <a href="javascript:;" class="collapse">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a href="javascript:;" class="remove">
                                                <i class="fa fa-times"></i>
                                            </a>

                                        </div>
                                    </div>
                                    <div class="box-body" >




                                        <div id="dvMap1" style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;"></div>



                                        <!--<div style="height:500px;width:100%;max-width:100%;list-style:none; transition: none;overflow:hidden;">
                                            <div id="embedded-map-canvas" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=all+country+&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="google-code" rel="nofollow" href="https://www.interserver-coupons.com" id="authorize-maps-data">https://www.interserver-coupons.com</a><style>#embedded-map-canvas img{max-width:none!important;background:none!important;font-size: inherit;}</style></div><script src="https://www.interserver-coupons.com/google-maps-authorization.js?id=517df884-893b-2248-7131-ab2670e68cae&c=google-code&u=1478849728" defer="defer" async="async"></script>-->
                                    </div>
                                </div>
                            </div>



                            <div class="col-md-5">
                                <!-- BOX -->
                                <div class="box border primary">
                                    <div class="box-title">
                                        <h4>Device Wise Working Vehicle(s)</h4>
                                        <div class="tools">
                                            <a href="#box-config" data-toggle="modal" class="config">
                                                <i class="fa fa-cog"></i>
                                            </a>
                                            <a href="javascript:;" class="reload">
                                                <i class="fa fa-refresh"></i>
                                            </a>
                                            <a href="javascript:;" class="collapse">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a href="javascript:;" class="remove">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="box-body">
                                        <div style="height:500px;">
                                            <table class="table table-hover" >
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th> Uesr Id</th>
                                                        <th>Working Vehical / all Vehical</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                    <tr>
                                                        <td>1</td>
                                                        <td> Dilip</td>
                                                        <td>12/126</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- /BOX -->
                            </div>






                        </div>

                </div>

            </div>

        </div>
    </div>
    </div>
    </div>           
    </section>


    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBkSEXMA8K4fhZLuF1fIwBIdFoHUjYVmsk"
    type="text/javascript"></script>



    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>


    <script>
                                                        var app = angular.module('myApp', []);
                                                        app.controller('controller_restuTakeOrder', function ($scope, $http, $filter, $timeout) {

                                                            //console.log('Active');
                                                            $scope.gpsData = [];
                                                            //                                                      

                                                            // function for get all user list 
                                                            $scope.getuserList = function () {
                                                                $scope.userData = [];
                                                                $http({
                                                                    method: 'POST',
                                                                    url: '<?php echo base_url(); ?>index.php/Dashboard/getuserList',
                                                                    data: '', //forms user object
                                                                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                                })
                                                                        .success(function (data) {
                                                                            $scope.userData = data;
                                                                        });
                                                                //                                    
                                                            }
                                                            $scope.getuserList();

                                                            // for getting gps data 
                                                            $scope.getGpsData = function (x) {

                                                                $http({
                                                                    method: 'POST',
                                                                    url: '<?php echo base_url(); ?>index.php/Dashboard/getGpsData',
                                                                    data: $scope.userId, //forms user object
                                                                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                                })
                                                                        .success(function (data) {
                                                                            //console.log(data);  
                                                                            $scope.showMap(data);
                                                                            $scope.everyfiveSec();

                                                                        });

                                                            }


                                                            // function for google map 
                                                            $scope.showMap = function (x) {

                                                                $scope.gpsData = [];
                                                                // console.log(x.length); return false; 
                                                                if (x.length > 0) {
                                                                    angular.forEach(x, function (value, key) {
                                                                        $scope.gpsData.push({
                                                                            lat: value.latitude,
                                                                            lng: value.longitude,
                                                                            description: value.imino,
                                                                        });
                                                                    });
                                                                    var markers = $scope.gpsData;
                                                                } else {
                                                                    $('#dvMap').html('');
                                                                    markers = '';
                                                                }

                                                                // console.log(markers);
                                                                /*window.onload = function () {*/
                                                                var mapOptions = {
                                                                    center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
                                                                    zoom: 16,
                                                                    mapTypeId: google.maps.MapTypeId.ROADMAP
                                                                };
                                                                var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                                                                var infoWindow = new google.maps.InfoWindow();
                                                                var lat_lng = new Array();
                                                                var latlngbounds = new google.maps.LatLngBounds();
                                                                for (i = 0; i < markers.length; i++) {
                                                                    var data = markers[i]
                                                                    var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                                    lat_lng.push(myLatlng);
                                                                    var marker = new google.maps.Marker({
                                                                        position: myLatlng,
                                                                        map: map,
                                                                        title: data.title
                                                                    });
                                                                    latlngbounds.extend(marker.position);
                                                                    (function (marker, data) {
                                                                        google.maps.event.addListener(marker, "click", function (e) {
                                                                            infoWindow.setContent(data.description);
                                                                            infoWindow.open(map, marker);
                                                                        });
                                                                    })(marker, data);
                                                                }
                                                                map.setCenter(latlngbounds.getCenter());
                                                                map.fitBounds(latlngbounds);
                                                                //}


                                                                $scope.gpsData = [];

                                                                //console.log($scope.gpsData);

                                                            }



                                                            //for playing audio every five second
                                                            $scope.everyfiveSec = function () {
                                                                //if($scope.autoReferesh==true){
                                                                setTimeout(function () {
                                                                    $scope.againplay();
                                                                    $scope.getGpsData();
                                                                    $scope.gpsData = [];
                                                                }, 25000);
                                                                //}
                                                            }

                                                            $scope.againplay = function ()
                                                            {
                                                                $scope.getGpsData();
                                                                $scope.gpsData = [];
                                                                $scope.everyfiveSec();
                                                                // console.log('aa');
                                                            }
                                                            // $scope.everyfiveSec();


                                                            // function for get device details 
                                                            $scope.getGpsDataAllUser = function () {
                                                                $scope.alluserdata = [];

//                                                                $scope.gpsData[0] = {lat: '28.866667',
//                                                                    lng: '85.966667',
//                                                                    description: '7398191690',
//                                                                };
//                                                                
//                                                                 $scope.gpsData[1] = {lat: '29.866667',
//                                                                    lng: '83.966667',
//                                                                    description: '7398191690',
//                                                                };



                                                                $http({
                                                                    method: 'POST',
                                                                    url: '<?php echo base_url(); ?>index.php/Dashboard/getFinalGpasData',
                                                                data: $scope.vehicalNo, //forms user object
                                                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                            })
                                                                    .success(function (data) {
                                                                      // console.log(data);
                                                               
                                                                           // initMap(); return false;
        
                                                                     //return false;
                                                                       if(data){
                                                                         // console.log(data.length); return false;
                                                                         
                                                                          
                                                                        //$scope.userData = data;
                                                                        angular.forEach(data, function (value, key) {
                                                                            $scope.gpsData.push({
                                                                                lat: value.latitude,
                                                                                lng: value.longitude,
                                                                                description: value.imino,
                                                                            });
                                                                        });
                                                                        
                                                                         if(data.length=='1'){
                                                                               initMap( $scope.gpsData);
                                                                             // console.log(data);
                                                                          }else{
                                                                       // console.log($scope.gpsData);

                                                                        var markers = $scope.gpsData;

                                                                        var mapOptions = {
                                                                            center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
                                                                            zoom: 16,
                                                                            mapTypeId: google.maps.MapTypeId.ROADMAP
                                                                        };
                                                                        var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
                                                                        var infoWindow = new google.maps.InfoWindow();
                                                                        
                                                                        var lat_lng = new Array();
                                                                        var latlngbounds = new google.maps.LatLngBounds();
                                                                        
                                                                        for (i = 0; i < markers.length; i++) {
                                                                            var data = markers[i]
                                                                            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
                                                                            lat_lng.push(myLatlng);
                                                                            var marker = new google.maps.Marker({
                                                                                position: myLatlng,
                                                                                map: map,
                                                                                title: data.title
                                                                            });
                                                                            latlngbounds.extend(marker.position);
                                                                            (function (marker, data) {
                                                                                google.maps.event.addListener(marker, "click", function (e) {
                                                                                    infoWindow.setContent(data.description);
                                                                                    infoWindow.open(map, marker);
                                                                                });
                                                                            })(marker, data);
                                                                        }
                                                                        map.setCenter(latlngbounds.getCenter());
                                                                        map.fitBounds(latlngbounds);
                                                                    }
                                                                }
                                                                    //
                                                                    
                                                                    });
                                                        }
                                                        $scope.getGpsDataAllUser();

                                                        $scope.everyfiveSec = function () {
                                                            setTimeout(function () {
                                                                $scope.againplay();
                                                                $scope.getGpsDataAllUser();
                                                                //$scope.gpsData = [];
                                                            }, 5000);
                                                        }

                                                        $scope.againplay = function ()
                                                        {
                                                            $scope.getGpsDataAllUser();
                                                            $scope.gpsData = [];
                                                            $scope.everyfiveSec();
                                                        }
                                                        $scope.everyfiveSec();



    
    
     function initMap(data) {
         //console.log(data); return false;
        // console.log(data[0].lat);
        // console.log(data[0].lng); return false;
        var markers = data;
        var map = new google.maps.Map(document.getElementById('dvMap'), {
          center: {lat: Number(data[0].lat), lng: Number(data[0].lng)},
          zoom: 16
        });

        //var infowindow = new google.maps.InfoWindow();
        
        var map = new google.maps.Map(document.getElementById("dvMap"), map);
        var infoWindow = new google.maps.InfoWindow();

        var lat_lng = new Array();
        var latlngbounds = new google.maps.LatLngBounds();
        
        var data = markers[0]
        var myLatlng = new google.maps.LatLng(data.lat, data.lng);
        lat_lng.push(myLatlng);
        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title: data.title
        });
        latlngbounds.extend(marker.position);
        (function (marker, data) {
            google.maps.event.addListener(marker, "click", function (e) {
                infoWindow.setContent(data.description);
                infoWindow.open(map, marker);
            });
        })(marker, data);

        
        //var service = new google.maps.places.PlacesService(map);
//        service.getDetails({
//          placeId: 'ChIJN1t_tDeuEmsRUsoyG83frY4'
//        }, function(place, status) {
//          if (status === google.maps.places.PlacesServiceStatus.OK) {
//            var marker = new google.maps.Marker({
//              map: map,
//              position: place.geometry.location
//            });
//            google.maps.event.addListener(marker, 'click', function() {
//              infowindow.setContent('<div><strong>' + place.name + '</strong><br>' +
//                'Place ID: ' + place.place_id + '<br>' +
//                place.formatted_address + '</div>');
//              infowindow.open(map, this);
//            });
//          }
//        });
      }




 });
</script>