 <footer>
    <div class="container">
        <div class="row">
        <div class="col-md-5">
            <h1 class="footer-logo"> <img src="<?php echo base_url(); ?>forentend/images/logoh.png" alt="Footer Logo Blue"> </h1>
          </div>
        <div class="col-md-5">
            <p>© World Track 2017  - Designed &amp; Developed by <a href="#">Live Software Solution</a></p>
          </div>
        <div class="col-md-2">
            <div class="social">
            <ul>
                <li><a href="#" class="facebook"> <i class="fa fa-facebook" aria-hidden="true"></i> </a></li>
                <li><a href="#" class="google"> <i class="fa fa-google-plus" aria-hidden="true"></i> </a></li>
                <li><a href="#" class="twitter"> <i class="fa fa-twitter" aria-hidden="true"></i> </a></li>
                <li><a href="#" class="pinterest"> <i class="fa fa-pinterest-p" aria-hidden="true"></i> </a></li>
              </ul>
          </div>
          </div>
      </div>
      </div>
  </footer>
  </div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script type="text/javascript" src="<?php echo base_url(); ?>forentend/js/jquery.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/toucheffects-min.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/flickity.pkgd.min.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/jquery.fancybox.pack.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url(); ?>forentend/js/retina.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/waypoints.min.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/scripts-min.js"></script> 
<!-- Google Analytics: change UA-XXXXX-X to be your site's ID. --> 
<script src="<?php echo base_url(); ?>forentend/js/makisu.js"></script> 

<!-- New Add ONN For About Us  --> 
<script src="<?php echo base_url(); ?>forentend/js/easing.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/jquery.fitvids.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/modernizr.custom.js"></script> 
<script src="<?php echo base_url(); ?>forentend/js/modernizr-2.6.2.min.js"></script> 








<script>
        // The `enabled` flag will be `false` if CSS 3D isn't available
        if ( $.fn.makisu.enabled ) {

            var $sashimi = $( '.sashimi' );
            var $nigiri = $( '.nigiri' );
            var $maki = $( '.maki' );

            // Create Makisus

            $nigiri.makisu({
                selector: 'dd',
                overlap: 0.85,
                speed: 1.7
            });

            $maki.makisu({
                selector: 'dd',
                overlap: 0.6,
                speed: 0.85
            });

            $sashimi.makisu({
                selector: 'dd',
                overlap: 0.2,
                speed: 0.5
            });

            // Open all
             
            // Toggle on click

            $( '.toggle' ).on( 'click', function() {
                $( '.list' ).makisu( 'toggle' );
            });

            // Disable all links
		}

    </script> 
<script type="text/javascript" src="<?php echo base_url(); ?>forentend/js/jquery.fadeImg.js"></script> 
<script>
  $(document).ready(function($) {
    $(".slide").fadeImages({
      time:3000,
      arrows: true,
      complete: function() {
        console.log("Fade Images Complete");
      }
    });

  });
</script>
</body>
</html>