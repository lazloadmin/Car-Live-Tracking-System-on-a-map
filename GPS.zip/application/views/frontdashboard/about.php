<div class="slider"></div>
<div class="sheet">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head">ABOUT US</div>
                <div class="about_h">Discover our jobs and the rigorous process of creation. Our principles are creativity, design, experience and knowledge.</div>
                <div class="underline"></div>
                <div class="para">
                   WorldTrack  is a privately-held company headquartered in Noida, Center of India . The WorldTrack’s  team is committed to providing quality tracking systems that integrate seamlessly with your everyday business operations, backed by reliable service and customer support. Customers can contact WorldTrack’s with questions regarding their vehicle tracking systems and a real, live person will assist you. The WorldTrack’s staff has the experience and know-how to provide effective tracking solutions for any industry.
                    <br />
                    At WorldTrack we don’t stop with just GPS. Our GPS Tracking System provides a total of three methods for determining and reporting tracking location data.
                    <br/> <br />
                    Our GPS Tracking System provides location data using both GPS along with cellular technology, which we have programmed to provide for cell tower triangulation or Advanced Forward Link Triangulation (AFLT). While it is usually necessary to connect with three cell towers for the most accurate cellular location data, should this not be possible, location data at that moment will be provided from the nearest cell, which we have programmed as our third method of reporting location data.
                    <br/> <br />
                    With WorldTrack, you know that you’re getting the most accurate tracking location data available because we provide three methods for determining “the location of whatever you're tracking!”
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sheet">
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                <div class="row">
                    <div class="col-md-12">
                        <div class="instabox">
                            <h4>Installation Contract</h4>
                            <p>
                                For more information about WorldTrack. and affordable vehicle tracking solutions, contact: <a href="#">gps.worldtrack@gmail.com</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="returnbox">
                            <h4>Return Policy</h4>
                            <p>To request a return authorization for either warranty or non-warranty hardware repair service, please print out and complete an RMA Request Form and Dispatch to courier it to Company. Normal response time for a submitted request is typically two business days.</p>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="cont_h">
                            Contact Us</div>
                        <div class="cont_p">

                            To access the secure documents please contact WorldTrack.
                        </div>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn cont">Submit</button>
                    </div>

                </div>

            </div>
<!--            <div class="col-md-4">
                <div class="recentbox">
                    <div class="headcover"><h5>Recent Client's Comments</h5></div>
                    <div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
                    </p>



                    <div class="name">Ravi Khanna, Gurgaon</div>
                    <p>
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
                    </p>

                </div>
            </div>-->

        </div>
    </div>
</div>

<section class="video" id="about">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i> Contact US
                    
                    <table>
                        <tr> 
                            <td> <?php echo $sitesetting['livechat'];?></td>
                        </tr>
                        
                    </table>
                    
                    </a></h1>
                  <h1> B - 7, 4th floor, Sector - 64, Noida, Uttar Pradesh 201301 </h1>
            <h1> Mobile : +91 9718624466 , +91 9718626633 , Phone : 120-4107052 , E-MAIL :  gps.worldtrack@gmail.com </h1>
            </div>
        </div>
    </div>
</section>