<div class="slider">

</div>
<div class="sheet">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head" style="margin-bottom:10px !important;">CONTACT US</div>
                <p style="text-align:center;margin-bottom:40px !important;">For more information on our services and custom solutions please contact us. We are just an e-mail or phone call away.</p>
            </div>
        </div>
        
        <?php if ($this->session->flashdata('flash_message')) { ?>
<div class="alert alert-block alert-success fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i>
</div>
<? }
if($this->session->flashdata('permission_message')){ ?>
<div class="alert alert-block alert-warning fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?>
</div>
<? }?>
        
        <div class="row">
            <div class="col-md-8">

                <form method="post" action="<?php echo base_url(); ?>index.php/Home/sendEmail">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" name="name" class="form-control pay"  placeholder="Name" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" name="email" class="form-control pay"  placeholder="Email-ID" required>

                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Phone No</label>
                        <input type="text" name="phone" class="form-control pay"  placeholder="Phone no">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Message</label>
                        <textarea class="form-control" name="message" rows="3" placeholder="Message"></textarea>  
                    </div>
                    <button type="submit" name="sub" class="btn conbut">Submit</button>
                </form>

            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">


                        <div class="addressbox">
                            <div class="headbox"> <h4> <i class="fa fa-comments-o" aria-hidden="true"></i> Additional Information </h4>  </div>
                            <h6> Contact Us</h6>
                            <hr>
                            <div class="addrescontent">
                                <ul>
                                    <li><strong>B - 7, 4th floor, Sector - 64,  Noida, Uttar Pradesh  201301</strong> </li>
<!--                                    <li> Uttar Pradesh 201301   </li>-->
<!--                                    <li> Dfgvdv, Lucknow</li>-->
                                </ul>
                            </div>
                            <div class="addrescontent">
                                <ul>
                                    <li><strong>P</strong>: 120-4107052 </li>
                                    <li><strong>M</strong>: +91 9718624466 , +91 9718626633 </li>
                                    <li> <strong>Mail</strong>: gps.worldtrack@gmail.com </li>




                                </ul>
                            </div>
                        </div>
                    </div>
                </div>




            </div>

        </div>
    </div>
</div>



<div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14010.31144136273!2d77.3771916!3d28.6124383!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa91168d288336fd!2sWorldtrack+GPS!5e0!3m2!1sen!2sin!4v1483521661594" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<table>
    <tr> 
        <td> <?php echo $sitesetting['livechat']; ?></td>
    </tr>

</table>