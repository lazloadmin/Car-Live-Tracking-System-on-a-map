
<?php
	$MERCHANT_KEY = "gtKFFx";
	$SALT = "eCwWELxi";
	$PAYU_BASE_URL = "https://test.payu.in";
	$action = '';
 
	$posted = array();
	if(!empty($_POST)) {
	  foreach($_POST as $key => $value) {    
	    $posted[$key] = $value; 
	  }
	}
	$formError = 0;
	if(empty($posted['txnid'])) {
	  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	} else {
	  $txnid = $posted['txnid'];
	}
	$hash = '';
	$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
	if(empty($posted['hash']) && sizeof($posted) > 0) {
	  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
                  
			  
	  ) {
	    $formError = 1;
 
	  } else {
		$hashVarsSeq = explode('|', $hashSequence);
	    $hash_string = '';	
		foreach($hashVarsSeq as $hash_var) {
	      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
	      $hash_string .= '|';
	    }
	    $hash_string .= $SALT;
	    $hash = strtolower(hash('sha512', $hash_string));
	    $action = $PAYU_BASE_URL . '/_payment';
	  }
	} elseif(!empty($posted['hash'])) {
	  $hash = $posted['hash'];
	  $action = $PAYU_BASE_URL . '/_payment';
	}
         if($fail){
             $hash = '';
             $action = '';
         }
	
?>
 <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
		//console.log(hash);
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>


  <div class="slider">
  
  </div>
 <div class="payment">
 <div class="container">
 <div class="row">
 <div class="col-md-12">
 <h4> Payment with Us in Quick Step !</h4>
 
 </div>
 </div>
<?php if ($this->session->flashdata('flash_message')) { ?>
<div class="alert alert-block alert-success fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <i class="fa fa-smile-o"></i> <?php echo $this->session->flashdata('flash_message'); ?>  <i class="fa fa-thumbs-up"></i>
</div>
<? }
if($this->session->flashdata('permission_message')){ ?>
<div class="alert alert-block alert-warning fade in">
    <a class="close" data-dismiss="alert" href="#" aria-hidden="true">X</a>
    <i class="fa fa-frown-o"></i> <?php echo $this->session->flashdata('permission_message'); ?>
</div>
<? }?>
                                   
  <div class="row">
  <div class="col-md-4">
  <div class="formback">
      
      
      <body onLoad="submitPayuForm()">
      <form action="<?php echo $action; ?>" method="post" name="payuForm">
          <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
        <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
        <input type="hidden" name="txnid" id="txnid" value="<?php echo $txnid ?>" />
<!--        <input type="hidden" name="amount" value="50" />
	<input type="hidden" name="productinfo" value="Iphone 6C - 16GB" />-->
	<input type="hidden" name="surl" value=" <?php echo base_url(); ?>index.php/Home/payNow/sucess"/> <!-- Success notification    http://localhost/payu/success.php -->
	<input type="hidden" name="furl" value="<?php echo base_url(); ?>index.php/Home/payNow/fail"/>
       <div class="form-group">
           <input name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>"  class="form-control pay"  placeholder="User Name" />
       </div>
        <div class="form-group">
           <input name="email" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" class="form-control pay"  placeholder="Email"/>
       </div>
        <div class="form-group">
            <input name="phone" id="phone" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" class="form-control pay"  placeholder="Phone No"/>
       </div>
        <div class="form-group">
            <input type="text" name="productinfo" id="productinfo" value="Iphone 6C - 16GB" class="form-control pay"  placeholder="product Info" />
       </div>
        
        <div class="form-group">
           <input type="text" name="amount" id="amount" value="50" class="form-control pay"  placeholder="Amount"  />
       </div>
          
        <?php if(!$hash) { ?>
        <a href="#" id='ppp' > <input type="submit"  value="Pay Now" class="btn paybut" /> </a>
          <?php } ?>  
        
        

    </form>
      </body>
      
      

</div>
  </div>

  <div class="col-md-8">
 <a href="#"> <img src="<?php echo base_url(); ?>forentend/images/buy-now-credit-card-icons-button.png" class="img-responsive"></a>
  </div>
  </div>
  </div>
 </div> 
  <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14010.31144136273!2d77.3771916!3d28.6124383!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa91168d288336fd!2sWorldtrack+GPS!5e0!3m2!1sen!2sin!4v1483521661594" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
    
     
    <section class="video" id="about">
    <div class="container">
        <div class="row">
        <div class="col-md-12 text-center">
            <h1><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i> Contact US
                
                    <table>
                        <tr> 
                            <td> <?php echo $sitesetting['livechat'];?></td>
                        </tr>
                        
                    </table>
                </a></h1>
              <h1> B - 7, 4th floor, Sector - 64, Noida, Uttar Pradesh 201301 </h1>
            <h1> Mobile : +91 9718624466 , +91 9718626633 , Phone : 120-4107052 , E-MAIL :  gps.worldtrack@gmail.com </h1>
          </div>
      </div>
      </div>
  </section>
 <!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
  <script src="<?php echo base_url() ?>assets/js/1.10.2.jquery.min.js"></script>
 <script>
 $(document).ready(function() {
       // for delete item from list
        $("#ppp").click(function(e) {
          
       // var id = this.id;
        $.ajax({
         url: '<?php echo base_url(); ?>index.php/Home/payNow/create',
           type:"POST",
            data:{'name':$("#firstname").val(),
                  'email':$("#email").val(),
                  'phone':$("#phone").val(),
                  'productinfo':$("#productinfo").val(),
                  'amount':$("#amount").val(),
                  'txnid':$("#txnid").val(),
                  
              },
            success: function(response)
            {
                // console.log(response);
                // alert(response);
                
            }
         });
     

    });


    });
 
 </script>
   