
   
<div class="wrap">
    <div class="slide">
        <ul>
            <?php foreach($banner as $key=>$value1){ $img = $value1['image']; ?> 
            
            <li style="background-image:url(<?php echo base_url(); ?>uploads/<?php  echo $img ; ?>)">
                
       <h4> <?php echo $value1['description']; ?> </h4>
          <div class="package"> 
          <p> <?php echo $value1['heading1']; ?> </p>
           
           <p> <?php echo $value1['heading2']; ?> </p>
           
          <p> <?php echo $value1['heading3']; ?> </p>
          </div>
                
                
          </li>
<!--        <li style="background-image:url(<?php echo base_url(); ?>forentend/images/slidy.jpg)">
            <h4> MEDICAL LABS INSTRUMENTS</h4>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
          </li>
        <li style="background-image:url(<?php echo base_url(); ?>forentend/images/how-does-gps-tracking-work.jpg)">
            <h4>VARIETY OF CCTV CAMERAS</h4>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
          </li>
        <li style="background-image:url(<?php echo base_url(); ?>forentend/images/Gps-Tracking-System_new.jpg)">
            <h4>SCHOOL ERP SOFTWARE</h4>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
          </li>-->
            <?php } ?> 
      </ul>
      </div>
  </div>
  


    <section class="features-intro">
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-6 nopadding features-intro-img">
            <div class="features-bg">
            <div class="texture-overlay"></div>
            <div class="features-img wp1"> <img src="<?php echo base_url(); ?>forentend/images/2015-03-02_02-48-38.jpg" class="img-responsive" > </div>
          </div>
          </div>
        <div class="col-md-6 nopadding">
            <div class="slidebot">
            <h1> VEHICLE TRACKING  SYSTEMS </h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
            <h1> School ERP</h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
            <h1>VARIETY OF CCTV CAMERAS</h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed a lorem quis neque interdum consequat ut sed sem. Duis quis tempor nunc. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
          </div>
          </div>
      </div>
      </div>
  </section>
    <section class="features-list" id="features">
    <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div class="col-md-4 feature-1 wp2">
            <div class="feature-icon fact1"> <i class="fa fa-street-view" aria-hidden="true"></i> </div>
            <div class="feature-content">
                <h1>GPS Tracking System</h1>
                <p style="text-align:justify;">Aim of WorldTrack  . is not to merely display the location of the vehicle on Map, but to provide our customers with bunch of useful data in form of various Graphical Reports to better manage their vehicles.</p>
              </div>
          </div>
            <div class="col-md-4 feature-2 wp2 delay-05s">
            <div class="feature-icon fact2"> <i class="fa fa-shield" aria-hidden="true"></i> </div>
            <div class="feature-content">
                <h1>House/Office Security</h1>
                <p style="text-align:justify;">Closed Circuit Television (CCTV) Cameras are the key facilitator of all homes, business areas, educational institutions, and other public places as they provide ultimate security and ensure safety.</p>
              </div>
          </div>
            <div class="col-md-4 feature-3 wp2 delay-1s">
            <div class="feature-icon fact3"> <i class="fa fa-smile-o" aria-hidden="true"></i> </div>
            <div class="feature-content">
                <h1>School ERP</h1>
                <p style="text-align:justify;">We are the leading manufacturer of scientific instruments India such as Laboratory Autoclave, Hot Air Oven, Incubator, Vacuum Oven, water bath, water testing equipments, cooling instruments. </p>
              </div>
          </div>
          </div>
      </div>
      </div>
  </section>
    <section class="showcase">
    <div class="showcase-wrap">
        <div class="texture-overlay"></div>
        <div class="container">
        <div class="row">
            <div class="col-md-6">
            <div class="device wp3">
                <div class="device-content">
                <div class="showcase-slider">
                    <ul class="slides" id="showcaseSlider">
                    <li> <img src="<?php echo base_url(); ?>forentend/images/screen1.jpg" alt="Device Content Image"> </li>
                    <li> <img src="<?php echo base_url(); ?>forentend/images/screen2.jpg" alt="Device Content Image"> </li>
                    <li> <img src="<?php echo base_url(); ?>forentend/images/screen3.jpg" alt="Device Content Image"> </li>
                  </ul>
                  </div>
              </div>
              </div>
          </div>
            <div class="col-md-6">
            <h3 style="color:#FFF;font-weight:bold; font-size:20px;">Why Us</h3>
            <p style="text-align:justify;">WorldTrack  is known for its commitment towards providing the best possible services to our esteemed clients. Our customer centric approach always put us ahead of our competitors in everything we do. Our passion towards the quality and long-term relationships always gives us an opportunity to retain our customers with a big satisfied smile.<br>
                We are committed to deliver what we promise to our customers. We treat our customers as we ourselves would like to be treated. We have a young team of experts who are having technical expertise and are passionate to provide top notch software solutions with a responsive customer service desk. </p>
            <h3 style="color:#FFF;">How It Works?</h3>
            <p style="text-align:justify;">Our device uses the Global Positioning System to determine the precise location of a vehicle or other asset to which it is attached. The position is recorded at regular intervals and is transmitted to a central database using a cellular (GPRS) modem embedded in the unit. This allows the location to be displayed on a map in real-time or over a span of time in Control Center.</p>
          </div>
          </div>
      </div>
      </div>
  </section>
    <section class="screenshots-intro">
    <div class="container">
        <div class="row">
        <div class="col-md-12">
            <h1 style="text-align:center;">Strong Backend As Per World-Class Standards with Strong Integration 
            with GPS Provider for Large Scale Deployments.</h1>
          </div>
      </div>
      </div>
  </section>
    <section class="screenshots" id="screenshots">
    <div class="container-fluid">
        <div class="row">
        <ul class="grid">
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/1.png" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/1.png" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Fleet Management Software</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/15.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/15.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Biometric System</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/access-control-card.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/access-control-card.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Door Access Control System</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/825200620739PMmin.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/825200620739PMmin.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Smart Cards</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
          </ul>
      </div>
        <div class="row">
        <ul class="grid">
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/cctv_camera_security_80080_3900x2600.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/cctv_camera_security_80080_3900x2600.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p> CCTV Security & Surveillance System</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/maxresdefault (1).jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/maxresdefault (1).jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Taxi Dispatch Software</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/maxresdefault.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/maxresdefault.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Bike Tracking System</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
            <li>
            <figure> <img src="<?php echo base_url(); ?>forentend/images/services/TRKM-Bus-GPS.jpg" alt="Screenshot 01">
                <figcaption>
                <div class="caption-content"> <a href="<?php echo base_url(); ?>forentend/images/services/TRKM-Bus-GPS.jpg" class="single_image"> <i class="fa fa-search"></i><br>
                  <p>Social School Bus Tracking System</p>
                  </a> </div>
              </figcaption>
              </figure>
          </li>
          </ul>
      </div>
      </div>
  </section>
    <div class="map">
   
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14010.31144136273!2d77.3771916!3d28.6124383!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa91168d288336fd!2sWorldtrack+GPS!5e0!3m2!1sen!2sin!4v1483521661594" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
  </div>
    <section class="video" id="about">
    <div class="container">
        <div class="row">
        <div class="col-md-12 text-center">
            <h1><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i> Contact US
                
                <table>
                        <tr> 
                            <td> <?php echo $sitesetting['livechat'];?></td>
                        </tr>
                        
                    </table>
                </a></h1>
             <h1> B - 7, 4th floor, Sector - 64, Noida, Uttar Pradesh 201301 </h1>
            <h1> Mobile : +91 9718624466 , +91 9718626633 , Phone : 120-4107052 , E-MAIL :  gps.worldtrack@gmail.com </h1>
           
            
          </div>
      </div>
      </div>
  </section>
