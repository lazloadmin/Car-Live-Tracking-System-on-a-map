<div class="slider">
 
  </div>
   <div class="sheet">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="head">SUPPORT</div>
<div class="underline"></div>
<div class="row"> 
  <div class="col-md-8">
  <div class="row">
  <div class="col-md-12">
  <div class="instabox">
<h4>Activation document and instruction</h4>
<p>
    To access the secure documents please contact WorldTrack . to obtain the user name and password .If you already have a username and password:  <a href="http://worldtrackgps.in/" target="blank">Login Here</a>
</p>
</div>
  
  </div>
  </div>
  <div class="row">
  <div class="col-md-12">
  <div class="returnbox">
<h4>Phone Support</h4>
<p>
Please feel free to contact our Customer Service no our sales representatives will more than happy to help you on mention below number or by :</p>
<div class="menpar">
<ul>
<li>EMAIL : <a href="#">gps.worldtrack@gmail.com </a></li>
<li>PHONE :  120-4107052   </li>
<li>  MOBILE : +91 9718624466 , +91 9718626633 </li>
</ul>
</div>



</div>
  
  </div>
  </div>
  
  
  <div class="row">
  <div class="col-md-12">
  <h4 style="font-weight:bold;">DOWNLOAD</h4>
 <ul style="margin-left: 16px;margin-top: 10px;">
 <li> <a href="#">Training Videos</a></li>
 <li> <a href="#">Firmware Downloads </a></li>
 <li> <a href="#">Product Manuals</a></li>
 <li> <a href="#">Technical Documentation</a></li>
 <li> <a href="#">Activation Request Form</a></li>
 </ul> 
  
  
  </div>
  </div>
  <div class="row">
  <div class="col-md-6">
  <div class="serverbox">
  <div class="row">
  <div class="col-md-4">
  <div class="colum1">
  
  <i class="fa fa-lock" aria-hidden="true"></i>
  
  </div>
  </div>
  <div class="col-md-8">
  <h4>Server 1</h4>
  <p><a href="http://worldtrackgps.in/" target="blank">Login Here>></a></p>
  </div>
  </div>
  </div>
  </div>
  <div class="col-md-6">
   <div class="serverbox">
  <div class="row">
  <div class="col-md-4">
  <div class="colum2">
  
  <i class="fa fa-lock" aria-hidden="true"></i>
  
  </div>
  </div>
  <div class="col-md-8">
  <h4>Server 2</h4>
  <p><a href="http://worldtrackgps.in/" target="blank">Login Here>></a></p>
  </div>
  </div>
  </div>
  </div>
  </div>
  
  </div>
<!--  <div class="col-md-4">
  <div class="recentbox">
<div class="headcover"><h5>Recent Client's Comments</h5></div>
<div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
<p>
If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
</p>



<div class="name">Ravi Khanna, Gurgaon</div>
<p>
It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
</p>
<div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
<p>
If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
</p>
<div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
<p>
If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
</p>
<div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
<p>
If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
</p>
</div>

  </div>-->
  </div>

  </div>
  </div>
  </div>
  </div>

   <section class="video" id="about">
    <div class="container">
        <div class="row">
        <div class="col-md-12 text-center">
            <h1><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i> Contact US
                
                 <table>
                        <tr> 
                            <td> <?php echo $sitesetting['livechat'];?></td>
                        </tr>
                        
                    </table>
                
                </a></h1>
               <h1> B - 7, 4th floor, Sector - 64, Noida, Uttar Pradesh 201301 </h1>
            <h1> Mobile : +91 9718624466 , +91 9718626633 , Phone : 120-4107052 , E-MAIL :  gps.worldtrack@gmail.com </h1>
          </div>
      </div>
      </div>
  </section>