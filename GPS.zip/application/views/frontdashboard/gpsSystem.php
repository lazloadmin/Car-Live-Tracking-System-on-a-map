<div class="slider">

</div>


<div class="sheet">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="head">Global Positioning System (GPS)</div>

                <div class="underline"></div>
                <div class="para">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sheet">
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                <div class="row">
                    <div class="col-md-12">
                        <img src="<?php echo base_url(); ?>forentend/images/gps-tracking.jpg" class="img-responsive">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h4><strong>How accurate is GPS?</strong></h4>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="<?php echo base_url(); ?>forentend/images/reports.png" class="img-responsive">
                            </div>
                            <div class="col-md-9">
                                <div class="para">
                                    Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature<br> discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h4><strong>How GPS Vehicle Tracking Works</strong></h4>
                        <ul>
                            <li>A GPS chip in the Communicator Box computes the Latitude and Longitude position every Second.</li>
                            <li>The GPS data is stored in the unit memory data in its’ memory.</li>
                            <li>The box transmits the GPS data via GSM(GPRS) to the Control Center (CC).</li>
                            <li>The Control Center decrypts the data and makes it available to the Internet server.</li>
                            <li>In the Web based application, The GIS Software plots the vehicle position accurately on a map.</li>
                        </ul>

                    </div>

                </div>

            </div>
            <div class="col-md-4">
                <div class="recentbox">
                    <div class="headcover"><h5>Recent Client's Comments</h5></div>
                    <div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
                    </p>
                    <div class="name">Ravi Khanna, Gurgaon</div>
                    <p>
                        It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
                    </p>
                    <div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
                    </p>
                    <div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
                    </p>
                    <div class="name">Anurag Jain, Director, Tour & Travels Agency, Delhi</div>
                    <p>
                        If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.
                    </p>

                </div>
            </div>

        </div>
    </div>
</div>

<section class="video" id="about">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h1><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i> Contact US
                    <table>
                        <tr> 
                            <td> <?php echo $sitesetting['livechat'];?></td>
                        </tr>
                        
                    </table>
                    </a></h1>
                   <h1> B - 7, 4th floor, Sector - 64, Noida, Uttar Pradesh 201301 </h1>
            <h1> Mobile : +91 9718624466 , +91 9718626633 , Phone : 120-4107052 , E-MAIL :  gps.worldtrack@gmail.com </h1>
            </div>
        </div>
    </div>
</section>