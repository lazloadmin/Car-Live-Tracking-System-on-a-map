<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>
      WorldTrack
  </title>
  <link rel="icon" href="<?php echo base_url(); ?>forentend/images/favIcon.png" type="image/gif" sizes="16x16">

  <!-- Bootstrap -->
  <link href="<?php echo base_url(); ?>forentend/css/bootstrap.min.css" rel="stylesheet">
  <script src="<?php echo base_url(); ?>forentend/js/modernizr.custom.js"></script>
  <link href="<?php echo base_url(); ?>forentend/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/jquery.fancybox.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/flickity.css" rel="stylesheet" >
  <link href="<?php echo base_url(); ?>forentend/css/animate.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/styles.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/queries.css" rel="stylesheet">
  <!--  For About Us Page--> 
  <link href="<?php echo base_url(); ?>forentend/css/3ddrop.css" rel="stylesheet">
<!--  <link href="<?php echo base_url(); ?>forentend/css/lightbox.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>forentend/css/myslider.css" rel="stylesheet">
   <link href="<?php echo base_url(); ?>forentend/css/owl.carousel.css" rel="stylesheet">
   <link href="<?php echo base_url(); ?>forentend/css/owl.theme.css" rel="stylesheet">
  
 
  <style>
.wrap {
	max-width: 100%;
	height: 800px;
	margin-top: -65px;
}
.slide {
	width: 100%;
	height: 800px;
	margin: 0 auto;
	position: relative;
	overflow: hidden;
}
.slide ul {
	margin: 0 auto;
	height: 382px;
	cursor: pointer;
}
.slide ul li {
	width: 100%;
	list-style: none;
	position: absolute;
	z-index: 1;
	height: 800px;
	background-position: top center;
	top: 0;
	left: 0;
	right: 0;
}
.slide ul li h4 {
	font-size: 40px;
	color: #FFF;
	font-weight: bold;
	position: absolute;
	z-index: 1000;
	top: 45%;
	left: 10%;
	right: 0;
	width: 40%;
}
.slide ul li p {
	font-size: 20px;
	color: #FFF;
	font-weight: bold;
	position: absolute;
	z-index: 1000;
	top: 60%;
	left: 10%;
	right: 0;
	width: 70%;
}
.slide #dots {
	position: absolute;
	left: 0;
	right: 0;
	bottom: 10px;
	height: 30px;
	z-index: 9999;
	font-size: 0;
	text-align: center;
	opacity: 0.7;
}
.slide #dots a {
	background: #333;
	margin: 0 6px;
	width: 18px;
	height: 18px;
	box-shadow: 0 0 1px 0 #333;
	border-radius: 100%;
	display: inline-block;
	cursor: pointer;
}
.slide #dots a.active {
	background: #FFF;
}
.slide .arrow {
	position: absolute;
	top: 50%;
	width: 70px;
	height: 100px;
	margin-top: -50px;
	background: #333;
	z-index: 999;
	opacity: 0.7;
	line-height: 100px;
	color: #FFF;
	text-align: center;
	text-decoration: none;
}
.slide .arrow.prev {
	left: 0;
}
.slide .arrow.next {
	right: 0;
}
.slide .arrow:active {
	background: #FAFAFA;
	opacity: 1;
}
.nav-wrapper img {
	position: absolute;
	z-index: 1000;
	top: 10px;
}
.nav-wrapper nav {
	position: absolute;
	z-index: 1000;
	top: 10px;
}
</style>-->
  </head>
  
  
  
  
  
  <div class="holder">
    <header>
    <div class="container">
        <div class="row nav-wrapper">
        <div class="col-md-4 col-sm-4 col-xs-4 text-left"> 
        <a href="<?php echo base_url() ?>index.php/Home/index"><img src="<?php echo base_url(); ?>forentend/images/logoh.png" class="mylogo"></a>
         </div>
        <div class="col-md-1"></div>
        
        
        
        <div class="col-md-4">
        <nav class="nav">
            <ul>
            <li > <a href="http://worldtrackgps.in/" target="blank">Server1</a>  </li>
               <li> <a href="#">LOGIN</a>
                <ul style="padding:0px 8px; background:#093; margin-top:8px;">
                    <form class="form-inline" style="margin-top:8px;">
                    <div class="form-group">
                        <input type="email" class="form-control name" id="exampleInputName2" placeholder="User ID">
                      </div>
                    <div class="form-group">
                        <input type="password" class="form-control name" id="exampleInputEmail2" placeholder="Password">
                      </div>
                    <div class="col-md-5" style="padding:0px;">
                        <button type="submit" class="btn logbut">Login</button>
                      </div>
                    <div class="col-md-7" style="padding:2px;">
                        <p style="padding:0px; font-size:11px;">Forgot Password ?</p>
                      </div>
                  </form>
                  </ul>
              </li>
           
<!--             <li> <a href="http://103.16.140.48:7001/login.aspx" target="blank">Server2</a></li>-->
                
              
              </ul>
          </nav>
        </div>
        
        
<!--          <div class="col-md-2">
            <nav class="nav">
              <ul>
                <li> <a href="#">Server1</a> </li>
              </ul>
          </nav>
          </div>-->
        
<!--         <div class="col-md-2">
            <nav class="nav">
              <ul>
                  <li> <a href="http://103.16.140.48:7001/login.aspx" target="blank">Server2</a> </li>
              </ul>
          </nav>
          </div>-->
         
        
        
<!--        <div class="col-md-2">
            <nav class="nav">
            <ul>
                <li> <a href="#">LOGIN</a>
                <ul style="padding:0px 8px; background:#093; margin-top:8px;">
                    <form class="form-inline" style="margin-top:8px;">
                    <div class="form-group">
                        <input type="email" class="form-control name" id="exampleInputName2" placeholder="User ID">
                      </div>
                    <div class="form-group">
                        <input type="password" class="form-control name" id="exampleInputEmail2" placeholder="Password">
                      </div>
                    <div class="col-md-5" style="padding:0px;">
                        <button type="submit" class="btn logbut">Login</button>
                      </div>
                    <div class="col-md-7" style="padding:2px;">
                        <p style="padding:0px; font-size:11px;">Forgot Password ?</p>
                      </div>
                  </form>
                  </ul>
              </li>
              </ul>
          </nav>
          </div>-->
        <div class="col-md-3"> 
            <!--<p>MENU</p>
            <a id="trigger-overlay" class="nav_slide_button nav-toggle" href="#"><span></span></a> </div>-->
            <section class="demo">
            <dl class="list maki">
                <dt></dt>
               <dd><a href="<?php echo base_url() ?>index.php/Home/index">Home</a></dd>
                <dd><a href="<?php echo base_url() ?>index.php/Home/about">About</a></dd>
                <dd><a href="#">Products</a></dd>
                <dd style="text-indent: 40px;"><a href="<?php echo base_url() ?>index.php/Home/gpsSystem">GPS System</a></dd>
                <dd style="text-indent: 40px;"><a href="#">School ERP</a></dd>
<!--               <dd><a href="<?php echo base_url() ?>index.php/Home/Faq">FAQ</a></dd>-->
                <dd><a href="<?php echo base_url() ?>index.php/Home/Contact">Contact</a></dd>
                <dd><a href="<?php echo base_url() ?>index.php/Home/Support">Support</a></dd>
                <dd><a href="<?php echo base_url() ?>index.php/Home/payment">Payment</a></dd>
              </dl>
            <a href="#" class="toggle"><img src="<?php echo base_url(); ?>forentend/images/threelines.png" class="img-responsive"></a> </section>
          </div>
          
      </div>
      </div>
  </header>
  

  <?php //echo $sitesetting['livechat']; ?> 