
<!--<html>
  <head>
 
  </head>
  <body onLoad="submitPayuForm()">
    <h2>Payment System with PayUMoney - By Baldau Chaursiya Gopal Joshi (www.sgeek.org)</h2>-->
    <form action="<?php echo $action; ?>" method="post" name="payuForm">
     
      <table>
      
       <tr>
       <td colspan="4">
        <input type="text" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="text" name="hash" value="<?php echo $hash ?>"/>
      <input type="text" name="txnid" value="<?php echo $txnid ?>" />
      <input type="text" name="amount" value="50" />
	  <input type="text" name="productinfo" value="Iphone 6C - 16GB" />
	  <input type="text" name="surl" value="http://localhost/payu/success.php"/> <!-- Success notification -->
	  <input type="text" name="furl" value="http://localhost/payu/failure.php"/> <!-- Failure notification -->
       </td>
       </tr>
        <tr>
          <td>Amount: </td>
          <td>$50</td>
          <td>First Name: </td>
          <td><input name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" /></td>
        </tr>
        <tr>
          <td>Email: </td>
          <td><input name="email" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" /></td>
          <td>Phone: </td>
          <td><input name="phone" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" /></td>
        </tr>
        <tr>
          <td>Product: </td>
          <td colspan="3"> Iphone 6C - 16GB</td>
        </tr>
        <tr>
          <?php if(!$hash) { ?>
            <td colspan="4"><input type="submit" value="Submit" /></td>
          <?php } ?>
        </tr>
      </table>
    </form>
<!--  </body>
</html>-->

